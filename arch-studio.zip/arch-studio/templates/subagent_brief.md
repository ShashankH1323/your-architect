# Subagent brief template (keep it under ~40 lines)

```
ROLE: <drafter | modeller | researcher | checker> for <project>, workflow <Wx>.
JOB (one only): <e.g. Draw Section B-B' as DXF + vector PDF + preview PNG>.

READ ONLY THESE (sections, not whole files):
- 06_model/model_GF.json, model_FF.json, model_STRUCT.json  (via scripts; do not print them whole)
- 06_model/geometry.py          (import roof()/levels(); never re-derive)
- 07_drawings/DECISIONS.md      (read first)
- 03_references/LOCKED_STYLE.md → "Sections"
- arch-studio/standards/cad_dxf.md → layer scheme <Simple|Standard|Professional>

WRITE ONLY THESE:
- 07_drawings/src/secB_<step>.py   (unique prefix; small files)
- 07_drawings/DXF/A202_Section_BB.dxf, PDF/A202_Section_BB.pdf, previews/A202.png
- Append results under "## Section B-B" in 07_drawings/CHECKS.md

RULES:
- Save after each step (geometry → cut poché → beyond → annotation → export).
- Never read .dxf/.pdf/large images into context; check by script and by a 100 dpi preview.
- Vector output only. Arial. Legend for every line type. No codes, no audit text on the drawing.
- If you find a real clash (footing off a column, missing flight, room without door), REPORT it; don't redesign.
- Report progress to the progress tool if one exists.

DONE WHEN: files exist, checks logged, final reply ≤ 10 lines: what was made, checks PASS/FAIL, clashes found.
```
