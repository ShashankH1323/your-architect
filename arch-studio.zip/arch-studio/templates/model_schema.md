# Model schema (metres; x east, y north, z up; origin at a site corner)

This schema proved itself on the source project. Every drawing and every table is generated from these files.

## model_<LEVEL>.json
```json
{"level": "GF", "ffl": 0.30,
 "walls":    [{"id":"W001","type":"ext230|int230|int115|panel100|screen|curtain150|low|guard",
               "a":[x,y],"b":[x,y],"t":0.23,"z0":0.30,"z1":4.425}],
 "openings": [{"id":"D01","wall":"W001","kind":"door|window|glazing|hatch|louvre|opening|lift_door",
               "a":[x,y],"b":[x,y],"sill":0.0,"head":2.1,
               "door":{"leaves":1,"hinge":[x,y],"opens_to":[x,y],"type":"single|double|glass|double-action|sliding"}}],
 "rooms":    [{"id":"kitchen","no":10,"name":"KITCHEN","poly":[[x,y],...],"zone":"service",
               "finish":"tile300","area":63.2,"why":"cooks for both floors; on the outside wall for air"}],
 "stairs":   [{"id":"ST1","flights":[{"poly":[...],"risers":14,"riser":0.150,"tread":0.30,"up_dir":[0,1]}],
               "landing":[...],"landing_z":2.40}],
 "lifts":    [{"id":"L1","poly":[...],"door":"D17","kind":"passenger|food"}],
 "voids":    [{"poly":[...],"label":"Open to below"}],
 "furniture":[{"block":"TABLE-4SEAT-1200x750","x":0,"y":0,"rot":0,"layer":"A-FURN"}],
 "checks":   {}}
```

## model_STRUCT.json
- `grid`: `{"cols":{"1":12.0,...},"rows":{"A":9.5,...}}`. Labels are sequential and unique.
- `columns`: `[{id,x,y,section,z_base,z_top}]`
- `footings`: `[{col,x,y,w,l,d,z_bottom}]`. x and y equal the column's x and y.
- `pedestals`, `plinth_beams [{a,b,w,d,z_top}]`, `floor_beams [{a,b,section,z_top}]`
- `roof_members`, `bracing`, `gutters`, `downpipes`

## model_SITE.json
- `boundary`, `setbacks`, `roads`, `gates`
- `paving`, `planting`, `trees [{x,y,dia,kind}]`
- `parking` (block inserts), `vehicle_paths`
- `outdoor_furniture`, `yard_items`
- `roof_outline`

## geometry.py
- Shared functions: `levels()`, `roof_profile(x)` / `roof_top(x, y)`, `eave()`, `crest()`.
- Every section, elevation, axo and label imports these, so heights can never disagree.
- Record the datum in a docstring, e.g. "all roof levels = top of roofing".

## Finish codes (example)
`tile300` (wet/kitchen/stores), `vitrified600` (lobby/office), `stone600` (halls), `deck150` (terrace), `paver450` (outdoor), `lawn`, `garden`, `asphalt`, `concrete`
