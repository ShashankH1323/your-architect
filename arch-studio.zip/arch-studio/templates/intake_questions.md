# Intake questions: exact wording

Use the host's multiple-choice tool. Claude Code's AskUserQuestion takes at most 4 questions and 4 options each, and the user can always type "Other". Put the recommended option first.

## Round 1
```
Q1  header: "Purpose"
    question: "What is this project for? This decides how strictly I follow the brief."
    options:
      - "Studio submission"     – "Graded by a jury; follow the brief's intent, keep it explainable."
      - "Practice / self-study" – "Brief is a guide; I can drop non-essential items to keep it simple."
      - "Competition entry"     – "Every requirement and sheet rule of the brief must be met."
      - "Professional / client" – "Full code compliance and technical detail."

Q2  header: "Detail"
    question: "How detailed should the project be?"
    options:
      - "Balanced (Recommended)" – "Furnished plans, sections, elevations, simple structure; easy to explain."
      - "Simple"                 – "Keeps everything the brief really tests; leaves out rarely-noticed or very technical extras. Very easy to explain."
      - "Detailed"               – "Full technical depth: schedules, structure sheets, detailed CAD layers."

Q3  header: "Scope"
    question: "How far should I take it?"
    options:
      - "Full sheets + guides (Recommended)" – "Foundation, form, drawings, DXF, final presentation sheets, explainer guides."
      - "Up to drawings + DXF"               – "Foundation, form, plans, sections, elevations; no final sheet layout."
      - "Concept only"                       – "Area programme, zoning, bubble diagrams and form options."

Q4  header: "Presenter" (skip if Q1 = Professional)
    question: "Who will present and defend this work?"
    options:
      - "Me, as a student" – "Keep wording and structure simple enough to explain on the spot."
      - "A team"           – "Same, plus a short split of who explains what in the guide."
```

## Round 2 (only the missing items)
```
Q5  header: "Site"
    question: "Where is the site? (city + a landmark, or coordinates, or attach a Google Earth / site plan image)"
    → free text via "Other"; give 1–2 options only if the brief hints at them.

Q6  header: "Site size"
    question: "What are the site dimensions and which sides face roads?"
    options: "Use the brief's drawing" (if any) / "I'll type it" / "Estimate from the satellite image (I'll confirm with you)"

Q7  header: "Your ideas" (optional, free text)
    question: "Any theme, material, climate idea or feeling you want? Leave blank to let me propose."
    placeholder hint shown in the question text:
      "e.g. curved roof, exposed brick, courtyard, steel and glass, local craft as inspiration, lots of shade, keep it low-cost…"

Q7b header: "Your refs" (always ask in round 2; it saves a whole research step when the answer is yes)
    question: "Do you already have style references you like (from your own past projects or others)? You can add them per type, and skip any type."
    options:
      - "No, find them for me (Recommended if unsure)" – "I'll search and show you 3 options per drawing type."
      - "Yes, I'll add some"  – "Put them in the folders I create; any type you leave empty, I'll search for."
      - "Use my previous project" – "Point me to its PDF/DXF folder; I'll study its plans, sections, sheets and blocks."
    If "Yes": create the folders below, tell the user the exact paths in ONE message, and wait for "done" (or "skip").
      03_references/user/plan/        03_references/user/section/      03_references/user/elevation/
      03_references/user/sheet_composition/   03_references/user/diagrams/ (zoning, bubbles, programme tables)
      03_references/user/axo_3d/      03_references/user/details/      03_references/user/other/
    Hint shown: "One or more images or PDFs per folder. Empty folders are fine. You can add or replace files later."

Q8  header: "Numbers" (only if the brief leaves out a number that changes the programme)
    question: "How many <seats / users / vehicles> should we plan for?"
    options: "Typical for this type (Recommended)" – "<state the default, e.g. 150 seats, 3 trucks, 3 buses, 10 cars>" / "I'll give numbers"
```
