# PROJECT STATE (the lead keeps this current; any new chat reads it first)

## Route
- Purpose: <Practice | Studio jury | Competition | Professional>
- Detail: <Simple | Balanced | Detailed>
- Scope: <Concept only | Up to drawings | Full sheets + guides>
- Presenter: <Student | Team | Professional>
- Workflow: <W0 | W1 | W2 | W3 | W4>
- CAD layer scheme: <Simple | Standard | Professional>

## Project facts
- Brief: `01_brief/<file>`; digest: `01_brief/brief_digest.md`
- Site: <location, landmark, coordinates>; size <W × D m>; roads on <edges>; north <deg>
- User ideas (free text): "<…>"
- Numbers: <seats / users / vehicles / staff>, with source (user | default)
- Defaults assumed: <list>

## Locked styles (`03_references/LOCKED_STYLE.md`)
User references supplied: <none | some types | all | previous project at <path>>

| Sheet type | Pick | Reference file | Source (user / found / preset) |
|---|---|---|---|
| Programme table | | |
| Bubble | | |
| Zoning | | |
| Plan | | |
| Section | | |
| Elevation | | |
| Composition | | |

## Gates
| Gate | Status | Date | Version / note |
|---|---|---|---|
| Intake | | | |
| Foundation style | | | |
| **Foundation approval** | | | data frozen in `04_foundation/data/_approved_v1/` |
| Form pick | | | option + refinements |
| Drawing styles | | | |
| (W3) Compliance review | | | |
| (W4) Technical review | | | |
| Composition | | | |
| Delivered | | | |

## Changes after approval
- <date> <what changed> <why> <files rebuilt>
