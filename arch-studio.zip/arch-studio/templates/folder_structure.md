# Project folder structure (create at the start)

```
<Project_Name>/
  00_admin/
    PROJECT_STATE.md        route, answers, locked styles, gates
    PROGRESS.md             STATUS / DONE / RUNNING / NEXT
    assumptions.md          (W4)
  01_brief/
    <brief>.pdf             as uploaded
    brief_digest.md         requirements, deliverables, sheet rules, gaps
    compliance_matrix.csv   (W3/W4)
    site_images/            satellite screenshot, user sketches
  02_research/
    site_context.md  climate.md  regulations_internal.md
    space_standards_internal.md  precedents.md
    data/                   climate.csv, sunpath.csv, wind.csv
  03_references/
    user/                   the user's own refs: plan/ section/ elevation/ sheet_composition/ diagrams/ axo_3d/ details/ other/
    INDEX.md                what is in each type folder, and what was taken from it
    sheets_composition/ foundation_tables/ bubble/ zoning/ form/
    plan/ section/ elevation/ axo_3d/ details/
    _boards/                choice boards shown to the user
    sources.csv  LOCKED_STYLE.md
  04_foundation/
    data/                   users, journeys, programme, relations, zoning, site_testfit (.json)
    data/_approved_v1/      frozen copy at the foundation gate
    diagrams_src/           one script per diagram -> SVG
    sheets/                 HTML/CSS + build.py
    notes/                  dropped_items_internal.md, brief_check_internal.md
    PDF/                    Foundation.pdf, Foundation_Summary.pdf
  05_form/
    data/                   form_basis.json, form_options.json, form_final.json
    src/  PDF/              Form_Options.pdf
  06_model/
    model_SITE.json  model_GF.json  model_FF.json  model_STRUCT.json
    geometry.py             shared formulas (roof, levels)
    _backup_<rev>/
  07_drawings/
    src/                    blocks.py, plan_draw.py, sec_draw.py, elev_draw.py, ...
    DXF/  PDF/  PDF/tech/  previews/
    CHECKS.md  AUDIT.md  DECISIONS.md
  08_sheets/
    src/                    gen_sheets.py, style.css, pages/
    _boards/                composition_board.pdf
    PDF/                    Presentation.pdf
  09_guides/
    src/  PDF/              Project_Guide, Space_Guide, Furniture_Guide, Structure_Guide, Jury_QA
  10_3D_handoff/            (only if requested) START_HERE_3D.md + copies
  _scratch/                 temporary files; safe to delete
```

## Rules
- Do the work in this folder only. Never overwrite a gate-approved file. Copy to `_backup_<rev>/` first.
- One builder script per PDF, re-runnable with a single command. Write the command into PROGRESS.md.
- Names are plain and dated or versioned (`Foundation_v2.pdf`), never "final_final".
