# Arch Studio workflow pack

A Claude skill that takes an architecture brief to finished, explainable presentation sheets, with a DXF for AutoCAD. It was distilled from the AD-6 "Woven Street" roadside-cafe project (Oct 2026), keeping only what produced the final approved result and turning every failure into a rule.

## Install
- **Claude Code, all projects:** copy the `arch-studio/` folder to `C:\Users\<you>\.claude\skills\arch-studio\`.
- **Claude Code, one project:** copy it to `<project>\.claude\skills\arch-studio\`.
- **Claude.ai / other hosts:** upload `arch-studio/` as a skill (zip it), or paste `SKILL.md` as the system prompt and attach the other files as project knowledge.

Then just say: *"Here's my brief, start the project"* and attach the PDF. The skill asks its questions and runs the right workflow.

## The flow (what the user experiences)
```
Upload brief
  → 2 short rounds of questions (purpose, detail, scope, site, ideas)
  → [research + references, silent]
  → pick foundation sheet style (A/B/C)
  → Foundation PDF → ★ WARNING + APPROVAL (the one hard stop)
  → pick a form (3–5 purpose-driven options)
  → pick plan / section / elevation styles (A/B/C each)
  → [model, structure, furnished plans, sections, elevations, 3D vector views, DXF: silent, script-checked]
  → [blind review by a context-free reviewer → fixes: silent]
  → pick sheet layout (A/B/C)
  → Final presentation PDF + DXF + explainer guides
```

## Building a web product on top (UI contract)
The workflow already defines everything a UI needs. A front end only has to map these:
- **Upload slots = folders.**
  - `01_brief/` takes the brief.
  - `03_references/user/{plan, section, elevation, sheet_composition, diagrams, axo_3d, details, other}/` take the user's own references, one slot per type, each optional with a "Skip, find them for me" button.
- **Reference browser.** Show `03_references/INDEX.md` and each type folder (user and found), so users can see, replace or delete files. Replacing files then sending "update the <type> style" re-runs only that type (S3).
- **Choice boards** (`03_references/_boards/*.pdf`, `08_sheets/_boards/*.pdf`) render as A/B/C cards. The questions come from the host's question tool, so they map to buttons.
- **Progress:** `00_admin/PROGRESS.md` (STATUS / DONE / RUNNING / NEXT) and `PROJECT_STATE.md` (gates) drive a progress bar.
- **Downloads:** the `PDF/` and `DXF/` folders per stage.
- **The foundation gate** should be a deliberate approve button that shows the warning text, not a passive "next".
- **Originality registry.** Replace the registry file with a backend table that holds the same record as `scripts/originality.py`: brief key, hashes and design signatures only, no personal data. Every user of the product is then checked against everyone else on the same brief. Without that shared table, the check only covers one machine, or a folder shared through `ARCH_STUDIO_REGISTRY`.

## Sharing with a class or team
Set the environment variable `ARCH_STUDIO_REGISTRY` on every machine to the same synced file, e.g. a OneDrive or Google Drive folder: `.../arch-studio-registry.jsonl`. Projects on the same brief then steer away from each other's references, colours, layouts and forms.

## Workflows
| File | For |
|---|---|
| `W0_concept_sprint` | foundation + form only |
| `W1_student_simple` | practice briefs, lenient juries; smallest correct project |
| `W2_student_balanced` | studio jury; the reference route (the AD-6 result) |
| `W3_competition_strict` | real competitions: compliance matrix, anonymity, exact sheet rules |
| `W4_professional` | client/authority work: separate technical set, NCS layers, schedules |

## Where each rule came from (AD-6 lessons)
| What went wrong | Rule now in the pack |
|---|---|
| 84-space, 27-page foundation looked great but produced a plan with 20 windowless rooms | Journey-first programme, plannability test-fit, hard foundation gate with warning (S2) |
| Zoning arrows confusing; codes like "NE-1" | Legend for every marking, thin offset flows, plain names (presentation_rules) |
| "Simplified" hand-drawn summary rejected as AI slop | Simple = minimal, not amateur; style boards before any new look (S3) |
| Form options with no purpose ("why is that wheel?") | Driver-first forms, precedent reasons, coherence checks (S4) |
| Stair risers wrong, lift vanishing, escape stair drawn 4 ways, 3 roof heights, area typos | Single-source model + shared geometry + consistency audit (S5, S6, consistency_audit) |
| Footing not under its column in a section | Load-path rule in the checklist and section spec |
| Elevations unreadable until a quick 3D aerial was made | Vector aerials made proactively in S6/S7 |
| Presentation PDF blurry on zoom (PNG crops) | SVG-only vector pipeline + image-count check (presentation_rules, S8) |
| Student couldn't defend technical spaces or furniture | Space, furniture, project and structure guides + humanise pass (S9) |
| Subagents stuck for an hour, work lost at limits, reruns wasted tokens | Narrow one-shot jobs, small saves, PROGRESS.md, never interrupt, continue rather than rerun (agent_ops) |
| PDF imported to AutoCAD = exploded lines | DXF with blocks and layers, by user level (cad_dxf) |
| Areas looked right, but furniture was placed wrongly | Areas sized by furniture test-fit from Neufert / Time-Saver / NBC; placement order + use zones (space_standards_research, furniture_layout) |
| An outside AI found stair, column and foundation errors in the "final" PDF | Construction rules per element (technical_drawing_accuracy), check_model.py, blind review before the user sees anything (S10) |
| "Simple" was misread as "fewer rooms" | Brief-test analysis + space triage. Simple drops peripheral spaces only, never core tests, and has no space cap |
| No way to show where numbers came from | Sources_and_Standards.pdf with every area and rule sourced, unverified values flagged |

## Scripts shipped (tested on the AD-6 final model and PDFs)
- `scripts/lib/blocks.py`: 164 true-size DXF blocks; ezdxf audit 0 errors.
- `scripts/lib/cadlib.py`: DXF drawing helpers.
- `scripts/check_model.py`: run on the final AD-6 model, it found 3 real issues that survived into the "final" set: two room areas that no longer matched their outlines after the stair fix, and an 8 cm lift-shaft offset between floors.
- `scripts/check_pdf.py`: on the final AD-6 presentation, it found raster images still covering 30–100% of pages 1, 3, 4, 8 and 9. This is why some diagrams still blur on zoom.
