# S6: Sections and elevations

Both are generated from the model and the shared geometry functions, never drawn freehand.

## Sections
- **Choose cuts that explain the building:**
  - one long section through the main space and the stair;
  - one cross section;
  - (W2+) one through the core: stair, lift, toilets.

  Place each cut where it shows something: both flights of a stair, the lift, the roof's highest point.
- **Everything cut is drawn as cut**, in the locked style (e.g. solid black poché):
  - walls, slabs, roof, beams (as I-sections for steel);
  - ground line;
  - footings, pedestals and plinth beams below ground, in a soil band.
- Elements beyond are thin grey with light fills. Glass is pale.
- **The load path must be visible and true.** Every column lands on its own footing, centred. Walls sit on plinth beams. Never put a footing off the column line.
- Stairs: every flight drawn, risers counted correctly, landings at the right level. The lift shaft and overrun are continuous through all floors.
- Level tags: one value per element, the same on every sheet. Tag GF, FF, eave and crest/highest point, ground ±0.00 and the footing bottom only. Do not tag stray local heights.
- Each section carries a small **key plan** showing the cut line on the floor plan. The source user asked for a "proper key floor plan, not just the building outline".
- People in use (eating, cooking, walking) and context trees in the locked style. Add a scale bar and a spaced-caps title.

## Elevations
- 4 elevations (2 per sheet), named by what you see from, e.g. "ELEVATION FROM THE SERVICE ROAD". Don't use only "North".
- Locked style. The source favourite was fine dark linework, soft facade shading, a watercolour sky wash, sage trees, a grey ground band and one accent colour on steel edges.
- **Coherence check.** All four elevations must obviously show the same building: the same heights, roof profile, column rhythm and openings, matching the plans and sections. If one elevation looks "empty" because the building steps back, add context so a viewer understands it.
- In the source project, the user could not reconcile two elevations until a quick 3D aerial was made. Do this proactively: make 1–2 vector aerial views (S7) during this stage and check the elevations against them.

## Construction rules
Every stair, column/beam junction, footing, slab, wall and level is constructed per `standards/technical_drawing_accuracy.md`. Most failures in the source project were here.

## Before anyone sees the drawings
1. `check_model.py` → 0 FAIL.
2. The consistency audit (`standards/consistency_audit.md`) across plans, sections, elevations and 3D. Fix mismatches in the model and rebuild.
3. **Blind review R1** (`stages/S10_blind_review.md`): a context-free reviewer reads only the drawing PDF. Verify, fix and rebuild.
