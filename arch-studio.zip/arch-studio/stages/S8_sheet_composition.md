# S8: Sheet composition and the final set

## 1. Inventory
List every finished drawing and diagram with its aspect ratio, in `08_sheets/inventory.json`.

## 2. Three composition options (★ gate)
- Build `08_sheets/_boards/composition_board.pdf`. It has 3 layouts for the same content, drawn as clean block diagrams at true sheet proportion: grey boxes labelled "Site plan", "GF plan", "Section A-A" and so on, plus the title band and text column.
- Put the reference sheet that inspired each layout next to it.
- Offer the seed's 3 `composition_families` (from 5; see `originality.py`) in the seed's order. Before building, fill `plan_topology` and run `originality.py check --register`. If it's too similar, change the seed-driven parts (composition, accent) automatically. If the plan topology matches, do one variation round (entry side, core position, zoning moves) and re-check.
- Typical families (`standards/drawing_style_presets.md`):
  - **A:** a hero drawing with an ordered grid and a narrow text column (Deus / Fish House boards);
  - **B:** horizontal bands, e.g. a section strip across the top and plans below;
  - **C:** portrait A1 with a central large plan and drawings around it.
- Respect the brief's sheet size, count and orientation (W3: exactly).
- Ask: "Which sheet layout do you like?" A / B / C.

## 3. Build the set
- HTML + CSS pages (one `<section class="page">` per sheet, `@page` at the true size). Drawings are embedded as **SVG** (or PDF-to-SVG), never PNG. Print with headless Chrome to PDF.
- Each sheet has:
  - a numbered title band, e.g. "06 HOW IT WORKS: THE PLANS", with a one-line subtitle;
  - a consistent footer (project tag, sheet x/y, and "GROUP NO." if anonymous);
  - short captions in plain student language.
- Every table comes from the data files: the programme table from `programme.json`, the key numbers from the model. Never retype numbers.
- The programme sheet uses the full table from S2: Space / Qty / Unit size / Area / How we sized it / Source, plus totals vs limits. It is restyled to the locked sheet style, so the student presents it as is.
- Recommended sequence (adapt to the count):
  1. site & climate;
  2. users & programme;
  3. organisation & zoning;
  4. concept & form;
  5. site plan & open spaces;
  6. plans;
  7. section & experience;
  8. sections;
  9. elevations;
  10. structure & details.

## 4. Checks before delivery
- **Vector check:** with pymupdf, list the images on each page. Drawings must have 0 raster images; only photos or reference crops may be raster. Zoom-test one page at 400%.
- **Legibility:**
  - render each page at about 50 dpi;
  - no overflow, overlapping labels, or empty boxes;
  - every legend complete.
- **Language:** run the humanise pass (S9) on all sheet text.
- **Jury-sensitive sweep:** no code clauses, assumptions, open questions, "rev" notes, audit text or AI-sounding phrases.
- Run the consistency audit one last time.
- **Blind review R2** (`stages/S10_blind_review.md`) on the presentation PDF. Verify, fix and rebuild before delivery.
- Run `py -I <pack>/scripts/check_pdf.py 08_sheets/PDF/Presentation.pdf`. It must report 0 raster images on drawing pages and no tiny fonts.

## 5. Deliver
Send one chat message: the list of files with one line each, plus "Tell me anything you'd like changed." Keep the build scripts so changes take minutes.
