# S5: Single-source model and plans

## Why one model
In the source project's audit, these problems were found across the drawings:
- a stair with too few risers;
- a lift shaft that vanished on the upper floor;
- an escape stair drawn four different ways;
- three different roof heights;
- area typos.

They were all fixed by making every drawing read **one model** and computing every number from it. Never draw or type a value by hand that the model already holds.

## The model (`06_model/`), in metres, origin at a site corner
- `model_SITE.json`: boundary, setbacks, roads, gates, paving, planting, trees, parking bays (as block inserts), vehicle paths, outdoor furniture.
- `model_<LEVEL>.json` for each floor: walls (type, thickness, a/b points, z), openings (doors with hinge and swing, windows with sill/head), rooms (polygon, name, number, finish, area), stairs (flights, risers, treads, landings), lifts, voids, furniture (block, x, y, rotation).
- `model_STRUCT.json`: grid, columns (section, base, top), footings (centred under columns), plinth beams, floor beams, roof members, bracing, gutters/downpipes.
- Shared geometry functions (roof curves, levels) live in one Python module that every drawing script imports.
- Schema: `templates/model_schema.md`.

Build level by level, in small saves: grid → walls → openings → rooms → stairs/lift → furniture. Each piece goes in its own script or step so a crash loses little.

## Read before modelling
- `standards/technical_drawing_accuracy.md`: how stairs, frames, footings, walls and levels must be constructed.
- `standards/furniture_layout.md`: sizes, use zones, the placement order, orientation.
- Reuse `scripts/lib/blocks.py`: 164 true-size DXF blocks (furniture, sanitary, kitchen, doors, lift, trees, vehicles, people) with insertion conventions in its header. `scripts/lib/cadlib.py` holds the DXF helpers: walls, steel sections, grids, dimensions, levels, north arrow, scale bar, section marks, title block, render. Write new blocks only for items missing from the library, and add them to it.

## Structure (draw it before the furniture)
- Choose a grid with economic spans for the material. For example, a steel frame at 6–9 m.
- Upper-floor columns stack on lower ones. No column in a door, aisle, kitchen line, table or toilet cubicle.
- Show bracing or the moment-frame logic.
- The load path must read: roof → beam → column → base → footing, with **the footing directly under its column**.
- Stairs:
  - riser and tread from the code (e.g. non-residential riser ≤ 150, tread ≥ 300, ≤ 12–15 risers per flight);
  - floor-to-floor ÷ riser = an exact count;
  - landings and headroom checked.

## Plans (`07_drawings/`)
- **Always fully furnished.** Tables with chairs, counters with stools, kitchen equipment, WC fixtures, beds, parking markings, trees and paving. A plan without furniture is unacceptable.
- **Every room:**
  - has a door, or a stated open connection;
  - has a window or louvre on an outside wall (lift, riser and duct are exempt);
  - has a reason to be where it is.

  No room is sealed by walls on all sides.
- Furniture is realistic, oriented sensibly and clear of door swings. Never put a table or basin in a doorway.
- Place furniture in the order given in `furniture_layout.md` §1: fixed elements → doors and swings → circulation → fixtures → furniture → orientation → checks.
- Run `py -I <pack>/scripts/check_model.py 06_model` and `standards/planning_checklist.md`. Write the results to `07_drawings/CHECKS.md`. Fix every FAIL in the model before anyone sees the plan.
- **Presentation version:**
  - locked plan style (S3);
  - plain 2-digit room numbers with one legend block;
  - north arrow and scale bar;
  - no grid, dimensions or areas unless the style calls for them.
- **Technical version** (W2–W4): grid bubbles, three-tier dimensions, areas, levels and section marks.
- Outputs per drawing:
  - DXF (`standards/cad_dxf.md`);
  - vector PDF;
  - a small PNG preview, only for checking.

## Self-review before moving on
- Render the previews at about 100 dpi and look at them downscaled.
- Then zoom into 3–4 crops: stairs, toilets, kitchen, entrance.
- Check that the plan reads at a glance and that nothing overlaps.
