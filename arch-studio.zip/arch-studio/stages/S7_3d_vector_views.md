# S7: 3D views as vectors (and the render policy)

## Vector 3D views (part of every drawing workflow)
Generate these from the model with a projection script (matplotlib 3D-to-2D or your own axonometric transform). Export as SVG/PDF line drawings in the locked style: white clay, fine lines, one accent.
- **Aerial axo** of the whole site (SW and NE views if one view hides things).
- **Exploded floors axo:** floors pulled apart and joined by dashed lines, with zones or circulation highlighted in the accent colour.
- **Form-steps strip:** 3–5 small axos showing how the form was made.
- **Structure axo** (W2+): the frame alone in the accent colour.
- Optional:
  - a "visit" vignette strip (numbered small views along the user journey);
  - a section-perspective;
  - a roof see-through explainer aerial.
- Hidden-line handling: draw faces back to front with white fills (painter's order), so it reads cleanly without a renderer.

## When the user asks for renders
Reply in one short message, then ask:
> "Photoreal renders need a full 3D model (e.g. in Blender) and take much more time and cost. I can instead draw clean 3D views straight from your drawings now: aerial, exploded floors, a street-level line perspective. Which do you want?"

Options:
- "Vector 3D views now (Recommended)"
- "Prepare a 3D-model hand-off for a separate render phase"

## 3D hand-off (if chosen)
Do not model in this session. Create `10_3D_handoff/` containing:
- `START_HERE_3D.md` (goal, the model JSON paths, levels, materials list, camera wishes, the render style refs);
- the model JSONs;
- the DXFs;
- key PDFs;
- the locked style.

The 3D phase runs in a fresh session from that folder.
