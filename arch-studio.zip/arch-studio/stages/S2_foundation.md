# S2: The foundation (the most important stage)

The plans, sections, elevations, structure and sheets all rest on this. A mistake here is cheap to fix now and very expensive later.

**The lesson from the source project:** the first foundation looked excellent on paper: 84 spaces, 27 pages. When it was planned, though:
- about 20 rooms had no outside wall;
- toilets filled a whole wing;
- rooms like a dorm and a prayer room had no real use.

It was redone as a journey-based programme of about 665 m² instead of 1,457 m². **A foundation must be plannable, not just impressive.**

## Order of work (each step saves its own data file in `04_foundation/data/`)
1. **Users** (`users.json`): who comes, how they arrive, how long they stay, what they need first.
2. **Journeys** (`journeys.json`): a step-by-step visit for each user group, e.g. "Truck driver: park → wash → toilet → order → eat in the shade → rest → leave". Think as each user: nobody should have to go outside and around to wash hands after eating.
3. **Space list and triage.** List every space from the brief plus every space the journeys and codes need. Give each a tier:
   | Tier | Meaning | W1 Simple | W2 | W3/W4 |
   |---|---|---|---|---|
   | core | serves a core test of the brief, or the main use | keep | keep | keep |
   | essential | needed by code or by every user (toilets, exits, accessible WC, lift if needed, basic services) | keep | keep | keep |
   | peripheral | in the brief's list but rarely used here, and would hardly be noticed if absent | leave out or merge, shown to the user | keep or merge | keep |
   | technical | engineering plant (transformer, STP, HVAC plant, DG) | only if required, as one simple labelled room | keep, simply drawn | keep, fully |

   There is no limit on the number of spaces. The project's scale decides that.
4. **Area programme** (`programme.json`), the single source for all areas. Every space is sized by the method in `standards/space_standards_research.md`:
   - a unit test-fit;
   - a cross-check rate;
   - code minimums;
   - fixtures from the code AND a peak scenario.

   Every row records: area, basis, source, verified, tier, why. Include the designed open spaces (courts, gardens, outdoor seating, yards). Totals (built-up area, footprint, coverage, FAR, height) are checked against the envelope.
5. **Adjacency** (`relations.json`): a matrix with 3–4 grades (must be next to / near / no need / keep apart), plus bubbles for the site and each floor.
6. **Zoning** (`zoning.json`): only the zonings that matter for this site, usually:
   - functional;
   - public → private;
   - movement (one small panel per user group);
   - climate & surroundings.

   Merge fire, noise or day-night zoning into one diagram if relevant.
7. **Site test-fit** (`site_testfit.json`): footprint blocks, parking bays, the vehicle loop with turning radii, gates and setbacks at true scale. Check:
   - every daylight-needing room can sit on an outside wall;
   - toilets and kitchens can be ventilated;
   - coverage and height are within limits;
   - vehicles can turn.
8. **Services & safety list:** electrical, gas store, water, waste, exits, the accessible route.

## Style before drawing
Run S3 for: the programme table, bubble diagram, zoning diagram and sheet layout.

## The area programme table (in the Foundation PDF AND on the final programme sheet)
It is generated from `programme.json` and never retyped. One row per space, grouped by zone and floor, with zone subtotals and grand totals:

| Space | Qty | Unit size | Area (m²) | How we sized it | Source |
|---|---|---|---|---|---|
| Family dining | 72 seats | 4-seat unit 2.4 × 2.4 m | 110 | 18 table units + 1.2 m main aisle; checks at 1.5 m² per seat | Neufert; NBC 2016 |
| Women's toilets | 3 WC + 2 basins | cubicle 1.0 × 1.4 m | 18 | 1 WC per 50 seats, plus 3 WCs for a bus of 50 arriving at once | NBC 2016; peak calc |
| Accessible WC | 1 | 2.2 × 2.3 m | 5.1 | 1.5 m turning circle, transfer space beside the WC | Harmonised Guidelines 2021 |

Rules for the table:
- "How we sized it" is one short line in plain words, a sentence the student could say aloud.
- "Source" names the document only (Brief / bylaw city / NBC 2016 / Harmonised Guidelines 2021 / Neufert / Time-Saver / Metric Handbook / peak calc / test-fit). Write it short; no clause numbers on the sheet.
- Only verified sources appear. A row whose source is still "to verify" shows the test-fit basis only, until verified.
- Under the table, add one line of totals against the limits: built-up area, footprint, coverage %, FAR, height, parking provided vs required.
- Use the same table, restyled to the locked sheet style, on the final "Users & programme" sheet (S8). The student never has to copy anything across.

## PDFs (built from the data files; vector)
- `Foundation.pdf`.
  - W1: about 3–5 pages: site & climate; users, journeys & programme; bubbles & zoning; site test-fit & parking.
  - W2/W3: 8–12 pages, plus a 4-page summary.
  - W4: adds the area statement.
- `Sources_and_Standards.pdf` (for the user; never on sheets): where every area and rule came from (space_standards_research §5).
- `Triage.pdf` (one page, W1/W2): the spaces left out or merged, each with a one-line reason the student can say if asked.

Diagram rules: `standards/presentation_rules.md`.

## The warning (send this, then STOP)
> **Please check this carefully before we go on.** The area programme, journeys, bubbles and zoning are the foundation: every plan, section and elevation will be built on them. Changing a room, an area or a position now takes minutes. After we start the plans, the same change can mean redrawing most of the project.
> Please read pages X–Y (the programme table, the bubbles and the list of left-out spaces). Check:
> - Are any spaces missing or not needed?
> - Are the sizes right?
> - Do the numbers (seats, parking, users) match what you expect?
> - Is anything here something you could not explain to your jury?
> The Sources PDF shows where every number came from.

Options:
- "Approved, continue"
- "I want changes" (they type them)
- "Explain a space to me first"

For that last option, answer from the space guide (S9 format).

## After approval
- Freeze the data in `04_foundation/data/_approved_v1/`. Record the approval in `PROJECT_STATE.md`.
- If a later stage forces a change, say what and why, update the data, regenerate the PDFs and mark it v2. Never edit silently.
- After the form is fixed (S4), re-check the bubbles and zoning against it and update them if positions moved.
