# S9: Explainer guides (so the user owns the work)

The source user's words:
> "I should be able to defend it … rather than having blanked out."

The guides are separate PDFs for the user only. They never go on the presentation sheets. Write them in plain, friendly language, short.

## Guides (by workflow)
| Guide | W1 | W2 | W3 | W4 |
|---|---|---|---|---|
| Project guide (the story) | ✔ | ✔ | ✔ | design report instead |
| Space guide | ✔ | ✔ | ✔ | room data sheet instead |
| Furniture guide (non-obvious items) | – | ✔ | ✔ | – |
| Structure / roof guide | short section in the project guide | ✔ | ✔ | consultant notes |
| Jury Q&A prep | – | optional | ✔ | – |

## Project guide (3–6 pages)
- **"My project in 6 sentences".** Site → what the brief asked → the main idea → the form → how it works → how it's built. Written so the student can say it aloud.
- **How we got here:**
  - site and climate findings → design moves;
  - journeys → programme;
  - zoning → form;
  - why this option was chosen.
- **How it works:** the visit step by step, through the plans.
- **How it's built:**
  - the grid and column sizes;
  - how the roof is made and held;
  - how loads reach the ground;
  - rainwater;
  - the foundations.

  Use one simple diagram each.
- **Key numbers to remember:** site area, built-up area, coverage, height, seats, parking, grid spacing, floor heights.

## Space guide (one row per space)
- **What it is.** Simple spaces get one line. Technical spaces (electrical room, gas store, septic tank, compost pit, lift pit) get 2–3 lines.
- **Why this project needs it.**
- **Why it is placed here, and not elsewhere.**

## Furniture guide
Cover only items a juror might ask about, such as solar panels, yard equipment, charpoys, gas cages and the food lift. Do not cover obvious ones (tables, cars, people). Number each item to match the plans, and give one line on what it is and why it is there.

## Structure / roof guide (W2+)
- The structural system in plain words, with 4–6 small diagrams:
  - frame;
  - column base;
  - key joint;
  - eave;
  - load path;
  - drainage.
- "If they ask…" boxes with short answers.

## Humanise pass (apply to sheets AND guides)
- Write as a student would:
  - short sentences;
  - first person plural where natural ("we kept the kitchen on the outside wall so it gets air");
  - simple verbs.
- Remove AI-sounding phrasing: "seamlessly", "harmonious", "elevate", "a testament to", "nestled", "boasts", "delve", "in conclusion", stacked adjectives, rhetorical triads, and heavy em-dashes.
- Remove anything that invites a question the student can't answer: unexplained acronyms, code clause numbers, exotic jargon.
- No odd symbols (†, ‡, §, ◐), no bracket tags, no monospace.
