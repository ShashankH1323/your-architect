# S4: Form development (purpose first)

The form comes out of the approved foundation and a few clear **drivers**. It does not come from mashing shapes together.

In the source project, options like "a wheel on a roof" were rejected:
> "What's the purpose of this form? … It should not be random objects mashed up together. It should be architecturally defined, structurally defined."

The option the user chose had a story, a structure and a climate logic that all agreed.

## Steps
1. **Drivers** (`05_form/data/form_basis.json`). List 4–6 drivers ranked by strength. For example:
   - climate (shade the west, catch the monsoon wind);
   - site edges and arrivals;
   - the user journey;
   - structure / material (e.g. a steel brief);
   - local context story;
   - views.

   Also write 5–6 short **form rules**, e.g. "one roof shades everything", "families up and quiet", "the street is the spine".
2. **Precedent reasons.** From S1 precedents, take 2–3 reasons that fit here (e.g. "east–west long axis to cut heat gain"). Study the seed's `precedent_families` first.
   - **Personal intent:** if the user gave no idea at intake, ask ONE question first. Offer the seed's 3 `intents_offered` plus "describe your own". The user's intent leads option A. See `standards/originality.md` §2.
3. **Options:** 3 options (W1) or 3–5 (W2–W4). Each must:
   - start from a named driver and say so in one sentence;
   - read as ONE coherent building: no unrelated parts stuck together, no boxes popping out of roofs, no elements clipped through others;
   - use the whole site, with open spaces designed into the experience;
   - pass the checks: footprint/coverage, height, setbacks, FAR, parking/vehicle loop still working (re-run the site test-fit), and the programme fitting with every daylight-needing room on an outside wall;
   - include a simple structural idea (grid, spans, how the roof is held) that a student can explain.
4. **Form Options PDF** (one page per option + a comparison page):
   - a light vector axo;
   - a roof/massing plan;
   - a form-steps strip (3–5 small steps);
   - one line each on structure, climate and concept;
   - the check results in small type.

   Mark one option as recommended, with a one-line reason.
5. ★ **Ask:** "Which form should we develop?" Options A / B / C, plus "B, but changed…" via Other. Allow one refinement loop: refine the chosen option with the user's notes, and show it again on one page.
6. **Originality check:** write `form_family` and `footprint_sig` into `fingerprint.json`, then run `originality.py check`. If it's too similar to another project on the same brief, tell the user in one line and offer a variation (different roof, massing or open-space strategy) before locking.
7. **Lock:** write `05_form/data/form_final.json` (grid, levels, roof geometry, footprint), which S5 builds from. Re-check the zoning and bubbles against the final form and update the foundation if positions moved (S2 "After approval").

## Curves, parametric, special structures
These are welcome when they serve a driver and can be drawn and built. Keep the geometry formula-based so plans, sections and elevations can all compute it. In the source project, the roof ribbons came from a formula shared by every drawing script.
