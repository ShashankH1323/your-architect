# S10: Blind review (a fresh reviewer with zero context)

**Why.** The source project's drawings looked fine to the team that made them. A different AI that saw ONLY the final PDF quickly found stair, column and foundation errors. People who built something stop seeing its faults. So before the user sees any drawing set, a reviewer with **no project context** audits it like a strict external examiner.

This is a **safety net, not the plan**. The model, `technical_drawing_accuracy.md`, the checklists and `check_model.py` should already make the set right. The blind review should find little.

## When
- **R1:** after S5/S6, on the drawings PDF (plans, sections, elevations, structure) and before sheet composition. This is the most important run.
- **R2:** after S8, on the final presentation PDF, with a lighter focus on legibility, legends, typos and consistency.
- W3/W4: also on the technical set.

## How (keep it cheap)
1. Prepare the inputs. Use the PDF itself if the host lets a subagent read PDFs. Otherwise render each page to PNG at about 110 dpi, plus 150 dpi crops of: every stair (plan + section), the column/beam/footing junctions in sections, toilets, kitchen, entrance/ramp, and the roof eave.
2. Spawn ONE fresh subagent with the strongest available model. Pass it **only** the file paths and the prompt below. Do NOT pass the brief, the model, the decisions or the chat history. The point is a cold read.
3. Its output is a numbered issue list: page, location, what is wrong, why (rule), and severity (CRITICAL / MAJOR / MINOR).

## Reviewer prompt (use as is)
```
You are a strict external examiner for architectural construction drawings. You have never seen this project.
Read ONLY these files: <paths>. Judge them as a professional would at a design jury and a building-permit check.
Check, with exact page + location:
1. Stairs: riser count and height vs floor-to-floor, treads, flights shown in BOTH plan and section, landings, headroom, direction arrows, cut line.
2. Structure: columns continuous to beams, beams supported, slabs on beams, columns stacking between floors, every footing directly under its column, plinth beams under walls, bracing consistent.
3. Levels: every level tag consistent across all drawings; roof profile identical in sections and elevations.
4. Plans: every room has a door and daylight/ventilation; door swings clear; furniture clear of doors, columns, aisles; toilet and kitchen layouts workable; accessibility route.
5. Consistency: same stair/lift/shaft/opening positions across plans, sections, elevations, 3D views; section cut marks match the sections.
6. Presentation: every symbol/line type in a legend, no overlapping text, no codes, legible at print size.
Report ONLY real problems you can point to. No praise, no general advice. Format:
#  | severity (CRITICAL/MAJOR/MINOR) | page | where | problem | rule it breaks
If you find nothing in a category, write "none" for it.
```

## The lead's job after the review
1. **Verify each issue against the model.** Reviewers can be wrong; the source project's audit brief said "do not blindly assume every item is an error". Mark each one TRUE / FALSE / PARTLY with a one-line reason in `07_drawings/BLIND_REVIEW.md`.
2. Fix every TRUE issue **in the model or geometry module**, never in one drawing. Rebuild all affected drawings. Re-run `check_model.py` and the consistency audit.
3. If any CRITICAL issue was TRUE, run the blind review once more on the fixed pages only. Stop after 2 rounds; anything left goes into the summary for the lead's judgement.
4. Add any new kind of mistake found to `07_drawings/DECISIONS.md`, so later stages don't repeat it.
5. The user is never shown the review itself. They see a correct set. If something can't be fixed without a design change, ask the user one plain question.
