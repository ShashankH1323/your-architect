# S3: Style choice boards (used several times)

The user cannot describe a drawing style in words, but can point at a picture. So before any sheet type is produced for the first time, show **3 options** and let them pick.

## When to run it
| Moment | Board rows (one pick per row) |
|---|---|
| Before the foundation PDF | Programme table style · Bubble diagram style · Zoning diagram style |
| Before the form options PDF | Form-step / concept axo style. Optional; reuse the zoning pick if similar |
| Before drawings (after the form pick) | Plan style · Section style · Elevation style (one board, three rows) |
| Before the final sheets | Sheet composition (S8) |

## If the user supplied references for this type
- **One reference, or several in one style:** don't build a 3-option board. Extract the style. Show ONE small confirmation page with their reference next to a small vector sample in the extracted style (e.g. a 4 × 4 m room in plan). Ask: "I'll draw your plans like this. OK / adjust?"
- **Several different styles in their folder:** they are the board options. Label them A/B/C and ask which one (or which mix).
- **"Use my previous project":** confirm once for all types together, on one page with one sample per type.

## Changing references later
The user may add, replace or delete files in `03_references/user/<type>/` at any time and say "update the <type> style". Then:
1. re-extract only that type;
2. update `LOCKED_STYLE.md` and `INDEX.md`;
3. tell the user which outputs need a rebuild;
4. rebuild them only after their OK.

Other types are not touched.

## Building a board (`03_references/_boards/board_<topic>.pdf`)
- One A3 landscape page per row, or one page with 3 rows if it stays legible.
- Each option is a large crop of the reference, labelled **A / B / C**, with a 1-line plain description of the key traits. Examples:
  - "A: solid dark walls, furniture in thin lines, soft floor colours, one orange accent";
  - "B: outlined walls with hatch, black and white only, very technical";
  - "C: black walls, coloured room tints, trees in green".
- Make the three options **genuinely different**:
  - plans: filled/poché walls vs outlined/hatched walls vs black walls with coloured zones;
  - elevations: watercolour sky and trees vs pure line vs shaded with cast shadows.
- If the user's ideas (from intake) point to a style, make that option A.
- The board is a viewing aid; raster reference crops are fine here. Final drawings are always vector.
- Before showing it, run `originality.py check`. If shown references overlap with another project on the same brief, swap them for the next pool candidates. Put the options in the seed's `board_order`.
- Accent colour: offer the seed's `accent_first` as option A's accent. The user may pick any; record the locked accent in `fingerprint.json`.
- Open or attach it, then ask with the question tool: one question per row, options A / B / C. "Other" lets them mix: "plan B but with A's trees".

## Locking the pick (`03_references/LOCKED_STYLE.md`)
For each pick, write the extracted rules that drawing agents will follow:
- wall fill or outline, line weights (mm), colours (hex), floor tones;
- furniture line weight, tree style, people style;
- text font/size/case, numbering style, legend style;
- what to avoid.

Example lock, from the source project's plans:
> Cut walls solid warm dark grey #6B625C. Columns small dark circles. Floors pale with faint tile grids by finish. Furniture thin #4A4A4A lines (0.18 mm), white fill, realistic shapes. Trees lobed outline, sage #9DB08F at 35% alpha. Plain 2-digit room numbers inside rooms with one legend block below. No codes and no areas on the presentation plan. Title bottom-right in Arial bold, small north arrow and scale bar.

If the user said "like this but darker", write the exact adjustment, e.g. "+25% darker floor tones than the reference".

## Rules
- Never switch to a new visual style without a board. Small fixes (arrow clarity, naming) don't need one.
- If the user rejects all 3, ask one question: "What do you dislike most?", giving 3 typical reasons (too heavy / too light / too technical / too sketchy). Then build one new board.
- Don't oversimplify. Simplicity comes from fewer, larger labels, clear legends and thin lines. It never comes from cartoons, hand-drawn wobble or icons.
