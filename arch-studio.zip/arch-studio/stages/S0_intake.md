# S0: Intake (understand the brief, pick the workflow, collect the minimum)

Goal: get only the facts you cannot safely infer, in **at most two rounds** of questions. Never ask what the brief answers or what you can research.

## 1. Read the brief once and write `01_brief/brief_digest.md`
- Project type, users, site (location, size, shape, roads, levels).
- Every listed space and area.
- Rules (FAR/FSI, coverage, height, setbacks, parking).
- **Deliverables:** sheet count, size, orientation, drawings demanded, models, anonymity rules.
- Evaluation criteria and missing facts.

## 2. "What this brief is testing" (add this section to the digest)
Understand the brief truly before deciding anything. Name the **2–5 core tests**: what the brief exists to examine. Look for them in:
- the title and the sponsor;
- the evaluation criteria;
- repeated words;
- the mandatory drawings.

Examples:
- "a steel-intensive structure" (a steel-institute competition);
- "very different highway users";
- "climate response", "accessibility", "a large span", "heritage context".

**Core tests are never simplified away, on any route.** A Simple project still meets them fully, even when that needs a challenging element (a real steel roof structure, a long span). It only presents them clearly.

## 3. Round 1: the route (always ask; up to 4 questions in one go)
Exact wording: `templates/intake_questions.md`.
1. **Purpose** (sets strictness): Studio submission / Practice / Competition / Professional.
2. **Detail:**
   - **Balanced:** furnished drawings with modest technical depth.
   - **Simple:** keeps every core test and every space users will obviously look for. Leaves out peripheral, rarely-noticed or highly technical spaces. Very easy to explain.
   - **Detailed:** full technical depth.
3. **Scope:** Full sheets + guides / Up to drawings + DXF / Concept only.
4. **Presenter:** a student who must explain it / a team. Skip if Professional.

## 4. Round 2: the facts (only what the brief does not give)
- **Site location:** city plus a landmark or coordinates, or an uploaded Google Earth screenshot or site plan.
- **Site size and shape:** dimensions or area, road sides, north. Ask for a sketch or screenshot if irregular.
- **Open design wishes** (free text, optional). Show this hint:
  > "e.g. curved roof, local brick, courtyard, steel and glass, climate-responsive, inspired by the town's history, keep it low-cost…"
- **Your own style references (optional, skippable).** Ask whether they have references or a previous project to match (`templates/intake_questions.md` Q7b). If yes, create the per-type folders under `03_references/user/` and give the paths in one message. Every type they fill skips the search and the 3-option board (S3). Types they leave empty are searched as usual. Never force an upload.
- **Key numbers** the brief leaves open that change the programme (seats, users, vehicles, staff). Offer "Use typical numbers (recommended)" with the default stated.

Never ask about:
- standards, codes or space sizes (research them);
- styles (shown later as picture choices);
- tools or folder names;
- anything technical the user may not know.

If the user doesn't know an answer, take a stated default and note it in `PROJECT_STATE.md`.

## 5. Route table (write the result into PROJECT_STATE.md)
| Purpose | Detail | Scope = concept | Scope = drawings or full |
|---|---|---|---|
| Practice | Simple / Balanced | W0 | W1 |
| Practice | Detailed | W0 | W2 |
| Studio jury | Simple | W0 | W1 (with W2's brief check) |
| Studio jury | Balanced / Detailed | W0 | W2 |
| Competition | any | W0 (strict compliance) | W3 |
| Professional | any | W0 (strict compliance) | W4 |

Inside W3/W4, the detail level only changes how much extra is drawn. A "Simple" competition entry is minimal but fully compliant.

## 6. Design seed (silent)
Run `py -I <pack>/scripts/originality.py seed --project . --brief 01_brief/<brief>` (see `standards/originality.md`). It reads the registry: a shared one if `ARCH_STUDIO_REGISTRY` is set, otherwise the local one. It sets this project's starting points (reference band, accent, compositions, intents), so that several people on the same brief start in different places. Record the seed in PROJECT_STATE.

## 7. After intake (no extra question)
- Confirm the route in one line, e.g. "Route: Studio jury, Balanced, full sheets. I'll research the site and standards next and come back with the area programme."
- Start S1.
