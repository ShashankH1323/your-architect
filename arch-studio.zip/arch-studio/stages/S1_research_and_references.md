# S1: Research and references (internal; no user stops except the style boards)

Research is done **before** any design. It is the backbone, but most of it never appears on a sheet. Keep it in `02_research/` as short notes plus data files.

## 1. Site and context (`02_research/site_context.md`)
- Locate the site. If coordinates are unsure, confirm with ONE question and a satellite screenshot.
- Record:
  - the roads on each edge (type, traffic, noise);
  - neighbours and landmarks;
  - views;
  - where people and vehicles arrive from;
  - existing trees and levels if known.
- Identify the **four edges**: what each edge offers or demands, e.g. "south = highway noise; west = afternoon sun + monsoon wind".
- Note one short **local-context idea** that could inspire the form: an industry, craft, history or landscape. The source project's roof idea came from the city's cotton-mill history: "steel ribbons woven like cloth".

## 2. Climate (`02_research/climate.md` + `data/climate.csv`)
- Monthly temperature and rain, wind roses (seasonal), and the sun path at the site latitude.
- Translate the data into 3–5 design moves, e.g. "shade the west", "open to the monsoon breeze", "deep overhangs south".
- Use real data sources: met-department normals, Meteonorm/EPW files, or a sun-position calculation from the latitude. Never invent numbers.

## 3. Rules (`02_research/regulations_internal.md`)
- FAR/FSI, ground coverage, height, setbacks, parking norms, fire (exits, travel distance, stair widths), accessibility, and toilet fixture norms.
- If local rules are not found, use the nearest larger city's bylaws or the national code. Write which one was used and why, so the student can defend it.
- Values must agree with each other. A juror comparing two numbers must never find a contradiction.
- Produce one **envelope summary**: maximum footprint, height and setbacks. Only this summary may reach a sheet.

## 4. Space standards (`02_research/space_standards_internal.md`)
Follow `standards/space_standards_research.md`:
- the source hierarchy (brief → local bylaws → national code → accessibility → typology guidelines → Neufert / Time-Saver / Metric Handbook / Human Dimension);
- the unit test-fit method;
- honest citations.

Furniture and clearance values come from `standards/furniture_layout.md` with no extra search. Research only the typology- and location-specific items. The results feed `programme.json`, the planning checklist and the user's Sources PDF.

## 5. Precedents (`02_research/precedents.md`)
For form development (S4), pick 4–5 well-regarded buildings, of any type, that solved a similar driver (climate, site, structure, experience). For each, record **why** the form is what it is, in 2–3 lines. You are learning reasons, not copying shapes.

## 6. Presentation references (`03_references/`)
These are **style** references only: how good sheets look. They do not need to be the same building type; any excellent project sheet can be used.

### User references first (cheapest and closest to what they want)
- For each sheet type, check `03_references/user/<type>/` first. If it holds files, **study those and don't search that type.**
  - Read images at a modest size (about 1000 px long side).
  - Read PDFs one page at a time, rendered to PNG by script.
  - Never load a whole PDF portfolio at once.
- **Previous project** (Q7b option 3): list its files by script. Pick 1–2 sheets per type, and extract:
  - style (colours, line weights, fonts, wall fill);
  - layer names and block names from its DXFs, read by script only.

  Reuse its blocks if they are better than the pack's.
- If one image mixes several drawing types (a full sheet), crop the parts into the matching type folders as `U01_<what>.jpg` and note it in the index.
- If a user reference conflicts with the brief's sheet rules (size, orientation, anonymity), the brief wins. Tell the user in one line.

### Where to search (only for types with no user references)
Search in this order and stop once you have enough strong candidates:
1. ArchDaily and Dezeen drawings sections;
2. student portfolio collections: CEPT Portfolio, ArchiDiaries, SPA/NASA India annual entries, issuu portfolios;
3. award sheets (AIA COTE, RIBA President's Medals, international student competitions);
4. Behance and Pinterest boards for "architecture presentation sheet", "zoning diagram", "furnished floor plan", "section perspective", "elevation watercolour".

### How many and what to keep
- Prefer high-resolution full sheets.
- Rank a pool of **about 12 candidates** per category, varying the search terms and sources. Show 3, starting at the seed's `reference_pick_offset`, so people on the same brief see different references. Never show just the top 3 of a search.
- Record each shown file's hash in `fingerprint.json` → `refs`.

### Folders (one per sheet type; the user can see and change all of them)
```
03_references/
  user/                 the user's own references, one folder per type (never renamed or deleted by the agent)
    plan/ section/ elevation/ sheet_composition/ diagrams/ axo_3d/ details/ other/
  INDEX.md              per type: user files, found files, the locked pick, one line on what was taken from each
  sheets_composition/   C01_<source>_<descriptor>.jpg
  foundation_tables/    T01_...   (area programme tables, user tables)
  bubble/               B01_...
  zoning/               Z01_...   (plan zoning, axo zoning, exploded circulation)
  form/                 F01_...   (form-step strips, concept axos)
  plan/                 P01_...   (e.g. P01_plan_filled-walls_furnished_accent.jpg)
  section/              S01_...
  elevation/            E01_...
  axo_3d/               A01_...
  details/              D01_...
  _boards/              choice boards shown to the user (S3)
  sources.csv           file, url, project, author, what we like about it
  LOCKED_STYLE.md       the user's picks + extracted rules (colours, line weights, fonts)
```

### Naming
The file name says what it shows and what is good about it, e.g. `Z09_plan-zoning-arrow-legend.jpg`, `P05_plan_furnished_colour_accent.jpg`.

### Usage
References are for internal study. They never appear on final sheets. Credit them in `sources.csv`.

### Fallback
If downloads fail, use the presets in `standards/drawing_style_presets.md`. Draw a small vector sample of each preset for the board.

## Cost control
- Research subagents get one narrow topic each (climate, rules, references per category). Each saves its note when done.
- Don't read whole websites. Stop when the question is answered.
- A good reference search takes about 20 minutes per category, not hours.
