# W0: Concept sprint (foundation + form only)

**Who:** anyone who needs only the early stage:
- a desk crit;
- a concept review;
- the first submission of a studio;
- a quick feasibility check for a client.

## Stages
1. **S0 intake.** As usual. Strictness from Q1 still applies: competition or professional means a full rule check.
2. **S1.** Site, climate and rules research. References for the foundation sheets and for the form sheet only.
3. **S2 foundation.** The depth follows the Q2 detail level (W1, W2 or W3 depth). The foundation gate is still mandatory.
4. **S4 form.** 3–5 purpose-driven options with axo, roof plan and checks. ★ The user picks one; refine it once if asked.
5. **S7 (light).** A form-steps strip and one aerial axo of the chosen form.
6. **S8 (light).** 2–4 sheets. Use the composition gate only if the user wants presentation sheets. Otherwise deliver the Foundation + Form PDFs as they are.

## Deliverables
- `Foundation.pdf` + `Sources_and_Standards.pdf`
- `Form_Options.pdf`
- optional `Concept_Sheets.pdf`
- `PROJECT_STATE.md`, complete so that W1–W4 can continue later without redoing anything. The foundation data files are the hand-over.

## Hand-over note
End by telling the user, in one line, that the project can continue to drawings later from the same folder. Write the exact next step into `PROGRESS.md`.
