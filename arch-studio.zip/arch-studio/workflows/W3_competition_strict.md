# W3: Competition (strict brief)

**Who:** anyone entering a real competition. The brief is a contract:
- every listed space, area and deliverable;
- sheet size, count and orientation;
- anonymity rules and file naming.

Missing any one can disqualify the entry.

## Principles
- **Compliance matrix first.** Make `01_brief/compliance_matrix.csv`: requirement → where it is met (sheet / drawing / room id) → status. Update it at every stage. It stays internal.
- **No dropping brief items.** You may merge spaces only if the brief allows it. Otherwise provide them all, and size them to within ±5% of the brief, or to code minimums where the brief gives none.
- **Anonymity.** No names, institute or logos on sheets unless allowed. Use the brief's ID or "GROUP NO." field.
- **The concept must be strong and legible:**
  - one clear idea with a name;
  - a form-steps strip;
  - "six principles"-style short statements.

  Juries skim, so the idea must read from across the room.
- Evaluation criteria from the brief (e.g. steel use, sustainability, accessibility) each get visible proof on the sheets. Examples: a structure sheet for a steel brief; a climate and energy diagram for a sustainability brief.
- **Detail level** (Simple / Balanced / Detailed) only changes how much extra is drawn beyond what is required. It never changes compliance.

## Stages and depth
Use W2 depth, plus:
- **S1:** the full rule set (FAR, coverage, height, setbacks, parking, fire, accessibility), each with its source. Keep it internal (`02_research/regulations_internal.md`). Write a one-line envelope summary for the sheet.
- **S2:** the programme table lists brief area vs provided area. Write the brief compliance check into the foundation PDF's internal appendix, which is NOT part of the presentation.
- **S5/S6:** run the full planning checklist and the consistency audit twice: once at drafts, once before sheets.
- **S10:** blind review R1 + R2 are mandatory. A third round is allowed if CRITICAL issues remain.
- **S8:** sheet count, size and orientation exactly as the brief says. Check the file size limit and naming.
- **Sources:** `Sources_and_Standards.pdf` with every value verified. No "to verify" rows are allowed at export.
- **S9:** guides as W2. Also a 1-page "jury Q&A prep": 10 likely questions, each with a 2-sentence answer.

## Gates
Same as W2, plus:

★ **Compliance review before the final export.** Show a one-page compliance summary PDF (all ✔ or flagged) and ask: "Ready to export, or fix the flagged items?"

## Deliverables
As W2, plus:
- `compliance_matrix.csv`
- `Compliance_Summary.pdf` (internal)
- `Jury_QA.pdf`
- final files named exactly as the brief requires
