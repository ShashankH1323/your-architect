# W4: Professional / client work

**Who:** a practising architect or office. The output must survive a client review, an authority submission check and a consultant hand-off.

## Principles
- **Code compliance is explicit.** Local bylaws plus the national code (e.g. NBC India, IBC, Approved Documents), with clause references kept in a compliance register. That register is NOT on presentation sheets, but it IS delivered.
- **Two separate sets:**
  - a presentation set (minimal, client-facing);
  - a technical set: grids, three-tier dimensions, levels, areas, door/window schedules, room data, structural grid and footing plan, wall types, finishes legend.
- **Professional CAD.** AIA/NCS-style layer names (`A-WALL-EXTR`, `A-DOOR`, `S-COLS` …), title blocks with revision table, a sheet index, and model space in mm at 1:1.
- **Assumptions are listed.** Every assumed value (soil, loads, services capacity) goes in `00_admin/assumptions.md` and the technical set's notes sheet.
- Design choices still come from the user via the gates. The user here is the professional, so questions may use technical terms.

## Stages and depth
Use W2 depth, plus:
- **S1:** site survey inputs. Ask for the survey DXF/PDF if one exists. Collect: soil assumption, services points, the full regulations register.
- **S2:** a programme with gross and net areas, efficiency ratio, area statement (FAR/coverage computation), parking computation, occupant load and exits, toilet fixture computation.
- **S5:**
  - full technical plans;
  - door/window schedule (from the model);
  - room data sheet;
  - structural grid and column schedule;
  - foundation layout (indicative, for consultant coordination).
- **S6:** sections with full level chains, wall build-ups and roof build-up. Elevations with materials keyed to a legend.
- **S7:** vector views as W2. Renders are a separate scoped phase (S7 policy).
- **S8:** two sets.
  - Presentation (client): composition gate as usual.
  - Technical: a standard title block and sheet numbering (A0xx general, A1xx plans, A2xx sections, A3xx elevations, A4xx details, S1xx structure).
- **S9:** a design brief report (narrative + area statement) instead of student guides. Add a short explainer only if the user asks.

## Review
- Blind review R1 + R2 (S10).
- The compliance register has a source and a verified flag on every line (`space_standards_research.md` §3).

## Gates
Same as W2, plus:
- ★ **Technical set review** (drawings + schedules) before export.
- ★ **Revision log.** Every change after a gate is logged with a revision letter in the title block and in `00_admin/revisions.md`.

## Deliverables
- Presentation PDF
- Technical PDF set
- DXF set (professional layers, xref-ready: one DXF per drawing, shared origin)
- Schedules (CSV + PDF)
- Area statement
- Compliance register
- Assumptions list
