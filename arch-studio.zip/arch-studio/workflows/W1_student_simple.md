# W1: Student, simple (practice brief or lenient jury)

**Who:** a student practising on a brief (often a competition brief used as a studio exercise) where the jury will not audit every brief item.

**Goal:** a correct project the student can explain from memory, at whatever scale the brief sets.

## What "Simple" means (and doesn't)
- **It is not a space cap.** A large hospital or campus stays large. Simple never means "fewer than N rooms".
- **It keeps:**
  - every **core test** of the brief (S0 §2), even when that is challenging;
  - every space users will obviously look for;
  - every space the code requires (toilets, exits, accessibility, basic services).
- **It leaves out** spaces that are peripheral to this project's context, rarely used, and would hardly be noticed if absent. The source example: in a highway cafe brief, a prayer room or a dorm can go.
- **It keeps very technical spaces only where required.** It shows them as one simple labelled room (e.g. "Electrical room") instead of a detailed plant layout. Examples are transformer yards, STP blower rooms and HVAC plant.
- **It merges** small related rooms into one zoned room where that is normal practice, e.g. one kitchen with zones instead of five kitchen rooms.
- Every leave-out is shown to the user at the foundation gate (S2 triage table). Nothing is dropped silently.
- **It does not reduce accuracy.** Stairs, doors, clearances, structure and load path are exactly as rigorous as in W4.
- **It does not reduce drawing quality.** Simple = minimal and self-explanatory, never sketchy.

## Principles
- Design from the user journey. Example: "Park → wash hands → toilet if needed → order → eat → leave; families go upstairs". Every space sits on a journey or on a code requirement.
- Explain complexity rather than avoid it. If a core test needs a complex element, keep it, and explain it in the project guide with simple diagrams.

## Stages and depth
| Stage | Do | Keep light |
|---|---|---|
| S1 | Site, climate, key bylaws, standards per space (`space_standards_research.md`), references (3 per sheet type) | Exhaustive code research beyond what the programme needs |
| S2 | Users, journeys, programme (all tiers triaged), adjacency, bubbles per floor + site, 3–4 zoning diagrams, site test-fit, Sources PDF | Separate fire / noise / day-night sheets (merge them into one if relevant) |
| ★ gate | Foundation approval | |
| S4 | 3 options, each from a stated driver | |
| S5 | Site plan, all floor plans furnished, roof plan, column grid | Technical plan set (only if asked) |
| S6 | Sections that explain the building (long, cross, through the stair), 4 elevations | Details beyond what the core tests need |
| S7 | Aerial axo, exploded floors, form-steps strip | Renders (S7 policy) |
| S10 | Blind review R1 (+ R2 on sheets) | |
| S8 | As many sheets as the content needs; usually 4–8 | |
| S9 | Project guide, space guide; a structure guide if a core test is structural | |

## Gates (★ = stop and wait)
1. Intake
2. ★ Foundation style
3. ★ **Foundation approval**
4. ★ Form pick
5. ★ Drawing styles (plans / sections / elevations, one board)
6. ★ Composition
7. Final set

## Deliverables
- Foundation PDF + Sources_and_Standards PDF
- Form Options PDF
- Drawings PDF
- DXF (simple layer names)
- Presentation PDF
- Guides
