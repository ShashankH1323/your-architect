# W2: Student, balanced (studio jury)

**Who:** a student submitting to a studio jury that reads the brief but values clarity and design logic over exhaustive compliance.

This is the **reference workflow**. The AD-6 "Woven Street" project that this pack comes from finished on this route: a 10-sheet set, DXF, and 4 guides.

## Principles
- Every brief item is **accounted for**:
  - provided as a room;
  - merged into another space (say where);
  - or dropped with the user's OK and a reason.

  Keep `04_foundation/notes/brief_check_internal.md` with one line per brief item. It is internal and never goes on a sheet.
- Use the journey-first programme of W1, sized to codes and peak loads. Example: toilets from code AND from a bus-arrival peak.
- Every room has a door, daylight or ventilation on an outside wall, and a reason to exist in that spot. Rooms must not end up deep in the plan with no window; that failure forced a full redo on the source project.
- Use the whole site. Open spaces (courts, gardens, shaded outdoor seating) are designed as part of the building experience, not leftovers.
- Some technical depth is welcome: a structure sheet, a part plan + section detail. Keep it presented simply, and explain it in a guide.

## Stages and depth
| Stage | Depth |
|---|---|
| S1 | Site and context; climate charts (temperature/rain, wind roses, sun path); bylaws; user groups; precedent forms (4–5 buildings, with why they look the way they do); references (3 per sheet type) |
| S2 | Space triage (core / essential / peripheral / technical; W2 keeps or merges peripheral); every area sized per `space_standards_research.md`; users table; step-by-step visit journeys; programme with areas (indoor + open spaces); adjacency matrix; bubbles (site + each floor); zoning: functional, public→private, movement (one panel per user group), climate & surroundings; parking count; services & safety list; site test-fit |
| ★ gate | Foundation approval |
| S4 | 3–5 form options from stated drivers; the pick may be refined once ("keep B, use more of the site") |
| S5 | Single-source model; column grid; site, floor and roof plans, fully furnished; plan checklist |
| S6 | 3 sections (long, cross, through the stair/core), each with a small key plan; 4 elevations |
| S7 | Aerial axo, exploded floors with circulation, form-steps strip, a section-perspective or "a visit" vignette strip; optional explainer aerials if elevations are hard to read |
| S10 | Blind review R1 on the drawings and R2 on the sheets; verify, fix in the model, rebuild |
| S8 | 8–10 sheets. Source order: 01 Site & climate, 02 Users & programme, 03 Organisation & zoning, 04 Concept & form, 05 Site plan & open spaces, 06 Plans, 07 Section & experience, 08 Sections, 09 Elevations, 10 Structure & details |
| S9 | Project guide, space guide, furniture guide (non-obvious items only), structure/roof guide |

## Gates
1. Intake
2. ★ Foundation style
3. ★ **Foundation approval**
4. ★ Form pick (plus one refinement loop if asked)
5. ★ Drawing styles (plans / sections / elevations board)
6. ★ Composition
7. Final set

An optional quick "plans preview" stop is allowed only if the form changed a lot after the foundation. Ask: "Plans are drafted. See them now (recommended if you want to change room positions) or continue to the full set?"

## Deliverables
- Foundation PDF (detailed, about 8–12 pages)
- Foundation Summary (4 pages)
- `Sources_and_Standards.pdf`
- `Triage.pdf` (spaces merged or left out, with reasons)
- Form Options PDF
- Drawings PDF + technical PDF (grid, dimensions, areas)
- DXF (standard layer names)
- Presentation PDF
- Guides (S9)
