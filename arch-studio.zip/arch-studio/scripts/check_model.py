"""check_model.py - automated plan / structure checks on the single-source model (templates/model_schema.md).

    py -I check_model.py <model_dir> [--riser-max 0.15] [--tread-min 0.30] [--flight-max 15]
                                     [--ext-riser-max 0.19] [--ext-tread-min 0.25] [--md CHECKS.md]
Set the limits from the project's code. Stairs whose id/name/type contains escape/external/fire use the ext limits.

Reads every *.json in <model_dir>: files with "walls" are floor levels, the file with "columns" is the structure.
Prints PASS / WARN / FAIL lines and a summary; exit code 1 if anything FAILs. Needs shapely.
Coordinates in metres. Only geometry that the model holds is checked - drawing-only errors still need the
consistency audit and the blind review.
"""
import argparse
import glob
import json
import math
import os
import sys

from shapely.geometry import LineString, Point, Polygon, box
from shapely import affinity

EXEMPT_DAYLIGHT = ("lift", "shaft", "duct", "riser", "cold", "store", "stair", "pit", "void", "court", "plaza",
                   "terrace", "street", "garden", "yard", "parking", "under-stair", "landing", "lobby")
LIGHT_KINDS = ("window", "glazing", "louvre", "opening", "curtain")
EXT_TYPES = ("ext", "curtain", "screen", "glaz")
NOT_A_ROOM = ("open to", "void", "roof over", "roof above", "below")   # outlines stored as rooms, not enterable
OVERHEAD = ("HOOD", "TREE", "CANOPY", "RUG", "OVERHEAD", "PERGOLA")   # may legally overlap what is under them

R = []  # (status, level, check, message)


def rep(status, lvl, chk, msg):
    R.append((status, lvl, chk, msg))


def poly(pts):
    p = Polygon(pts)
    return p if p.is_valid else p.buffer(0)


def wall_shape(w):
    t = w.get("t", 0.2)
    return LineString([w["a"], w["b"]]).buffer(t / 2, cap_style=2)


def furn_fp(f):
    if f.get("fp"):
        return poly(f["fp"])
    if "w" in f and "d" in f:
        b = box(-f["w"] / 2, -f["d"] / 2, f["w"] / 2, f["d"] / 2)
        return affinity.translate(affinity.rotate(b, f.get("rot", 0), origin=(0, 0)), f["x"], f["y"])
    return None


def swing_shape(o):
    """Quarter-circle sector swept by each door leaf (hinge -> opens_to gives the open leaf direction)."""
    d = o.get("door") or {}
    shapes = []
    for hk, ok in (("hinge", "opens_to"), ("hinge2", "opens_to2")):
        if hk not in d or ok not in d:
            continue
        h, op = d[hk], d[ok]
        leaves = d.get("leaves", 1)
        width = math.dist(o["a"], o["b"]) / max(leaves, 1)
        if d.get("type") == "sliding":
            continue
        a_open = math.atan2(op[1] - h[1], op[0] - h[0])
        far = o["b"] if math.dist(h, o["a"]) < math.dist(h, o["b"]) else o["a"]
        a_closed = math.atan2(far[1] - h[1], far[0] - h[0])
        da = (a_open - a_closed + math.pi) % (2 * math.pi) - math.pi
        pts = [tuple(h)] + [(h[0] + width * math.cos(a_closed + da * k / 12), h[1] + width * math.sin(a_closed + da * k / 12))
                            for k in range(13)]
        shapes.append(Polygon(pts).buffer(0))
    return shapes


def check_level(L, lvl):
    walls = {w["id"]: w for w in L.get("walls", [])}
    wall_geo = {k: wall_shape(w) for k, w in walls.items()}
    opens = L.get("openings", [])
    rooms = L.get("rooms", [])

    # rooms: area, door, daylight
    for r in rooms:
        rp = poly(r["poly"])
        name = (r.get("name") or r.get("id", "?")).lower()
        if "area" in r and rp.area > 0:
            dev = abs(rp.area - r["area"]) / rp.area
            rep("PASS" if dev <= 0.05 else "FAIL", lvl, "room area", f"{name}: stated {r['area']:.1f} vs polygon {rp.area:.1f} m2")
        edge = rp.exterior
        if any(k in name for k in NOT_A_ROOM):
            continue
        near = [o for o in opens if edge.distance(LineString([o["a"], o["b"]]).centroid) <= walls.get(o.get("wall"), {}).get("t", 0.25) / 2 + 0.15]
        has_door = r.get("open") or any(o.get("kind") in ("door", "opening", "lift_door", "hatch") for o in near)
        rep("PASS" if has_door else "FAIL", lvl, "room door", f"{name}: {'has an entrance' if has_door else 'NO door or opening on its edge'}")
        if not any(k in name for k in EXEMPT_DAYLIGHT) and not r.get("open"):
            lit = any(o.get("kind") in LIGHT_KINDS and str(walls.get(o.get("wall"), {}).get("type", "")).startswith(EXT_TYPES) for o in near)
            rep("PASS" if lit else "WARN", lvl, "room daylight", f"{name}: {'window/louvre on an outside wall' if lit else 'no window or louvre on an outside wall found'}")

    # furniture vs walls, door swings, each other, lifts
    furn = [(f, furn_fp(f)) for f in L.get("furniture", []) + L.get("fixtures", [])]
    furn = [(f, g) for f, g in furn if g is not None and not g.is_empty]
    swings = [(o["id"], s) for o in opens if o.get("kind") == "door" for s in swing_shape(o)]
    lifts = [poly(l["poly"]) for l in L.get("lifts", []) if l.get("poly")]
    bad = 0
    for f, g in furn:
        tag = f"{f.get('block', '?')} @({f.get('x', 0):.2f},{f.get('y', 0):.2f})"
        core = g.buffer(-0.02)
        for wid, wg in wall_geo.items():
            if core.intersects(wg) and core.intersection(wg).area > 0.01:
                rep("FAIL", lvl, "furniture vs wall", f"{tag} overlaps wall {wid}"); bad += 1; break
        for did, sg in swings:
            if core.intersects(sg) and core.intersection(sg).area > 0.01:
                rep("FAIL", lvl, "furniture vs door swing", f"{tag} inside the swing of {did}"); bad += 1; break
        for lp in lifts:
            if core.intersects(lp):
                rep("FAIL", lvl, "furniture in lift", f"{tag} inside a lift shaft"); bad += 1
    for i in range(len(furn)):
        for j in range(i + 1, len(furn)):
            a, b = furn[i][1], furn[j][1]
            names = f"{furn[i][0].get('block', '')} {furn[j][0].get('block', '')}".upper()
            if any(k in names for k in OVERHEAD):
                continue
            inter = a.intersection(b).area if a.intersects(b) else 0
            if inter >= 0.9 * min(a.area, b.area):      # one sits on / in the other (basin in a counter)
                continue
            if inter > 0.02:
                rep("WARN", lvl, "furniture overlap", f"{furn[i][0].get('block')} and {furn[j][0].get('block')} overlap "
                    f"{a.intersection(b).area:.2f} m2 (fine only if one sits on the other, e.g. a rug)")
    if furn and not bad:
        rep("PASS", lvl, "furniture placement", f"{len(furn)} items clear of walls, door swings and lifts")

    # door swing vs door swing
    for i in range(len(swings)):
        for j in range(i + 1, len(swings)):
            if swings[i][0] != swings[j][0] and swings[i][1].intersection(swings[j][1]).area > 0.02:
                rep("FAIL", lvl, "door swings clash", f"{swings[i][0]} and {swings[j][0]}")


def check_stairs(levels, a):
    by_ffl = sorted(levels, key=lambda L: L.get("ffl", 0))
    for idx, L in enumerate(by_ffl):
        for st in L.get("stairs", []):
            fl = st.get("flights", [])
            if not fl or "riser" not in fl[0]:
                continue
            sid = st.get("id", "?")
            ext = any(k in f"{st.get('type', '')} {st.get('name', '')} {sid}".lower() for k in ("escape", "external", "fire"))
            rmax, tmin = (a.ext_riser_max, a.ext_tread_min) if ext else (a.riser_max, a.tread_min)
            total = 0.0
            for f in fl:
                r, t, n = f["riser"], f.get("tread", 0), f["risers"]
                total += r * n
                ok = r <= rmax + 1e-6 and t >= tmin - 1e-6 and n <= a.flight_max and 0.55 <= 2 * r + t <= 0.70
                rep("PASS" if ok else "FAIL", L["level"], "stair flight",
                    f"{sid}/{f.get('id', '?')}: {n} risers x {r * 1000:.0f} / tread {t * 1000:.0f} (2R+T {(2 * r + t) * 1000:.0f})")
                if "z_bottom" in f and "z_top" in f and abs((f["z_top"] - f["z_bottom"]) - r * n) > 0.005:
                    rep("FAIL", L["level"], "stair flight rise", f"{sid}/{f.get('id')}: risers give {r * n:.3f} but z span is {f['z_top'] - f['z_bottom']:.3f}")
            if idx + 1 < len(by_ffl) and all("z_bottom" in f for f in fl) and min(f["z_bottom"] for f in fl) <= L.get("ffl", 0) + 0.01:
                f2f = by_ffl[idx + 1]["ffl"] - L["ffl"]
                rep("PASS" if abs(total - f2f) <= 0.005 else "FAIL", L["level"], "stair total rise",
                    f"{sid}: risers sum {total:.3f} vs floor-to-floor {f2f:.3f}")


def check_vertical(levels):
    lifts = {}
    for L in levels:
        for lf in L.get("lifts", []):
            if lf.get("poly"):
                c = poly(lf["poly"]).centroid
                lifts.setdefault(lf.get("id", lf.get("kind", "lift")), []).append((L["level"], c))
    for lid, cs in lifts.items():
        drift = max(c.distance(cs[0][1]) for _, c in cs)
        rep("PASS" if drift <= 0.05 else "FAIL", "ALL", "lift stacks", f"{lid}: on {[l for l, _ in cs]}, max offset {drift:.2f} m")


def check_struct(S, levels):
    cols = S.get("columns", [])
    foots = S.get("footings", [])
    fby = {f.get("col"): f for f in foots if f.get("col")}
    off = 0
    for c in cols:
        f = fby.get(c.get("id"))
        if f is None:
            f = min(foots, key=lambda q: math.dist((q["x"], q["y"]), (c["x"], c["y"])), default=None)
        if f is None:
            rep("FAIL", "STRUCT", "footing", f"column {c.get('id')} has no footing"); off += 1; continue
        d = math.dist((f["x"], f["y"]), (c["x"], c["y"]))
        combined = str(f.get("type", "")).lower() in ("combined", "raft", "strip", "mat")
        if d > 0.05 and not combined:
            rep("FAIL", "STRUCT", "footing under column", f"{c.get('id')}: footing centre is {d:.2f} m off the column"); off += 1
        if "z_base" in c and "z_top" in f and c["z_base"] < f["z_top"] - 0.01:
            rep("FAIL", "STRUCT", "column base", f"{c.get('id')}: base {c['z_base']} below footing top {f['z_top']}"); off += 1
    if cols and not off:
        rep("PASS", "STRUCT", "load path", f"{len(cols)} columns, each on its own centred footing (or a labelled combined one)")
    # columns vs door openings on every level
    for L in levels:
        z = L.get("ffl", 0)
        for o in L.get("openings", []):
            if o.get("kind") != "door":
                continue
            seg = LineString([o["a"], o["b"]])
            for c in cols:
                if c.get("z_base", -9) <= z + 0.1 <= c.get("z_top", 99):
                    r = c.get("dia", 0.3) / 2
                    if seg.distance(Point(c["x"], c["y"])) < r + 0.15 and seg.length > 0:
                        rep("FAIL", L["level"], "column in door", f"column {c.get('id')} within 0.15 m of door {o['id']}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("model_dir")
    ap.add_argument("--riser-max", type=float, default=0.15)
    ap.add_argument("--tread-min", type=float, default=0.30)
    ap.add_argument("--flight-max", type=int, default=15)
    ap.add_argument("--ext-riser-max", type=float, default=0.19, help="external / escape stairs (named so in the model)")
    ap.add_argument("--ext-tread-min", type=float, default=0.25)
    ap.add_argument("--md", default=None, help="append a markdown report to this file")
    a = ap.parse_args()
    levels, struct = [], None
    for fn in sorted(glob.glob(os.path.join(a.model_dir, "*.json"))):
        d = json.load(open(fn, encoding="utf-8"))
        if isinstance(d, dict) and "walls" in d:
            d.setdefault("level", os.path.basename(fn)); levels.append(d)
        elif isinstance(d, dict) and "columns" in d:
            struct = d
    for L in levels:
        check_level(L, L["level"])
    check_stairs(levels, a)
    check_vertical(levels)
    if struct:
        check_struct(struct, levels)
    n = {s: sum(1 for r in R if r[0] == s) for s in ("PASS", "WARN", "FAIL")}
    order = {"FAIL": 0, "WARN": 1, "PASS": 2}
    lines = [f"{s:4} | {l:6} | {c:24} | {m}" for s, l, c, m in sorted(R, key=lambda r: order[r[0]])]
    summary = f"SUMMARY: {n['FAIL']} FAIL, {n['WARN']} WARN, {n['PASS']} PASS ({len(levels)} levels{', structure' if struct else ''})"
    print("\n".join(l for l in lines if not l.startswith("PASS")))
    print(summary)
    if a.md:
        with open(a.md, "a", encoding="utf-8") as fh:
            fh.write("\n## check_model.py\n" + summary + "\n\n" + "\n".join(lines) + "\n")
    sys.exit(1 if n["FAIL"] else 0)


if __name__ == "__main__":
    main()
