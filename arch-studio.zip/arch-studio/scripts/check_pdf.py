"""check_pdf.py - presentation PDF health check (vector, fonts, symbols, legibility). Needs pymupdf.

    py -I check_pdf.py <file.pdf> [--previews <dir> --dpi 50] [--strict]

Per page: raster image count and how much of the page they cover, smallest text size, fonts used.
FAIL: monospace / Arial Black fonts, odd marker symbols, and (with --strict) any raster image on the page.
WARN: raster images covering > 15% of a page (drawings must be vector; photos and reference crops are fine),
      text under 5 pt (unreadable in print - or text hidden by a crop; check the preview).
--previews renders small PNGs for a quick visual check (look at them downscaled; never read the PDF itself into context).
"""
import argparse
import os
import sys

import pymupdf

BAD_FONTS = ("consola", "courier", "mono", "arialblack", "arial-black", "black")
ODD = set("†‡§◐◑◒◓■□▪▫★☆✓✔✗✘")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdf")
    ap.add_argument("--previews")
    ap.add_argument("--dpi", type=int, default=50)
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args()
    doc = pymupdf.open(a.pdf)
    fails = warns = 0
    for pno, page in enumerate(doc, 1):
        area = page.rect.width * page.rect.height
        imgs = page.get_images(full=True)
        cover = 0.0
        for im in imgs:
            for r in page.get_image_rects(im[0]):
                cover += (r & page.rect).width * (r & page.rect).height
        cover = min(cover / area, 1.0) if area else 0
        fonts, sizes, odd = set(), [], set()
        for b in page.get_text("dict")["blocks"]:
            for l in b.get("lines", []):
                for s in l["spans"]:
                    if s["text"].strip():
                        fonts.add(s["font"]); sizes.append(s["size"])
                        odd |= {ch for ch in s["text"] if ch in ODD}
        bad = sorted(f for f in fonts if any(k in f.lower().replace(" ", "") for k in BAD_FONTS))
        small = min(sizes) if sizes else None
        status = "PASS"
        notes = [f"{len(imgs)} raster ({cover:.0%} of page)", f"min text {small:.1f} pt" if small else "no text"]
        if bad:
            status = "FAIL"; notes.append(f"fonts not allowed: {bad}")
        if odd:
            status = "FAIL"; notes.append(f"odd symbols: {''.join(sorted(odd))}")
        tiny = sum(1 for s in sizes if s < 5)
        if imgs and a.strict:
            status = "FAIL"
        elif cover > 0.15 and status == "PASS":
            status = "WARN"; notes.append("large raster area - drawings must be vector (SVG/PDF), photos are fine")
        if tiny:
            status = "WARN" if status == "PASS" else status
            notes.append(f"{tiny} text spans under 5 pt (unreadable in print, or hidden by a crop - check the preview)")
        fails += status == "FAIL"; warns += status == "WARN"
        print(f"{status:4} | page {pno:2} | " + "; ".join(notes) + f" | fonts: {', '.join(sorted(fonts))[:120]}")
        if a.previews:
            os.makedirs(a.previews, exist_ok=True)
            page.get_pixmap(dpi=a.dpi).save(os.path.join(a.previews, f"p{pno:02d}.png"))
    print(f"SUMMARY: {fails} FAIL, {warns} WARN, {len(doc)} pages")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
