"""originality.py - design seed, fingerprint and duplicate check across projects (standards/originality.md).

    py -I originality.py seed  --project <project_dir> [--brief <brief.pdf|txt>]
    py -I originality.py check <project_dir>/00_admin/fingerprint.json [--register]

seed : creates 00_admin/fingerprint.json with a random seed and the seed-driven choices
       (reference pick offsets, board orders, accent family, composition families, precedent families, intents).
       Accents, compositions and intents already used by registered projects on the same brief are offered last.
Record the final picks in fingerprint.json using the exact strings from the lists below (accent = an ACCENTS entry,
composition = a COMPOSITIONS entry, form_family = the intent / family name), plus refs (file sha256[:12]),
footprint_sig {aspect, compact, corners, orient} and plan_topology ["entry:S", "core:W", ...].
check: compares the fingerprint with every registry entry for the SAME brief and prints similarity 0-1
       (>= 0.75 = too similar). --register appends / updates this project in the registry.
Registry: $ARCH_STUDIO_REGISTRY (shared path) or ~/.arch-studio/registry.jsonl. Stores hashes and signatures only.
"""
import argparse
import hashlib
import json
import os
import random
import secrets
import sys
import time

ACCENTS = ["burnt orange #D35400", "teal #127C7A", "oxblood #7B1E2B", "ochre #C08A1E", "cobalt #2453A6",
           "olive #6B7A2A", "terracotta #B5523B", "plum #6E3B6B", "slate green #3E6B5C", "rust #9C4A1A"]
COMPOSITIONS = ["hero + ordered grid + text column", "horizontal bands", "central plan portrait",
                "two-column narrative (left story, right drawings)", "modular tiles with one full-bleed section"]
PRECEDENT_FAMILIES = ["climate-led", "structure-led", "landscape-led", "street / urban-led", "craft & material-led",
                      "courtyard typologies", "pavilion typologies", "linear / spine typologies"]
INTENTS = ["a shaded street", "one big roof", "pavilions in a garden", "a courtyard building", "a stepped terrace",
           "a bridge between two parts", "a wall that shelters", "a cluster of small volumes"]
STORY_ANGLES = ["history", "craft", "landscape", "industry", "climate"]
THRESHOLD = 0.75


def registry_path():
    p = os.environ.get("ARCH_STUDIO_REGISTRY") or os.path.join(os.path.expanduser("~"), ".arch-studio", "registry.jsonl")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p


def brief_key(path):
    if not path or not os.path.exists(path):
        return None
    if path.lower().endswith(".pdf"):
        import pymupdf
        text = "".join(p.get_text() for p in pymupdf.open(path))
    else:
        text = open(path, encoding="utf-8", errors="ignore").read()
    norm = " ".join(text.lower().split())
    return hashlib.sha256(norm.encode()).hexdigest()[:16]


def cmd_seed(a):
    adm = os.path.join(a.project, "00_admin")
    os.makedirs(adm, exist_ok=True)
    fp_path = os.path.join(adm, "fingerprint.json")
    if os.path.exists(fp_path):
        print(f"seed exists, reusing: {fp_path}"); print(open(fp_path).read()); return
    seed = secrets.randbits(32)
    rnd = random.Random(seed)
    bkey = brief_key(a.brief)
    # projects already registered on the same brief: offer what they did NOT use first
    reg = registry_path()
    rows = [json.loads(l) for l in open(reg, encoding="utf-8")] if os.path.exists(reg) else []
    same = [r for r in rows if bkey and r.get("brief_key") == bkey]
    used = {k: {r.get(k) for r in same if r.get(k)} for k in ("accent", "composition", "form_family")}

    def fresh(pool, used_vals, n):
        free = [x for x in pool if x not in used_vals]
        pick = rnd.sample(free, min(n, len(free)))
        return pick + rnd.sample([x for x in pool if x not in pick], n - len(pick))

    fp = {
        "seed": seed, "created": time.strftime("%Y-%m-%d"), "project_id": secrets.token_hex(6),
        "brief_key": bkey, "site_key": None, "projects_on_same_brief": len(same),
        "choices": {
            # start index into the ranked pool of 12 candidates: each project on the brief gets its own band of 3
            "reference_pick_offset": (3 * len(same) + rnd.randrange(0, 3)) % 12,
            "board_order": rnd.sample(["A", "B", "C"], 3),
            "accent_first": fresh(ACCENTS, used["accent"], 1)[0],
            "composition_families": fresh(COMPOSITIONS, used["composition"], 3),
            "precedent_families": rnd.sample(PRECEDENT_FAMILIES, 3),
            "intents_offered": fresh(INTENTS, used["form_family"], 3),
            "story_angle": rnd.choice(STORY_ANGLES),
        },
        "refs": [], "accent": None, "composition": None, "form_family": None,
        "footprint_sig": None, "plan_topology": None,
    }
    json.dump(fp, open(fp_path, "w"), indent=1)
    print(json.dumps(fp, indent=1))


def _jacc(a, b):
    a, b = set(a or []), set(b or [])
    return len(a & b) / len(a | b) if a and b else 0.0


def _num_sim(a, b):
    """footprint signature: dict of numbers (aspect, compactness, n_corners, orientation_deg, coverage)."""
    if not a or not b:
        return 0.0
    keys = set(a) & set(b)
    if not keys:
        return 0.0
    s = 0.0
    for k in keys:
        x, y = float(a[k]), float(b[k])
        s += 1 - min(abs(x - y) / (max(abs(x), abs(y), 1e-9)), 1)
    return s / len(keys)


def similarity(p, q):
    parts = [
        (0.15, _jacc(p.get("refs"), q.get("refs"))),
        (0.10, float(p.get("accent") is not None and p.get("accent") == q.get("accent"))),
        (0.15, float(p.get("composition") is not None and p.get("composition") == q.get("composition"))),
        (0.20, float(p.get("form_family") is not None and p.get("form_family") == q.get("form_family"))),
        (0.15, _num_sim(p.get("footprint_sig"), q.get("footprint_sig"))),
        (0.25, _jacc(p.get("plan_topology"), q.get("plan_topology"))),   # e.g. ["entry:S", "core:W", "kitchen-dining:adj", ...]
    ]
    # site_key is stored but not scored: a shared site is normal in a studio and is not copying by itself
    return round(sum(w * v for w, v in parts) / sum(w for w, _ in parts), 3)


def cmd_check(a):
    fp = json.load(open(a.fingerprint))
    reg = registry_path()
    rows = [json.loads(l) for l in open(reg, encoding="utf-8")] if os.path.exists(reg) else []
    others = [r for r in rows if r.get("project_id") != fp.get("project_id") and r.get("brief_key") and r.get("brief_key") == fp.get("brief_key")]
    worst = 0.0
    for r in others:
        s = similarity(fp, r)
        worst = max(worst, s)
        flag = "TOO SIMILAR" if s >= THRESHOLD else "ok"
        shared = [k for k in ("accent", "composition", "form_family") if fp.get(k) and fp.get(k) == r.get(k)]
        refs = len(set(fp.get("refs") or []) & set(r.get("refs") or []))
        print(f"{flag:11} | vs {r['project_id']} ({r.get('created')}) | similarity {s} | same: {shared or '-'} | shared refs: {refs}")
    print(f"SUMMARY: {len(others)} other project(s) on this brief in {reg}; max similarity {worst}")
    if a.register:
        rows = [r for r in rows if r.get("project_id") != fp.get("project_id")] + [{k: fp.get(k) for k in (
            "project_id", "created", "brief_key", "site_key", "refs", "accent", "composition", "form_family",
            "footprint_sig", "plan_topology")}]
        with open(reg, "w", encoding="utf-8") as fh:
            fh.write("\n".join(json.dumps(r) for r in rows) + "\n")
        print("registered")
    sys.exit(1 if worst >= THRESHOLD else 0)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("seed"); s.add_argument("--project", required=True); s.add_argument("--brief")
    c = sub.add_parser("check"); c.add_argument("fingerprint"); c.add_argument("--register", action="store_true")
    a = ap.parse_args()
    cmd_seed(a) if a.cmd == "seed" else cmd_check(a)


if __name__ == "__main__":
    main()
