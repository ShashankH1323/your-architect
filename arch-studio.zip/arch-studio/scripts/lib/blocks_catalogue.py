"""v3_blocks_catalogue.py - inserts every block of v3_blocks.py on a grid with its name and renders
drawings/previews/blocks_catalogue_v3.png (white fills, thin #4A4A4A lines) + blocks_catalogue_v3.dxf.

Run:  py -3.14 -I v3_blocks_catalogue.py            (add  --crops DIR  to also write one PNG per section)
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import ezdxf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import Frontend, RenderContext
from ezdxf.addons.drawing.config import (BackgroundPolicy, ColorPolicy, Configuration, LinePolicy,
                                         LineweightPolicy)
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend

import blocks as vb

OUT = os.path.normpath(os.path.join(HERE, "..", "previews"))
INK = (0x4A, 0x4A, 0x4A)
GREY = (0x9A, 0x9A, 0x9A)
FONT_PT = 6.5
W_IN = 20.0
LAYER_OF = {"Furniture": "A-FURN", "Equipment": "A-EQPT", "Sanitary": "A-FIXT", "Doors": "A-DOOR", "Lift": "A-LIFT",
            "Landscape": "L-PLNT", "People": "A-PEOP", "Vehicles": "C-PARK", "Symbol": "A-FURN-CLR"}

LONG = ("FUR-BARTOP", "FUR-LEDGE", "FUR-WASHCTR", "FUR-PLANTER-BENCH", "FUR-CTR-ROUNDED", "FUR-CTR-4000",
        "FUR-CTR-3000", "FUR-CTR-L-3000", "FUR-CTR-PLAIN", "EQP-HOOD-2400", "EQP-HOOD-5338", "EQP-PREP-3200",
        "EQP-PREP-2400", "EQP-PANEL-LT", "EQP-CABLETRAY", "SAN-WASH-COUNTER", "SAN-TROUGH-800x6000",
        "FUR-BENCH-COMM", "FUR-TREESEAT", "FUR-KIDSPLAY")


def _is_long(n):
    return any(n.startswith(p) for p in LONG)


def sections():
    names = list(vb.BLOCK_INFO)
    cat = vb.CATEGORY
    long_ = [n for n in names if _is_long(n)]
    rest = [n for n in names if n not in long_]
    seating = [n for n in rest if n.startswith(("FUR-CHAIR", "FUR-LOUNGE", "FUR-TBL", "FUR-DHABA", "FUR-BOOTH",
                                                  "FUR-BENCH", "FUR-SOFA", "FUR-STOOL", "FUR-CHARPOY"))]
    furn = [n for n in rest if cat[n] == "Furniture" and n not in seating]
    eqp = [n for n in rest if cat[n] == "Equipment"]
    san = [n for n in rest if cat[n] in ("Sanitary", "Symbol", "Lift")]
    doors = [n for n in rest if cat[n] == "Doors"]
    land = [n for n in rest if cat[n] in ("Landscape", "People")]
    veh = [n for n in rest if cat[n] == "Vehicles"]
    return [
        ("SEATING AND TABLES", seating, 15000, 350),
        ("STORAGE, DESKS, COUNTERS AND SMALL FURNITURE", furn, 11000, 300),
        ("KITCHEN AND SERVICE EQUIPMENT", eqp, 11000, 300),
        ("LONG ITEMS: BAR TOPS, COUNTERS, HOODS, TROUGH, PLAY CORNER", long_, 22000, 500),
        ("SANITARY, ACCESSIBILITY AND LIFT", san, 9000, 300),
        ("DOORS (hinge / start jamb on the wall line; swing arcs on A-DOOR-SWING)", doors, 11000, 350),
        ("TREES, SHRUBS, PLANTERS AND PEOPLE", land, 32000, 700),
        ("VEHICLES (top view)", veh, 36000, 900),
    ]


def pack(doc, names, row_w, gap):
    """Row-pack blocks by true extents. Returns (cells, total_h); cell = (name, x, y_top, bbox, label_w, label_h)."""
    mm_per_in = row_w / W_IN
    lab_h = FONT_PT / 72.0 * mm_per_in * 2.6
    cells, rows, cur, cw = [], [], [], 0.0
    info = []
    for n in names:
        x0, y0, x1, y1 = vb.measure(doc, n)
        lab_w = len(n) * 0.58 * FONT_PT / 72.0 * mm_per_in
        info.append((n, (x0, y0, x1, y1), max(x1 - x0, lab_w) + gap))
    for it in info:
        if cur and cw + it[2] > row_w:
            rows.append(cur)
            cur, cw = [], 0.0
        cur.append(it)
        cw += it[2]
    if cur:
        rows.append(cur)
    y = 0.0
    for row in rows:
        h = max(it[1][3] - it[1][1] for it in row)
        x = 0.0
        for n, bb, cell_w in row:
            w = bb[2] - bb[0]
            cx = x + cell_w / 2.0 - gap / 2.0
            cells.append((n, cx, y, bb, lab_h))
            x += cell_w
        y -= h + lab_h + gap * 1.2
    return cells, -y


def build(doc, cells, with_text=False, label_style=None):
    msp = doc.modelspace()
    for n, cx, ytop, bb, lab_h in cells:
        x0, y0, x1, y1 = bb
        ins = (cx - (x0 + x1) / 2.0, ytop - y1)
        msp.add_blockref(n, ins, dxfattribs={"layer": LAYER_OF[vb.CATEGORY[n]]})
        if with_text:
            t = msp.add_text(n, height=lab_h / 2.6 * 1.3, dxfattribs={"style": label_style, "layer": "A-ANNO-TEXT"})
            t.set_placement((cx, ytop - (y1 - y0) - lab_h * 0.25), align=ezdxf.enums.TextEntityAlignment.TOP_CENTER)


def new_doc():
    doc = ezdxf.new("R2018", setup=True)
    doc.units = 4
    for ln in set(LAYER_OF.values()) | {"A-ANNO-TEXT"}:
        if ln not in doc.layers:
            doc.layers.add(ln)
        lay = doc.layers.get(ln)
        lay.rgb = INK
        lay.dxf.lineweight = 18
    vb.add_blocks(doc)
    doc.layers.get(vb.SWING_LAYER).rgb = GREY
    doc.layers.get(vb.SWING_LAYER).dxf.lineweight = 13
    return doc


def render_section(ax, doc, ymin_mm, row_w, title):
    cfg = Configuration(background_policy=BackgroundPolicy.WHITE, color_policy=ColorPolicy.COLOR,
                        lineweight_policy=LineweightPolicy.ABSOLUTE, lineweight_scaling=4.0, min_lineweight=0.3,
                        line_policy=LinePolicy.ACCURATE)
    Frontend(RenderContext(doc), MatplotlibBackend(ax), config=cfg).draw_layout(doc.modelspace(), finalize=False)
    ax.set_xlim(-600, row_w + 600)
    ax.set_ylim(-ymin_mm - 300, 350)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")


def main(crops=None):
    os.makedirs(OUT, exist_ok=True)
    base = new_doc()
    secs = []
    for title, names, row_w, gap in sections():
        if not names:
            continue
        cells, h = pack(base, names, row_w, gap)
        secs.append((title, names, row_w, gap, cells, h))

    # ---- DXF (one stacked drawing, with name labels)
    big = new_doc()
    if "CAT_ARIAL" not in big.styles:
        big.styles.add("CAT_ARIAL", font="arial.ttf")
    y_off = 0.0
    msp = big.modelspace()
    for title, names, row_w, gap, cells, h in secs:
        mm_per_in = row_w / W_IN
        t = msp.add_text(title, height=11 / 72.0 * mm_per_in * 1.3, dxfattribs={"style": "CAT_ARIAL", "layer": "A-ANNO-TEXT"})
        t.set_placement((0, y_off + 300), align=ezdxf.enums.TextEntityAlignment.LEFT)
        shifted = [(n, cx, yt + y_off, bb, lh) for n, cx, yt, bb, lh in cells]
        build(big, shifted, True, "CAT_ARIAL")
        y_off -= h + 2500
    big.saveas(os.path.join(OUT, "blocks_catalogue_v3.dxf"))

    # ---- PNG
    heights = []
    for title, names, row_w, gap, cells, h in secs:
        heights.append((W_IN * (h + 1200) / (row_w + 1200)) + 0.55)
    fig = plt.figure(figsize=(W_IN, sum(heights) + 0.3), facecolor="white")
    top = sum(heights) + 0.3
    total = top
    for (title, names, row_w, gap, cells, h), hh in zip(secs, heights):
        d = new_doc()
        build(d, cells)
        ax = fig.add_axes([0.01, (top - hh) / total, 0.98, (hh - 0.55) / total])
        render_section(ax, d, h, row_w, title)
        mm_per_in = row_w / W_IN
        # labels (matplotlib text so they stay in Arial and at a fixed point size)
        for n, cx, ytop, bb, lab_h in cells:
            ax.text(cx, ytop - (bb[3] - bb[1]) - lab_h * 0.22, "%s\n%d x %d" % (n, round(bb[2] - bb[0]), round(bb[3] - bb[1])),
                    ha="center", va="top", fontsize=FONT_PT, color="#333333", family="Arial", linespacing=1.15)
        fig.text(0.012, (top - 0.32) / total, title, fontsize=10.5, fontweight="bold", family="Arial", va="center")
        if crops:
            f2 = plt.figure(figsize=(W_IN, hh), facecolor="white")
            a2 = f2.add_axes([0.01, 0.0, 0.98, (hh - 0.55) / hh])
            d2 = new_doc()
            build(d2, cells)
            render_section(a2, d2, h, row_w, title)
            for n, cx, ytop, bb, lab_h in cells:
                a2.text(cx, ytop - (bb[3] - bb[1]) - lab_h * 0.22, "%s\n%d x %d" % (n, round(bb[2] - bb[0]), round(bb[3] - bb[1])),
                        ha="center", va="top", fontsize=FONT_PT, color="#333333", family="Arial", linespacing=1.15)
            f2.text(0.012, 1 - 0.28 / hh, title, fontsize=10.5, fontweight="bold", family="Arial", va="center")
            safe = "".join(ch if ch.isalnum() else "_" for ch in title)[:24]
            f2.savefig(os.path.join(crops, "sec_%s.png" % safe), dpi=100, facecolor="white")
            plt.close(f2)
        top -= hh
    fig.savefig(os.path.join(OUT, "blocks_catalogue_v3.png"), dpi=120, facecolor="white")
    plt.close(fig)
    print("catalogue:", sum(len(s[1]) for s in secs), "blocks in", len(secs), "sections ->", os.path.join(OUT, "blocks_catalogue_v3.png"))


if __name__ == "__main__":
    cr = None
    if "--crops" in sys.argv:
        cr = sys.argv[sys.argv.index("--crops") + 1]
        os.makedirs(cr, exist_ok=True)
    main(cr)
