"""cadlib.py - core CAD library for the AD-6 DXF pipeline (ezdxf 1.4.x, mm, R2018).

All annotation sizes are PAPER mm; they are multiplied by the drawing scale
(cadlib.SCALE, set by new_doc(scale=...)). Geometry is real-world mm.
Usage: sys.path.insert(0, <this folder>); import cadlib
"""
import math
import ezdxf
from ezdxf import units
from ezdxf.enums import TextEntityAlignment as TA

SCALE = 100
POCHE_RGB = (35, 35, 35)

# name, ACI, lineweight at 1:100 (1/100 mm), linetype, plot
_LAYERS = """
A-WALL 7 50 C 1|A-WALL-PATT 8 13 C 1|A-WALL-LOW 7 35 C 1|A-DOOR 2 35 C 1
A-DOOR-SWNG 8 13 C 1|A-DOOR-IDEN 3 25 C 1|A-GLAZ 4 25 C 1|A-GLAZ-IDEN 3 25 C 1
A-FLOR-STRS 2 35 C 1|A-FLOR-IDEN-STRS 3 25 C 1|A-FLOR-HRAL 2 35 C 1
A-FLOR-OVHD 4 25 H 1|A-FLOR-LEVL 3 25 C 1|A-FLOR-PATT 8 13 C 1
A-FURN 5 18 C 1|A-FURN-FIXD 5 18 C 1|A-FURN-CLR 9 13 D 0|A-EQPM 5 18 C 1
A-EQPM-OVHD 4 18 H 1|P-FIXT 5 18 C 1|P-FIXT-ACCS 5 18 C 1
S-COLS 7 50 C 1|S-BEAM 4 25 H 1|S-BRAC 4 25 H 1|S-FNDN 8 25 H 1
S-GRID 6 25 M 1|S-GRID-IDEN 6 25 C 1|S-SECT-CUT 7 50 C 1|S-SECT-PATT 8 13 C 1
A-ROOF 7 35 C 1|A-ROOF-PATT 8 13 C 1|A-ROOF-DRAN 4 25 C 1
A-SECT-CUT 1 70 C 1|A-SECT-PATT 8 13 C 1|A-SECT-BYND 7 25 C 1|A-SECT-MCUT 1 35 M 1
A-ELEV-OTLN 7 50 C 1|A-ELEV-LINE 7 25 C 1|A-ELEV-GRND 1 70 C 1|A-ELEV-PATT 8 13 C 1
A-ANNO-DIMS 3 25 C 1|A-ANNO-TEXT 7 25 C 1|A-ANNO-SYMB 7 25 C 1|A-AREA-IDEN 7 25 C 1
A-AREA 9 13 C 0|A-ANNO-TTLB 7 35 C 1|A-ANNO-NPLT 9 13 C 0|A-ANNO-VPRT 9 13 C 0
L-PLNT 3 18 C 1|L-WALK 8 18 C 1|L-SITE-PATT 8 13 C 1
C-PROP 1 70 P 1|C-PROP-SETB 1 35 H 1|C-ROAD 8 35 C 1|C-ROAD-IDEN 3 25 C 1
C-PRKG 8 25 C 1|C-PRKG-VEHC 5 18 C 1|C-PRKG-IDEN 3 25 C 1|G-ANNO-REVS 1 25 C 1
"""
_LT = {"C": "Continuous", "H": "AD6_HIDDEN", "M": "AD6_CENTER", "P": "AD6_PHANTOM", "D": "AD6_DOT"}
# 1:200 weights (hundredths mm) for the pens that change
_LW200 = {70: 50, 50: 35, 35: 25, 25: 18, 18: 13, 13: 13}


def rect(x, y, w, h):
    return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]


def new_doc(scale=100):
    """R2018 mm document: all AD6 layers, linetypes, Arial styles, dimstyle AD6_DIM."""
    global SCALE
    SCALE = scale
    doc = ezdxf.new("R2018", setup=True, units=units.MM)
    for k, v in {"$MEASUREMENT": 1, "$LUNITS": 2, "$LUPREC": 0, "$LWDISPLAY": 1,
                 "$LTSCALE": 1.0, "$PSLTSCALE": 0}.items():
        doc.header[k] = v
    doc.styles.add("AD6_ARIAL", font="arial.ttf")
    doc.styles.add("AD6_ARIAL_BOLD", font="arialbd.ttf")
    for nm, d, pat in [("AD6_HIDDEN", "Dashed", [3, -1.5]),
                       ("AD6_CENTER", "Chain", [12, -2, 2, -2]),
                       ("AD6_PHANTOM", "Phantom", [14, -2, 2, -2, 2, -2]),
                       ("AD6_DOT", "Dotted", [0.0, -2])]:
        p = [v * scale for v in pat]
        doc.linetypes.add(nm, pattern=[sum(abs(v) for v in p)] + p, description=d)
    for row in _LAYERS.replace("\n", "|").split("|"):
        if not row.strip():
            continue
        nm, aci, lw, lt, plot = row.split()
        lw = int(lw)
        if scale >= 200:
            lw = _LW200[lw]
        la = doc.layers.add(nm)
        la.color = int(aci)
        la.dxf.linetype = _LT[lt]
        la.dxf.lineweight = lw
        la.dxf.plot = int(plot)
    doc.dimstyles.new("AD6_DIM", dxfattribs={
        "dimscale": scale, "dimtxsty": "AD6_ARIAL", "dimtxt": 2.5, "dimgap": 0.8,
        "dimtad": 1, "dimtih": 0, "dimtoh": 0, "dimtsz": 1.5, "dimdle": 1.0,
        "dimexo": 2.0, "dimexe": 1.5, "dimdec": 0, "dimlunit": 2, "dimzin": 8,
        "dimclrd": 3, "dimclre": 3, "dimclrt": 3, "dimlwd": 25, "dimlwe": 25})
    return doc


# ------------------------------------------------------------------ helpers
def _pts(poly):
    """Accept shapely Polygon, or list of (x,y). Returns (outer, [holes])."""
    if hasattr(poly, "exterior"):
        out = [tuple(p[:2]) for p in poly.exterior.coords][:-1]
        holes = [[tuple(p[:2]) for p in r.coords][:-1] for r in poly.interiors]
        return out, holes
    return [tuple(p[:2]) for p in poly], []


def txt(msp, s, pt, h=2.5, layer="A-ANNO-TEXT", bold=False, align=TA.MIDDLE_CENTER, rotation=0):
    """Single-line TEXT, height h in PAPER mm (x SCALE). Arial / Arial Bold."""
    e = msp.add_text(s, height=h * SCALE, rotation=rotation, dxfattribs={
        "layer": layer, "style": "AD6_ARIAL_BOLD" if bold else "AD6_ARIAL"})
    e.set_placement(pt, align=align)
    return e


def _fill(msp, paths, layer, rgb=None, aci=7):
    h = msp.add_hatch(dxfattribs={"layer": layer})
    if rgb:
        h.set_solid_fill(color=aci, rgb=rgb)
    else:
        h.set_solid_fill(color=aci)
    for p in paths:
        h.paths.add_polyline_path(p, is_closed=True)
    return h


def poche_wall(msp, polygon, layer="A-WALL"):
    """Cut wall: closed LWPOLYLINE outline(s) on `layer` + SOLID dark hatch on A-WALL-PATT.
    polygon: shapely Polygon (holes honoured) or list of (x,y)."""
    outer, holes = _pts(polygon)
    for ring in [outer] + holes:
        msp.add_lwpolyline(ring, close=True, dxfattribs={"layer": layer})
    return _fill(msp, [outer] + holes, "A-WALL-PATT", rgb=POCHE_RGB, aci=8)


def i_section_pts(cx, cy, d=300, bf=250, tf=10.6, tw=7.6, rot=0):
    """12-point I/H profile centred on (cx,cy); depth d along local y, flange width bf."""
    hd, hb, hw = d / 2, bf / 2, tw / 2
    p = [(-hb, -hd), (hb, -hd), (hb, -hd + tf), (hw, -hd + tf), (hw, hd - tf), (hb, hd - tf),
         (hb, hd), (-hb, hd), (-hb, hd - tf), (-hw, hd - tf), (-hw, -hd + tf), (-hb, -hd + tf)]
    c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in p]


def steel_i_column(msp, cx, cy, d=300, bf=250, tf=10.6, tw=7.6, rot=0, layer="S-COLS"):
    """True-shape I/H steel column (default ISHB 300 simplified) + solid fill, both on `layer`."""
    pts = i_section_pts(cx, cy, d, bf, tf, tw, rot)
    msp.add_lwpolyline(pts, close=True, dxfattribs={"layer": layer})
    _fill(msp, [pts], layer, aci=7)
    return pts


def steel_chs_column(msp, cx, cy, dia=219.1, t=None, layer="S-COLS"):
    """CHS column: circle + solid fill. t=None -> solid disc; t=wall thickness -> filled ring."""
    msp.add_circle((cx, cy), dia / 2, dxfattribs={"layer": layer})
    h = msp.add_hatch(dxfattribs={"layer": layer})
    h.set_solid_fill(color=7)
    h.paths.add_edge_path().add_arc((cx, cy), dia / 2, 0, 360)
    if t:
        msp.add_circle((cx, cy), dia / 2 - t, dxfattribs={"layer": layer})
        h.paths.add_edge_path().add_arc((cx, cy), dia / 2 - t, 0, 360)
    return h


def grid_line(msp, p1, p2, label, bubble="end", ext=None, dia=8):
    """Chain grid line p1->p2 on S-GRID with a bubble (circle dia paper-mm + bold label) on
    S-GRID-IDEN. bubble: 'start' | 'end' | 'both'. ext = line extension to the bubble (model mm,
    default 4 paper-mm). Returns bubble centres."""
    ext = 4 * SCALE if ext is None else ext
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    L = math.hypot(dx, dy)
    ux, uy = dx / L, dy / L
    msp.add_line(p1, p2, dxfattribs={"layer": "S-GRID"})
    r = dia / 2 * SCALE
    centres = []
    ends = {"start": [(p1, -1)], "end": [(p2, 1)], "both": [(p1, -1), (p2, 1)]}[bubble]
    for (pt, sgn) in ends:
        c = (pt[0] + sgn * ux * (ext + r), pt[1] + sgn * uy * (ext + r))
        msp.add_line(pt, (pt[0] + sgn * ux * ext, pt[1] + sgn * uy * ext),
                     dxfattribs={"layer": "S-GRID-IDEN"})
        msp.add_circle(c, r, dxfattribs={"layer": "S-GRID-IDEN"})
        txt(msp, label, c, h=3.5, layer="S-GRID-IDEN", bold=True)
        centres.append(c)
    return centres


def dim_chain(msp, points, base, direction="x"):
    """Continuous chain of linear dimensions through `points` (model mm).
    direction 'x' = horizontal dims, `base` = (any, y of the dim line);
    'y' = vertical dims, `base` = (x of the dim line, any). Real DIMENSION entities, AD6_DIM."""
    ang = 0 if direction == "x" else 90
    b = (points[0][0], base[1]) if direction == "x" else (base[0], points[0][1])
    d = msp.add_multi_point_linear_dim(b, points, angle=ang, dimstyle="AD6_DIM",
                                       dxfattribs={"layer": "A-ANNO-DIMS"})
    return d


# ------------------------------------------------------------------ annotation
def room_label(msp, pt, name, area_m2=None, polygon=None):
    """Plain room name (bold 3.5) + area 'xx.x m2' (2.5) centred on pt. Area taken from polygon if given."""
    if area_m2 is None and polygon is not None:
        o, h = _pts(polygon)

        def a(r):
            n = len(r)
            return abs(sum(r[i][0] * r[(i + 1) % n][1] - r[(i + 1) % n][0] * r[i][1]
                           for i in range(n))) / 2
        area_m2 = (a(o) - sum(a(r) for r in h)) / 1e6
    x, y = pt
    txt(msp, name, (x, y + 2.3 * SCALE), 3.5, "A-AREA-IDEN", bold=True)
    if area_m2 is not None:
        txt(msp, "%.1f m²" % area_m2, (x, y - 2.0 * SCALE), 2.5, "A-AREA-IDEN")


def level_marker(msp, pt, value_m, side=1):
    """Level marker: filled inverted triangle on a datum line, text like +0.450 (metres).
    side=1 text to the right, -1 to the left. pt = the level point (triangle apex)."""
    S = SCALE
    x, y = pt
    tri = [(x - 1.5 * S, y + 2.6 * S), (x + 1.5 * S, y + 2.6 * S), (x, y)]
    msp.add_lwpolyline(tri, close=True, dxfattribs={"layer": "A-FLOR-LEVL"})
    _fill(msp, [tri], "A-FLOR-LEVL", aci=7)
    msp.add_line((x - side * 1.5 * S, y + 2.6 * S), (x + side * 11 * S, y + 2.6 * S),
                 dxfattribs={"layer": "A-FLOR-LEVL"})
    s = ("%+.3f" % value_m) if abs(value_m) > 1e-9 else "0.000"
    txt(msp, s, (x + side * 2.2 * S, y + 3.1 * S), 2.5, "A-FLOR-LEVL",
        align=TA.BOTTOM_LEFT if side > 0 else TA.BOTTOM_RIGHT)


def north_arrow(msp, pt, dia=14, angle=0):
    """Circle with half-filled arrow and bold N. angle = degrees CCW the arrow is rotated."""
    S, L = SCALE, "A-ANNO-SYMB"
    x, y = pt
    r = dia / 2 * S
    msp.add_circle(pt, r, dxfattribs={"layer": L})
    a = math.radians(angle)

    def R(px, py):
        return (x + px * math.cos(a) - py * math.sin(a), y + px * math.sin(a) + py * math.cos(a))
    tip, bl, br, nt = R(0, r * 0.95), R(-r * 0.38, -r * 0.7), R(r * 0.38, -r * 0.7), R(0, -r * 0.3)
    msp.add_lwpolyline([tip, bl, nt, br], close=True, dxfattribs={"layer": L})
    _fill(msp, [[tip, nt, br]], L, aci=7)
    txt(msp, "N", R(0, r + 2.4 * S), 3.5, L, bold=True, rotation=angle)


def scale_bar(msp, pt, length_m=10, divisions=5):
    """Graphic scale bar, alternating black/white blocks, metre labels; pt = left end."""
    S, L = SCALE, "A-ANNO-SYMB"
    x, y = pt
    seg = length_m * 1000 / divisions
    hgt = 1.2 * S
    for i in range(divisions):
        box = rect(x + i * seg, y, seg, hgt)
        msp.add_lwpolyline(box, close=True, dxfattribs={"layer": L})
        if i % 2 == 0:
            _fill(msp, [box], L, aci=7)
        txt(msp, "%g" % (i * length_m / divisions), (x + i * seg, y + hgt + 1.4 * S), 2.0, L)
    txt(msp, "%g m" % length_m, (x + length_m * 1000, y + hgt + 1.4 * S), 2.0, L)
    txt(msp, "SCALE 1 : %d" % SCALE, (x, y - 2.4 * S), 2.0, L, align=TA.MIDDLE_LEFT)


def section_marker(msp, p1, p2, label, look=1):
    """Section cut: chain line p1-p2 on A-SECT-MCUT, heavy 10-paper-mm stubs at both ends,
    view-direction arrows and label bubbles. look=+1 views to the left of p1->p2, -1 to the right."""
    S = SCALE
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    L = math.hypot(dx, dy)
    ux, uy = dx / L, dy / L
    nx, ny = -uy * look, ux * look
    msp.add_line(p1, p2, dxfattribs={"layer": "A-SECT-MCUT"})
    for pt, sg in ((p1, 1), (p2, -1)):
        e = (pt[0] + sg * ux * 10 * S, pt[1] + sg * uy * 10 * S)
        msp.add_lwpolyline([pt, e], dxfattribs={"layer": "A-SECT-MCUT", "const_width": 0.8 * S})
        a1 = (pt[0] + nx * 8 * S, pt[1] + ny * 8 * S)
        msp.add_line(pt, a1, dxfattribs={"layer": "A-ANNO-SYMB"})
        h1 = (a1[0] - nx * 2.2 * S + ux * 0.8 * S, a1[1] - ny * 2.2 * S + uy * 0.8 * S)
        h2 = (a1[0] - nx * 2.2 * S - ux * 0.8 * S, a1[1] - ny * 2.2 * S - uy * 0.8 * S)
        tri = [a1, h1, h2]
        msp.add_lwpolyline(tri, close=True, dxfattribs={"layer": "A-ANNO-SYMB"})
        _fill(msp, [tri], "A-ANNO-SYMB", aci=7)
        c = (a1[0] + nx * 3.2 * S, a1[1] + ny * 3.2 * S)
        msp.add_circle(c, 3 * S, dxfattribs={"layer": "A-ANNO-SYMB"})
        txt(msp, label, c, 3.5, "A-ANNO-SYMB", bold=True)


def title_block(msp, origin, w, h, fields):
    """Title block frame (paper-mm w x h at `origin`, scaled by SCALE) with a bottom strip of
    equal cells. fields: dict label->value (group number only, no names)."""
    S, L = SCALE, "A-ANNO-TTLB"
    x, y = origin
    msp.add_lwpolyline(rect(x, y, w * S, h * S), close=True, dxfattribs={"layer": L})
    strip = 14 * S
    msp.add_line((x, y + strip), (x + w * S, y + strip), dxfattribs={"layer": L})
    n = max(len(fields), 1)
    cw = w * S / n
    for i, (k, v) in enumerate(fields.items()):
        cx = x + i * cw
        if i:
            msp.add_line((cx, y), (cx, y + strip), dxfattribs={"layer": L})
        txt(msp, k.upper(), (cx + 1.5 * S, y + strip - 2.5 * S), 2.0, L, align=TA.MIDDLE_LEFT)
        txt(msp, str(v), (cx + 1.5 * S, y + 4.5 * S), 3.5, L, bold=True, align=TA.MIDDLE_LEFT)


# ------------------------------------------------------------------ render
PAPER = {"A4": (297, 210), "A3": (420, 297), "A2": (594, 420), "A1": (841, 594), "A0": (1189, 841)}


def render(dxf_path, pdf_path=None, png_path=None, paper="A3", scale=100, dpi=150,
           mono=True, center=None, doc=None):
    """Render model space to PDF/PNG on a figure of TRUE paper size so lineweights and text print
    at scale. White background; mono=True -> all black ink (plot-like), else ACI colours.
    center: model-mm point to centre on (default = drawing extents centre)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from ezdxf import bbox
    from ezdxf.addons.drawing import Frontend, RenderContext
    from ezdxf.addons.drawing.config import (BackgroundPolicy, ColorPolicy, Configuration,
                                             LineweightPolicy)
    from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
    if doc is None:
        doc = ezdxf.readfile(dxf_path)
    msp = doc.modelspace()
    pw, ph = PAPER[paper.upper()] if isinstance(paper, str) else paper
    box = bbox.extents(msp)
    cx, cy = center or ((box.extmin.x + box.extmax.x) / 2, (box.extmin.y + box.extmax.y) / 2)
    need_w, need_h = (box.extmax.x - box.extmin.x) / scale, (box.extmax.y - box.extmin.y) / scale
    if need_w > pw or need_h > ph:
        print("render WARNING: drawing %.0f x %.0f paper-mm exceeds %s %d x %d" %
              (need_w, need_h, paper, pw, ph))
    fig = plt.figure(figsize=(pw / 25.4, ph / 25.4), facecolor="white")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("white")
    cfg = Configuration(background_policy=BackgroundPolicy.WHITE,
                        color_policy=ColorPolicy.BLACK if mono else ColorPolicy.COLOR,
                        lineweight_policy=LineweightPolicy.ABSOLUTE)
    Frontend(RenderContext(doc), MatplotlibBackend(ax), config=cfg).draw_layout(msp, finalize=True)
    fig.set_size_inches(pw / 25.4, ph / 25.4)
    ax.set_position([0, 0, 1, 1])
    ax.set_xlim(cx - pw * scale / 2, cx + pw * scale / 2)
    ax.set_ylim(cy - ph * scale / 2, cy + ph * scale / 2)
    ax.set_aspect("equal", adjustable="box")
    ax.axis("off")
    if pdf_path:
        fig.savefig(pdf_path, facecolor="white")
    if png_path:
        fig.savefig(png_path, dpi=dpi, facecolor="white")
    plt.close(fig)
