"""v3_blocks.py - DXF BLOCK LIBRARY for "The Woven Street" (final furnished plans), mm, true size.

    import v3_blocks; names = v3_blocks.add_blocks(doc)        # defines every block in `doc`
    v3_blocks.BLOCK_INFO[name] -> (w_mm, d_mm, insert_note)    # measured extents of the geometry

Look: P05 (Refer_ThIS/P05_plan_furnished_colour_accent.jpg): thin clean lines, rounded chairs,
real sanitary shapes, white fills, soft cushions and rugs, sketchy lobed trees.

Conventions
  * All geometry on layer "0", colour / linetype BYBLOCK, so the layer of the INSERT
    (A-FURN, A-FIXT, A-EQPT, L-PLNT, C-PARK, A-PEOP ...) controls the look. Fine detail uses an
    explicit 0.09 mm lineweight; hidden / overhead items use linetype BLK_DASH (made if missing).
    Only door swing arcs sit on their own layer A-DOOR-SWING.
  * Closed outlines are LWPOLYLINEs. Each solid body has a WHITE SOLID HATCH (true colour 255,255,255,
    layer "0") added just BEFORE its outline, so the object masks the floor pattern behind it.
    Blocks with NO built-in fill (the renderer tints them): trees, shrubs, dashed / overhead items, flat marks.
  * Front = +Y. Chairs, vehicles, counters face / point +Y.
  * "centre"  : insertion point = geometric centre of the plan footprint.
  * "back"    : insertion point = back-centre on the wall face (y = 0); the block projects into +Y.
                South wall rot 0, east wall rot 90, north wall rot 180, west wall rot 270.
  * Chairs    : insertion point = seat centre; back on -Y, faces +Y.
  * Doors     : see the note per block. Single leaf: insertion = hinge jamb on the wall centre line,
                the opening runs along +X, the leaf opens 90 deg to +Y; mirror with xscale = -1.
  * Nested INSERTs (chairs inside table sets) are BYBLOCK too, so one layer colours the whole set.
"""
import math
import random

import ezdxf

FINE_LW = 9
DASH = "BLK_DASH"
SWING_LAYER = "A-DOOR-SWING"
WHITE = (255, 255, 255)
B90 = math.tan(math.radians(90) / 4.0)          # bulge of a quarter circle

REG = []            # (name, category, insert_note, w, d, builder)
BLOCK_INFO = {}     # name -> (w, d, insert_note)    w, d = extents of the geometry in mm
CATEGORY = {}       # name -> category (for the catalogue)


# ------------------------------------------------------------------ vertex helpers
def _same(a, b):
    return abs(a[0] - b[0]) < 1e-6 and abs(a[1] - b[1]) < 1e-6


def _dedupe(v):
    """drop a vertex whose successor sits on the same point (zero-length segment)."""
    n = len(v)
    out = []
    for i in range(n):
        if n > 2 and _same(v[i], v[(i + 1) % n]):
            continue
        out.append(v[i])
    return out


def rr_verts(x0, y0, x1, y1, r=0, r4=None):
    """Rounded rectangle, CCW, start bottom edge. r4 = (bottom-left, bottom-right, top-right, top-left)."""
    x0, x1 = sorted((x0, x1))
    y0, y1 = sorted((y0, y1))
    if r4 is None:
        r4 = (r, r, r, r)
    if not any(r4):
        return [(x0, y0, 0), (x1, y0, 0), (x1, y1, 0), (x0, y1, 0)]
    m = min((x1 - x0) / 2.0, (y1 - y0) / 2.0)
    bl, br, tr, tl = [min(max(q, 0), m) for q in r4]
    v = [(x0 + bl, y0, 0), (x1 - br, y0, B90 if br else 0), (x1, y0 + br, 0),
         (x1, y1 - tr, B90 if tr else 0), (x1 - tr, y1, 0), (x0 + tl, y1, B90 if tl else 0),
         (x0, y1 - tl, 0), (x0, y0 + bl, B90 if bl else 0)]
    return _dedupe(v)


def rr_open(x0, y0, x1, y1, r, gap_side, gap_w):
    """Rounded rectangle as an OPEN path with a gap_w gap centred on the north ('N') or east ('E') side."""
    b, h = B90, gap_w / 2.0
    if gap_side == "N":
        return [(-h, y1, 0), (x0 + r, y1, b), (x0, y1 - r, 0), (x0, y0 + r, b), (x0 + r, y0, 0),
                (x1 - r, y0, b), (x1, y0 + r, 0), (x1, y1 - r, b), (x1 - r, y1, 0), (h, y1, 0)]
    return [(x1, h, 0), (x1, y1 - r, b), (x1 - r, y1, 0), (x0 + r, y1, b), (x0, y1 - r, 0),
            (x0, y0 + r, b), (x0 + r, y0, 0), (x1 - r, y0, b), (x1, y0 + r, 0), (x1, -h, 0)]


def hull_verts(c1, r1, c2, r2):
    """Closed outline (CCW, bulge arcs) of the convex hull of two circles: capsule / teardrop / pear."""
    dx, dy = c1[0] - c2[0], c1[1] - c2[1]
    d = math.hypot(dx, dy)
    al = math.atan2(dy, dx)                       # direction from circle 2 toward circle 1
    be = math.acos(max(-1.0, min(1.0, -(r1 - r2) / d)))
    n1, n2 = al - be, al + be                     # right / left normal angles
    p = lambda c, r, a: (c[0] + r * math.cos(a), c[1] + r * math.sin(a))
    b1 = math.tan(2 * be / 4.0)                   # wide arc sweep 2*be
    b2 = math.tan((2 * math.pi - 2 * be) / 4.0)   # narrow arc sweep
    a1, a2 = p(c1, r1, n1), p(c1, r1, n2)
    a3, a4 = p(c2, r2, n2), p(c2, r2, n1)
    return [(a1[0], a1[1], b1), (a2[0], a2[1], 0), (a3[0], a3[1], b2), (a4[0], a4[1], 0)]


def arc_samples(p0, p1, bulge, n=16):
    """points along a bulge arc p0 -> p1 (excluding p0, including p1)."""
    if abs(bulge) < 1e-9:
        return [p1]
    x0, y0, x1, y1 = p0[0], p0[1], p1[0], p1[1]
    c = math.hypot(x1 - x0, y1 - y0)
    th = 4 * math.atan(bulge)
    r = c / (2 * math.sin(abs(th) / 2))
    mx, my = (x0 + x1) / 2, (y0 + y1) / 2
    h = r * math.cos(th / 2) * (1 if th > 0 else -1)
    nx, ny = -(y1 - y0) / c, (x1 - x0) / c
    cx, cy = mx + nx * h, my + ny * h             # centre is to the left for CCW arcs (bulge > 0)
    a0 = math.atan2(y0 - cy, x0 - cx)
    out = []
    for i in range(1, n + 1):
        a = a0 + th * i / n
        out.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return out


def lobed_verts(R, n, seed, lo=0.84, sweep=(105, 160)):
    """Cloud / scalloped closed outline of outer radius ~R with n lobes (apexes at k*360/n)."""
    rnd = random.Random(seed)
    phi = 2 * math.pi / n
    targets, sweeps = [], []
    for k in range(n):
        axis = (k * 4) % n == 0
        targets.append(R if axis else R * (lo + (1 - lo) * rnd.random()))
        sweeps.append(math.radians(rnd.uniform(*sweep)))
    verts = []
    jit = [rnd.uniform(-0.16, 0.16) * phi for _ in range(n)]
    for k in range(n):                             # vertex k sits between lobe k-1 and lobe k
        t = (targets[k - 1] + targets[k]) / 2.0
        s = (sweeps[k - 1] + sweeps[k]) / 2.0
        rho = t / (math.cos(phi / 2) + math.sin(phi / 2) * math.tan(s / 4))
        a = (k - 0.5) * phi + jit[k]
        verts.append([rho * math.cos(a), rho * math.sin(a), math.tan(sweeps[k] / 4)])
    # rescale so the extents are exactly R
    pts = []
    for i, v in enumerate(verts):
        pts.append((v[0], v[1]))
        pts += arc_samples(v, verts[(i + 1) % n], v[2])
    x0, x1 = min(p[0] for p in pts), max(p[0] for p in pts)
    y0, y1 = min(p[1] for p in pts), max(p[1] for p in pts)
    cx, cy, sx, sy = (x0 + x1) / 2.0, (y0 + y1) / 2.0, 2 * R / (x1 - x0), 2 * R / (y1 - y0)
    return [((v[0] - cx) * sx, (v[1] - cy) * sy, v[2]) for v in verts]


def clip_line(p, d, x0, y0, x1, y1):
    """Liang-Barsky: part of the infinite line p + t*d inside the rectangle, or None."""
    t0, t1 = -1e9, 1e9
    for pp, dd, lo, hi in ((p[0], d[0], x0, x1), (p[1], d[1], y0, y1)):
        if abs(dd) < 1e-12:
            if pp < lo or pp > hi:
                return None
        else:
            ta, tb = (lo - pp) / dd, (hi - pp) / dd
            if ta > tb:
                ta, tb = tb, ta
            t0, t1 = max(t0, ta), min(t1, tb)
    if t0 >= t1:
        return None
    return (p[0] + t0 * d[0], p[1] + t0 * d[1]), (p[0] + t1 * d[0], p[1] + t1 * d[1])


# ------------------------------------------------------------------ block drawing helper
class B:
    """Drawing helper bound to one block definition. fill=None -> white fill for solid closed shapes."""

    def __init__(self, doc, name):
        self.doc = doc
        self.blk = doc.blocks.new(name=name, base_point=(0, 0))
        self.name = name

    def _a(self, fine=False, dash=False, lw=None, layer="0"):
        d = {"layer": layer, "color": 0, "lineweight": FINE_LW if fine else -2,
             "linetype": DASH if dash else "BYBLOCK"}
        if lw is not None:
            d["lineweight"] = lw
        return d

    def _hatch(self, verts):
        h = self.blk.add_hatch(dxfattribs={"layer": "0"})
        h.set_solid_fill(color=7, rgb=WHITE)
        h.paths.add_polyline_path([(v[0], v[1], v[2] if len(v) > 2 else 0) for v in verts], is_closed=True)
        return h

    def _want_fill(self, fill, k):
        return (not (k.get("fine") or k.get("dash"))) if fill is None else fill

    # --- primitives
    def L(self, p, q, **k):
        return self.blk.add_line(p, q, dxfattribs=self._a(**k))

    def LS(self, pairs, **k):
        for p, q in pairs:
            self.L(p, q, **k)

    def PL(self, pts, close=False, **k):
        return self.blk.add_lwpolyline(pts, close=close, dxfattribs=self._a(**k))

    def PLB(self, verts, close=True, fill=None, **k):
        verts = [(v[0], v[1], v[2] if len(v) > 2 else 0) for v in verts]
        if close and self._want_fill(fill, k):
            self._hatch(verts)
        return self.blk.add_lwpolyline(verts, format="xyb", close=close, dxfattribs=self._a(**k))

    def R(self, x0, y0, x1, y1, r=0, r4=None, fill=None, **k):
        return self.PLB(rr_verts(x0, y0, x1, y1, r, r4), True, fill, **k)

    def C(self, cx, cy, r, fill=None, **k):
        if self._want_fill(fill, k):
            self._hatch([(cx - r, cy, 1), (cx + r, cy, 1)])
        return self.blk.add_circle((cx, cy), r, dxfattribs=self._a(**k))

    def A(self, cx, cy, r, a0, a1, **k):
        return self.blk.add_arc((cx, cy), r, a0, a1, dxfattribs=self._a(**k))

    def E(self, cx, cy, rx, ry, fill=None, **k):
        if self._want_fill(fill, k):
            self._hatch([(cx + rx * math.cos(2 * math.pi * i / 40), cy + ry * math.sin(2 * math.pi * i / 40), 0)
                         for i in range(40)])
        if rx >= ry:
            return self.blk.add_ellipse((cx, cy), (rx, 0), ry / rx, dxfattribs=self._a(**k))
        return self.blk.add_ellipse((cx, cy), (0, ry), rx / ry, dxfattribs=self._a(**k))

    def HULL(self, c1, r1, c2, r2, fill=None, **k):
        return self.PLB(hull_verts(c1, r1, c2, r2), True, fill, **k)

    def POLY(self, pts, fill=None, **k):
        return self.PLB([(p[0], p[1], 0) for p in pts], True, fill, **k)

    def BLOB(self, cx, cy, r, seed, n=8, lo=0.84, **k):
        """lobed cloud outline (shrub / tree canopy), no fill."""
        return self.PLB([(x + cx, y + cy, bb) for x, y, bb in lobed_verts(r, n, seed, lo)], True, False, **k)

    def INS(self, name, pos, rot=0, scale=1, layer="0"):
        return self.blk.add_blockref(name, pos, dxfattribs={
            "layer": layer, "rotation": rot, "xscale": scale, "yscale": scale, "color": 0, "lineweight": -2})

    # --- composite details
    def slats(self, x0, y0, x1, y1, n, axis="x", **k):
        """n-1 parallel fine lines dividing the rectangle into n equal strips (axis = direction of the lines)."""
        k.setdefault("fine", True)
        for i in range(1, n):
            if axis == "x":
                y = y0 + (y1 - y0) * i / n
                self.L((x0, y), (x1, y), **k)
            else:
                x = x0 + (x1 - x0) * i / n
                self.L((x, y0), (x, y1), **k)

    def diag(self, x0, y0, x1, y1, step, ang=45, **k):
        """parallel fine lines at `ang` degrees clipped to the rectangle."""
        k.setdefault("fine", True)
        a = math.radians(ang)
        d = (math.cos(a), math.sin(a))
        nrm = (-d[1], d[0])
        diag_len = math.hypot(x1 - x0, y1 - y0)
        cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
        n = int(diag_len / step / 2) + 1
        for i in range(-n, n + 1):
            seg = clip_line((cx + nrm[0] * step * i, cy + nrm[1] * step * i), d, x0, y0, x1, y1)
            if seg:
                self.L(seg[0], seg[1], **k)

    def grid(self, x0, y0, x1, y1, px, py, **k):
        k.setdefault("fine", True)
        x = x0 + px
        while x < x1 - 1:
            self.L((x, y0), (x, y1), **k)
            x += px
        y = y0 + py
        while y < y1 - 1:
            self.L((x0, y), (x1, y), **k)
            y += py


# ------------------------------------------------------------------ registry
def reg(name, cat, ins, w, d):
    """Register a block: builder(b) draws it. (w, d) = extents of the geometry in mm."""
    def deco(fn):
        assert name not in BLOCK_INFO, "duplicate block name " + name
        REG.append((name, cat, ins, w, d, fn))
        BLOCK_INFO[name] = (w, d, ins)
        CATEGORY[name] = cat
        return fn
    return deco


def reg_many(items, cat, ins, mk, wd):
    """register a family: items = list of parameters; mk(p) -> builder; wd(p) -> (name, w, d)."""
    for p in items:
        name, w, d = wd(p)
        reg(name, cat, ins, w, d)(mk(p))


def _ensure(doc):
    if DASH not in doc.linetypes:
        doc.linetypes.add(DASH, pattern=[300.0, 200.0, -100.0], description="Block hidden / overhead")
    if SWING_LAYER not in doc.layers:
        doc.layers.add(SWING_LAYER, color=9)


# ================================================================== SEATING AND TABLES
def _chair(b, k=1.0):
    """seat centre = origin, back on -Y, faces +Y. k scales the 450 chair (k = 0.667 -> 300 kids chair)."""
    b.R(-225 * k, -185 * k, 225 * k, 200 * k, r4=(26 * k, 26 * k, 62 * k, 62 * k))    # seat
    b.R(-188 * k, -150 * k, 188 * k, 165 * k, r=42 * k, fine=True)                    # cushion line
    b.PLB([(-225 * k, -185 * k, 0.2889), (225 * k, -185 * k, 0), (200 * k, -170 * k, -0.225),
           (-200 * k, -170 * k, 0)], True)                                           # curved back rest


reg("FUR-CHAIR-450", "Furniture", "seat centre; back on -Y, faces +Y", 450, 450)(lambda b: _chair(b))
reg("FUR-CHAIR-TUCK-450", "Furniture", "seat centre; faces +Y (same drawing as FUR-CHAIR-450)", 450, 450)(
    lambda b: _chair(b))
reg("FUR-CHAIR-KID-300", "Furniture", "seat centre; back on -Y, faces +Y", 300, 300)(
    lambda b: _chair(b, 300 / 450.0))


@reg("FUR-CHAIR-OFFICE-550", "Furniture", "seat centre; back on -Y, faces +Y", 550, 515)
def _chair_office(b):
    b.R(-230, -190, 230, 215, r=72)                                                   # seat
    b.R(-178, -150, 178, 175, r=52, fine=True)
    for sx in (-1, 1):                                                                # arm rests
        b.R(sx * 255 - 20, -40, sx * 255 + 20, 190, r=16)
    a0, a1, cy, ro, ri = math.radians(215), math.radians(325), 40, 285, 250
    p = lambda r, a: (r * math.cos(a), cy + r * math.sin(a))
    bg = math.tan((a1 - a0) / 4.0)
    b.PLB([p(ro, a0) + (bg,), p(ro, a1) + (0,), p(ri, a1) + (-bg,), p(ri, a0) + (0,)], True)   # curved back rest
    for i in range(5):                                                                # 5-star base (hidden)
        a = math.radians(90 + 72 * i)
        b.L((0, 0), (255 * math.cos(a), 255 * math.sin(a)), dash=True)
    b.C(0, 0, 38, fine=True)


@reg("FUR-LOUNGE-CHAIR-800", "Furniture", "centre; back on -Y", 800, 800)
def _chair_lounge(b):
    b.R(-400, -400, 400, 400, r=90)
    b.R(-400, -400, 400, -230, r=60)                                                 # back
    for sx in (-1, 1):
        b.R(sx * 400, -230, sx * 400 - sx * 130, 400, r=45)                          # arms
    b.R(-250, -210, 250, 380, r=50, fine=True)                                       # seat cushion
    b.L((-250, -100), (250, -100), fine=True)


# ---- table sets: table drawn AFTER the chairs so its white fill hides the tucked 100 mm of each chair
def _tbl_rect(b, w, d, chairs):
    for (x, y, rot) in chairs(w, d):
        b.INS("FUR-CHAIR-450", (x, y), rot)
    b.R(-w / 2, -d / 2, w / 2, d / 2, r=15)
    b.R(-w / 2 + 28, -d / 2 + 28, w / 2 - 28, d / 2 - 28, r=8, fine=True)


def _ch2(w, d):
    return [(0, -(d / 2 + 100), 0), (0, d / 2 + 100, 180)]


def _ch4sq(w, d):
    return _ch2(w, d) + [(w / 2 + 100, 0, 90), (-(w / 2 + 100), 0, 270)]


def _chrect(n_long):
    def f(w, d):
        pitch = w / n_long
        out = []
        for i in range(n_long):
            x = -w / 2 + pitch * (i + 0.5)
            out += [(x, -(d / 2 + 100), 0), (x, d / 2 + 100, 180)]
        return out
    return f


reg("FUR-TBL2-700", "Furniture", "centre of the table; seats north + south", 700, 1400)(
    lambda b: _tbl_rect(b, 700, 700, _ch2))
reg("FUR-TBL4-900", "Furniture", "centre of the table; seats on 4 sides", 1500, 1400)(
    lambda b: _tbl_rect(b, 900, 900, _ch4sq))
reg("FUR-TBL4R-1200", "Furniture", "centre of the table; 2 + 2 seats along the long sides", 1200, 1350)(
    lambda b: _tbl_rect(b, 1200, 750, _chrect(2)))
reg("FUR-TBL6-1800", "Furniture", "centre of the table; 3 + 3 seats along the long sides", 1800, 1500)(
    lambda b: _tbl_rect(b, 1800, 800, _chrect(3)))


def _tbl_round(b, dia, n, start, chair="FUR-CHAIR-450", off=100, k=1.0):
    R = dia / 2 + off
    for i in range(n):
        th = start + 360.0 / n * i
        a = math.radians(th)
        b.INS(chair, (R * math.cos(a), R * math.sin(a)), th + 90)
    b.C(0, 0, dia / 2)
    b.C(0, 0, dia / 2 - 28 * k, fine=True)


reg("FUR-TBLR2-700", "Furniture", "centre of the table; seats north + south", 700, 1400)(
    lambda b: _tbl_round(b, 700, 2, -90))
reg("FUR-TBLR4-1000", "Furniture", "centre of the table; 4 seats", 1700, 1700)(
    lambda b: _tbl_round(b, 1000, 4, -90))
reg("FUR-TBLR6-1500", "Furniture", "centre of the table; 6 seats", 2200, 2200)(
    lambda b: _tbl_round(b, 1500, 6, -90))
reg("FUR-TBLR4-KIDS-600", "Furniture", "centre of the table; 4 small chairs tucked", 1000, 1000)(
    lambda b: _tbl_round(b, 600, 4, -90, "FUR-CHAIR-KID-300", off=33, k=0.667))


@reg("FUR-DHABA-TABLE-4", "Furniture", "centre; long side along Y; table 750 + two 300 steel benches", 1550, 1200)
def _dhaba(b):
    for x0 in (-775, 475):                                                            # steel benches
        b.R(x0, -600, x0 + 300, 600, r=8)
        b.slats(x0, -600, x0 + 300, 600, 3, axis="y")                                 # plank joints
        b.L((x0, 0), (x0 + 300, 0), fine=True)                                        # 2 seats per bench
    b.R(-375, -600, 375, 600, r=10)                                                   # steel table
    b.R(-345, -570, 345, 570, r=6, fine=True)                                         # rolled edge


@reg("FUR-BOOTH4-1500", "Furniture", "centre of the table; bench seats north + south", 1500, 1850)
def _booth(b):
    for s in (-1, 1):
        y0, y1 = s * 375, s * 925
        b.R(-750, min(y0, y1), 750, max(y0, y1), r=15)                                # bench
        b.R(-750, min(s * 825, y1), 750, max(s * 825, y1), r=8)                       # back rest
        for x in (-250, 250):
            b.L((x, y0), (x, s * 825), fine=True)
    b.R(-600, -375, 600, 375, r=15)
    b.R(-570, -345, 570, 345, r=8, fine=True)


@reg("FUR-BENCH-COMM-3000", "Furniture", "centre of the table; bench seats north + south", 3000, 1700)
def _comm(b):
    for s in (-1, 1):
        b.R(-1500, min(s * 500, s * 850), 1500, max(s * 500, s * 850), r=10)
        for x in range(-1000, 1001, 500):
            b.L((x, s * 500), (x, s * 850), fine=True)
    b.R(-1500, -450, 1500, 450, r=12)
    b.R(-1470, -420, 1470, 420, r=8, fine=True)


def _bench(b, w, d):
    """plank bench: back-centre, w x d."""
    b.R(-w / 2, 0, w / 2, d, r=10)
    b.R(-w / 2 + 25, 25, w / 2 - 25, d - 25, fine=True)
    b.slats(-w / 2 + 25, 25, w / 2 - 25, d - 25, max(2, int(round((d - 50) / 110.0))), axis="x")


for _w, _d, _nm in ((3000, 450, "FUR-BENCH-3000"), (2800, 450, "FUR-BENCH-2800"), (1800, 450, "FUR-BENCH-1800"),
                    (1500, 400, "FUR-BENCH-1500x400"), (1200, 350, "FUR-BENCH-1200x350")):
    reg(_nm, "Furniture", "back-centre on the wall face", _w, _d)((lambda w, d: (lambda b: _bench(b, w, d)))(_w, _d))


@reg("FUR-CHARPOY-1900", "Furniture", "centre", 1900, 1000)
def _charpoy(b):
    b.R(-950, -500, 950, 500, r=22)                                                   # timber frame
    b.R(-890, -440, 890, 440, fine=True)
    for x in range(-750, 751, 150):                                                   # woven jute
        b.L((x, -440), (x, 440), fine=True)
    for y in range(-300, 301, 150):
        b.L((-890, y), (890, y), fine=True)
    for sx in (-1, 1):                                                                # turned legs
        for sy in (-1, 1):
            b.R(sx * 950 - sx * 70, sy * 500 - sy * 70, sx * 950, sy * 500, r=10)


def _sofa(b, w):
    d, arm, bk = 900, 190, 230
    b.R(-w / 2, 0, w / 2, d, r=65)
    b.R(-w / 2, 0, -w / 2 + arm, d, r=50)                                             # arms
    b.R(w / 2 - arm, 0, w / 2, d, r=50)
    b.R(-w / 2 + arm, 0, w / 2 - arm, bk, r=40)                                       # back cushion
    n = 3 if w >= 2000 else 2
    inner = w - 2 * arm
    for i in range(n):                                                                # seat cushions
        x0 = -w / 2 + arm + inner * i / n + 8
        x1 = -w / 2 + arm + inner * (i + 1) / n - 8
        b.R(x0, bk + 8, x1, d - 35, r=38)
    for ang, cx in ((24, -w / 2 + arm + 160), (-18, w / 2 - arm - 160)):              # scatter cushions
        c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
        pts = [(-130, -110), (130, -110), (130, 110), (-130, 110)]
        b.PLB([(cx + x * c - y * s, bk + 190 + x * s + y * c, 0) for x, y in pts], True)


reg("FUR-SOFA3-2000", "Furniture", "back-centre against the wall", 2000, 900)(lambda b: _sofa(b, 2000))
reg("FUR-SOFA2-1500", "Furniture", "back-centre against the wall", 1500, 900)(lambda b: _sofa(b, 1500))


# ---- kids soft-play corner (low fence with a 900 gate gap, soft mat grid, ball pit, slide, play house)
def _kids(b, gate):
    W, D = 3000, 2400
    b.PLB(rr_open(-W / 2, -D / 2, W / 2, D / 2, 130, gate, 900), False)                    # low fence (outer)
    b.PLB(rr_open(-W / 2 + 60, -D / 2 + 60, W / 2 - 60, D / 2 - 60, 80, gate, 900), False)  # inner line
    for x in range(-W // 2 + 660, W // 2 - 60, 600):                                       # 600 mat tiles
        b.L((x, -D / 2 + 60), (x, D / 2 - 60), fine=True)
    for y in range(-D // 2 + 660, D // 2 - 60, 600):
        b.L((-W / 2 + 60, y), (W / 2 - 60, y), fine=True)
    b.C(-800, -300, 520)                                                                   # ball pit
    b.C(-800, -300, 470, fine=True)
    for ang, rr in ((20, 300), (95, 250), (170, 320), (245, 260), (320, 330), (0, 0)):
        b.C(-800 + rr * math.cos(math.radians(ang)), -300 + rr * math.sin(math.radians(ang)), 70, fine=True)
    b.R(430, -D / 2 + 110, 1070, 300, r=40)                                                # slide
    for y in range(-D // 2 + 330, 250, 160):
        b.L((450, y), (1050, y), fine=True)
    b.R(430, 300, 1070, 520, r=30)                                                         # slide platform
    b.R(1000, 520, 1360, 880, r=20)                                                        # play house
    b.L((1000, 520), (1360, 880), fine=True)
    b.L((1000, 880), (1360, 520), fine=True)


reg("FUR-KIDSPLAY-3000", "Furniture", "centre; gate gap on the north (+Y) side", 3000, 2400)(lambda b: _kids(b, "N"))
reg("FUR-KIDSPLAY-3000-GATE-E", "Furniture", "centre; gate gap on the east (+X) side", 3000, 2400)(
    lambda b: _kids(b, "E"))


# ================================================================== COUNTERS, DESKS, STORAGE, MISC FURNITURE
def _bartop(b, w):
    """garden bar counter top on the parapet: w x 450, back-centre, rounded nosing on +Y."""
    b.R(-w / 2, 0, w / 2, 450, r4=(0, 0, 60, 60))
    b.R(-w / 2 + 25, 25, w / 2 - 25, 400, r4=(0, 0, 40, 40), fine=True)               # slab edge
    n = int(round(w / 1100.0))
    for i in range(1, n):                                                             # stone slab joints
        x = -w / 2 + w * i / n
        b.L((x, 25), (x, 425), fine=True)


for _w in (5400, 5600, 5900):
    reg("FUR-BARTOP-%dx450" % _w, "Furniture", "back-centre on the parapet", _w, 450)(
        (lambda w: (lambda b: _bartop(b, w)))(_w))


@reg("FUR-CTR-PLAIN-2700", "Furniture", "back-centre; serving side +Y", 2700, 700)
def _ctr_plain(b):
    b.R(-1350, 0, 1350, 700)
    b.R(-1320, 30, 1320, 670, fine=True)                                              # worktop edge
    b.L((-1350, 120), (1350, 120), fine=True)                                         # back shelf line


@reg("FUR-CTR-ROUNDED-5000x3500", "Furniture", "centre; north edge straight, south corners r = 1750", 5000, 3500)
def _ctr_round(b):
    b.PLB([(-2500, 1750, 0), (-2500, 0, B90), (-750, -1750, 0), (750, -1750, B90), (2500, 0, 0), (2500, 1750, 0)], True)
    b.PLB([(-2000, 1750, 0), (-2000, 0, B90), (-750, -1250, 0), (750, -1250, B90), (2000, 0, 0), (2000, 1750, 0)],
          False, fine=True)                                                           # 500 thick top, inner edge


def _counter(b, n):
    b.R(-n / 2, 0, n / 2, 700)
    b.L((-n / 2, 450), (n / 2, 450))                                                  # 450 customer top / 250 back bench
    b.R(-n / 2 + 30, 480, n / 2 - 30, 670, fine=True)
    tx = n / 2 - 450                                                                  # till box at +X end
    b.R(tx - 175, 60, tx + 175, 360, r=20)
    b.L((tx - 175, 60), (tx + 175, 360), fine=True)
    b.L((tx - 175, 360), (tx + 175, 60), fine=True)


for _n in (2000, 3000, 4000):
    reg("FUR-CTR-%d" % _n, "Furniture", "back-centre; customer side +Y", _n, 700)(
        (lambda n: (lambda b: _counter(b, n)))(_n))


@reg("FUR-CTR-ACC-1500", "Furniture", "back-centre; lowered 750 accessible counter", 1500, 600)
def _ctr_acc(b):
    b.R(-750, 0, 750, 600)
    b.R(-720, 30, 720, 570, fine=True)
    b.R(-400, 100, 400, 600, dash=True)                                               # knee space 800 x 500
    b.L((-750, 600), (750, 600), lw=40)


@reg("FUR-CTR-L-3000", "Furniture", "inner (wall) corner", 3000, 2000)
def _ctr_l(b):
    b.PLB([(0, 0, 0), (3000, 0, 0), (3000, 700, 0), (700, 700, 0), (700, 2000, 0), (0, 2000, 0)], True)
    b.PLB([(40, 40, 0), (2960, 40, 0), (2960, 660, 0), (660, 660, 0), (660, 1960, 0), (40, 1960, 0)], True, fine=True)
    b.R(2300, 80, 2800, 380, r=20)                                                    # till
    b.L((2300, 80), (2800, 380), fine=True)
    b.L((2300, 380), (2800, 80), fine=True)


@reg("FUR-DISPLAY-1200", "Furniture", "back-centre", 1200, 600)
def _display(b):
    b.R(-600, 0, 600, 600)
    b.R(-570, 30, 570, 570, fine=True)
    b.slats(-570, 30, 570, 570, 3, axis="x")


@reg("FUR-LEDGE-4500x350", "Furniture", "centre; chai ledge", 4500, 350)
def _ledge(b):
    b.R(-2250, -175, 2250, 175, r=12)
    b.R(-2220, -145, 2220, 145, fine=True)
    for i in range(1, 4):
        x = -2250 + 4500 * i / 4
        b.L((x, -145), (x, 145), fine=True)                                           # slab joints


@reg("FUR-WASHCTR-4000x600", "Furniture", "centre; hall wash counter slab (basins sit on it)", 4000, 600)
def _washctr_hall(b):
    b.R(-2000, -300, 2000, 300, r=20)
    b.R(-1970, -270, 1970, 270, r=12, fine=True)
    for i in range(1, 4):
        x = -2000 + 4000 * i / 4
        b.L((x, -270), (x, 270), fine=True)


@reg("FUR-PLANTER-BENCH-2500x600", "Furniture", "centre; planter south (-Y), timber bench north (+Y)", 2500, 600)
def _planter_bench(b):
    b.R(-1250, -300, 1250, 0, r=15)                                                   # planter box
    b.R(-1215, -265, 1215, -35, fine=True)                                            # soil edge
    for x, rr in ((-800, 105), (-250, 95), (320, 110), (850, 100)):                    # plants
        b.BLOB(x, -150, rr, int(x), fine=True)
        b.C(x, -150, 16, fine=True)
    b.R(-1250, 0, 1250, 300, r=10)                                                    # timber bench
    b.R(-1225, 25, 1225, 275, fine=True)
    b.slats(-1225, 25, 1225, 275, 3, axis="x")


@reg("FUR-TREESEAT-R1400", "Furniture", "centre; ring bench r 1000-1400 round a tree", 2800, 2800)
def _treeseat(b):
    h = b._hatch([(-1400, 0, 1), (1400, 0, 1)])
    h.paths.add_polyline_path([(-1000, 0, 1), (1000, 0, 1)], is_closed=True)           # ring: outer + hole
    b.blk.add_circle((0, 0), 1400, dxfattribs=b._a())
    b.blk.add_circle((0, 0), 1000, dxfattribs=b._a())
    b.blk.add_circle((0, 0), 1200, dxfattribs=b._a(fine=True))                        # centre line of the seat
    for i in range(12):                                                               # 12 timber segments
        a = math.radians(i * 30 + 15)
        b.L((1000 * math.cos(a), 1000 * math.sin(a)), (1400 * math.cos(a), 1400 * math.sin(a)), fine=True)


@reg("FUR-MAT-RUBBER-1000x2400", "Furniture", "centre; flat rubber mat (no height)", 1000, 2400)
def _rubbermat(b):
    b.R(-500, -1200, 500, 1200, r=15)
    b.R(-460, -1160, 460, 1160, fine=True)
    b.diag(-460, -1160, 460, 1160, 130, 45)


@reg("FUR-DESK-1500x750", "Furniture", "centre; user sits on the +Y side", 1500, 750)
def _desk1500(b):
    b.R(-750, -375, 750, 375, r=12)
    b.R(-720, -345, 720, 345, r=6, fine=True)
    b.R(-210, -330, 210, -285, r=8)                                                   # monitor
    b.L((0, -285), (0, -240))
    b.R(-210, -120, 210, 20, r=10, fine=True)                                         # keyboard
    b.R(300, -100, 360, 10, r=28, fine=True)                                          # mouse
    b.R(-640, -300, -400, -60, r=12, fine=True)                                       # paper tray


@reg("FUR-DESK-1200x600", "Furniture", "back-centre; CCTV desk, user on the +Y side", 1200, 600)
def _desk1200(b):
    b.R(-600, 0, 600, 600, r=10)
    b.R(-570, 30, 570, 570, r=6, fine=True)
    for x in (-300, 300):                                                             # two monitors
        b.R(x - 190, 50, x + 190, 105, r=8)
        b.L((x, 105), (x, 150))
    b.R(-200, 330, 200, 470, r=10, fine=True)                                         # keyboard
    b.R(300, 340, 360, 450, r=28, fine=True)                                          # mouse


@reg("FUR-DESK-1200", "Furniture", "back-centre; desk + chair on the +Y side", 1200, 1450)
def _desk_chair(b):
    b.INS("FUR-CHAIR-OFFICE-550", (0, 960), 180)
    b.R(-600, 0, 600, 600, r=10)
    b.R(-570, 30, 570, 570, r=6, fine=True)
    b.R(-230, 60, 230, 130, r=8)                                                      # monitor
    b.R(-175, 300, 175, 450, r=15, fine=True)                                         # keyboard


@reg("FUR-CABINET-450x600", "Furniture", "back-centre; drawers face +Y", 450, 600)
def _cabinet(b):
    b.R(-225, 0, 225, 600, r=6)
    b.R(-195, 30, 195, 570, fine=True)
    for y in (400, 480):
        b.L((-195, y), (195, y), fine=True)
    for y in (350, 440, 520):
        b.L((-60, y), (60, y), lw=35)                                                 # drawer pulls
    b.C(0, 150, 14, fine=True)                                                        # lock


@reg("FUR-LOCKER-450", "Furniture", "back-centre; doors face +Y", 450, 500)
def _locker(b):
    b.R(-225, 0, 225, 500, r=5)
    b.R(-205, 20, 205, 480, fine=True)                                                # top panel
    for y in (390, 420, 450):
        b.L((-110, y), (110, y), fine=True)                                           # louvre slots
    b.L((140, 300), (140, 340), lw=40)                                                # handle
    b.L((-225, 500), (225, 500), lw=40)                                               # door line


def _rack(b, w, d):
    """steel store rack: wire shelf with corner posts."""
    b.R(-w / 2, 0, w / 2, d)
    b.R(-w / 2 + 40, 40, w / 2 - 40, d - 40, fine=True)
    b.slats(-w / 2 + 40, 40, w / 2 - 40, d - 40, 5, axis="x")
    for sx in (-1, 1):
        for y in (0, d - 50):
            b.R(sx * (w / 2 - 25) - 25, y, sx * (w / 2 - 25) + 25, y + 50)            # posts


reg("FUR-RACK-1200x600", "Furniture", "back-centre; steel store rack", 1200, 600)(lambda b: _rack(b, 1200, 600))
reg("FUR-RACK-1200x500", "Furniture", "back-centre; cold-room shelf rack", 1200, 500)(lambda b: _rack(b, 1200, 500))


@reg("FUR-SAFE-500", "Furniture", "back-centre; door faces +Y", 500, 500)
def _safe(b):
    b.R(-250, 0, 250, 500, r=8)
    b.R(-215, 40, 215, 455, r=5, fine=True)
    b.C(0, 250, 70)                                                                   # dial
    b.C(0, 250, 40, fine=True)
    b.L((70, 250), (150, 250), lw=40)                                                 # handle


@reg("FUR-SHELF-700x300", "Furniture", "back-centre; wall shelf", 700, 300)
def _shelf700(b):
    b.R(-350, 0, 350, 300, r=5)
    b.R(-320, 30, 320, 270, fine=True)
    b.slats(-320, 30, 320, 270, 3, axis="x")


@reg("FUR-SHELF-LOW-1200", "Furniture", "back-centre; low toy shelf, 5 bays", 1200, 300)
def _shelf_low(b):
    b.R(-600, 0, 600, 300, r=8)
    for i in range(1, 5):
        x = -600 + 1200 * i / 5
        b.L((x, 15), (x, 285), fine=True)
    for i in range(5):                                                                # toy bins
        x0 = -600 + 240 * i
        b.R(x0 + 40, 60, x0 + 200, 240, r=18, fine=True)


@reg("FUR-HOOKRAIL-600x50", "Furniture", "back-centre; wall hook rail", 600, 50)
def _hookrail(b):
    b.R(-300, 0, 300, 25)
    for x in (-225, -75, 75, 225):
        b.C(x, 25, 10)
        b.L((x, 35), (x, 50), lw=35)


@reg("FUR-SIGN-WALL-600", "Furniture", "back-centre; wall sign plate", 600, 100)
def _sign(b):
    b.R(-300, 0, 300, 100, r=8)
    b.R(-270, 22, 270, 78, fine=True)
    for x in (-250, 250):
        b.C(x, 50, 8, fine=True)


@reg("FUR-CHARGE-POST-300", "Furniture", "centre; phone-charging post", 300, 300)
def _charge(b):
    b.R(-150, -150, 150, 150, r=40)
    b.C(0, 0, 105, fine=True)
    b.R(-60, -60, 60, 60, r=20)                                                       # socket cluster
    b.C(-25, 0, 12, fine=True)
    b.C(25, 0, 12, fine=True)


@reg("FUR-VEND-PAD-400x200", "Furniture", "back-centre; dispenser faces +Y", 400, 200)
def _vend(b):
    b.R(-200, 0, 200, 200, r=10)
    b.R(-160, 40, 160, 160, r=6, fine=True)
    b.R(-60, 70, 60, 130, r=4, fine=True)                                             # dispensing window
    b.C(110, 100, 18, fine=True)                                                      # coin slot
    b.L((-120, 60), (-120, 140), fine=True)


def _stool(b, dia):
    r = dia / 2.0
    b.C(0, 0, r)
    b.C(0, 0, r * 0.72, fine=True)                                                    # seat pad ring
    b.C(0, 0, r * 0.12, fine=True)


reg("FUR-STOOL-350", "Furniture", "centre; round bar stool", 350, 350)(lambda b: _stool(b, 350))
reg("FUR-STOOL-340", "Furniture", "centre; round bar stool", 340, 340)(lambda b: _stool(b, 340))


@reg("FUR-BIN-400", "Furniture", "centre; round bin with lid", 400, 400)
def _bin400(b):
    b.C(0, 0, 200)
    b.C(0, 0, 165, fine=True)
    b.R(-40, 150, 40, 185, r=10, fine=True)                                           # lid flap


@reg("FUR-BIN-DUAL-800x400", "Furniture", "back-centre; dry + wet bin pair", 800, 400)
def _bindual(b):
    for x in (-200, 200):
        b.R(x - 190, 10, x + 190, 390, r=30)
        b.R(x - 150, 50, x + 150, 350, r=20, fine=True)
        b.L((x - 70, 370), (x + 70, 370), fine=True)


# ================================================================== KITCHEN AND SERVICE EQUIPMENT
def _burner(b, cx, cy, s=1.0):
    b.C(cx, cy, 100 * s)
    b.C(cx, cy, 56 * s, fine=True)
    b.L((cx - 150 * s, cy), (cx + 150 * s, cy), fine=True)                            # pan-support cross
    b.L((cx, cy - 150 * s), (cx, cy + 150 * s), fine=True)


def _range(b, w, d, ncol):
    b.R(-w / 2, 0, w / 2, d, r=8)
    b.L((-w / 2, d - 115), (w / 2, d - 115))                                          # control strip
    pitch = (w - 100) / ncol
    sc = 0.9 if d < 900 else 1.0
    for i in range(ncol):
        x = -w / 2 + 50 + pitch * (i + 0.5)
        _burner(b, x, d * 0.27, sc)
        _burner(b, x, d * 0.62, sc)
        b.C(x - 70, d - 55, 22)                                                       # control knobs
        b.C(x + 70, d - 55, 22)


reg("EQP-RANGE6-1800", "Equipment", "back-centre; 6 burners, knobs on +Y", 1800, 900)(
    lambda b: _range(b, 1800, 900, 3))
reg("EQP-RANGE6-1500", "Equipment", "back-centre; 6 burners, knobs on +Y", 1500, 800)(
    lambda b: _range(b, 1500, 800, 3))
reg("EQP-RANGE4-1200", "Equipment", "back-centre; 4 burners, knobs on +Y", 1200, 800)(
    lambda b: _range(b, 1200, 800, 2))


@reg("EQP-TAWA-1200", "Equipment", "back-centre; flat-top tawa, knobs on +Y", 1200, 900)
def _tawa1200(b):
    b.R(-600, 0, 600, 900, r=10)
    b.R(-565, 45, 565, 790, r=25, fine=True)                                          # flat plate
    b.C(0, 420, 340)                                                                  # big round tawa
    b.C(0, 420, 295, fine=True)
    b.R(340, 395, 520, 445, r=18)                                                     # tawa handle
    b.L((-565, 770), (565, 770), fine=True)                                           # grease trough
    for x in (-450, -150, 150, 450):
        b.C(x, 850, 24)                                                               # knobs


@reg("EQP-TANDOOR-900", "Equipment", "centre; working side +Y", 900, 900)
def _tandoor(b):
    b.R(-450, -450, 450, 450, r=28)                                                   # steel plinth
    b.R(-430, -430, 430, 430, r=20, fine=True)
    b.C(0, 0, 350)                                                                    # clay body
    b.C(0, 0, 300, fine=True)
    b.C(0, 0, 250)                                                                    # mouth rim
    b.C(0, 0, 190, fine=True)
    b.R(-110, 350, 110, 450, r=10)                                                    # fire door, working side
    b.L((-60, 450), (60, 450), lw=50)


@reg("EQP-DOSA-TAWA-1000", "Equipment", "centre; large round griddle", 1100, 1100)
def _dosa_tawa(b):
    b.R(-550, -550, 550, 550, r=32)
    b.R(-530, -530, 530, 530, r=24, fine=True)
    b.C(0, 0, 500)
    b.C(0, 0, 470, fine=True)
    b.C(0, 0, 300, fine=True)
    b.C(0, 0, 150, fine=True)
    b.R(-60, 500, 60, 550, r=15)                                                      # handle


@reg("EQP-DOSA-HEARTH-1800", "Equipment", "back-centre; two round tawas, cook on +Y", 1800, 900)
def _hearth(b):
    b.R(-900, 0, 900, 900, r=8)
    b.L((-900, 830), (900, 830))
    for sx in (-1, 1):
        b.C(sx * 450, 430, 395)
        b.C(sx * 450, 430, 360, fine=True)
        b.C(sx * 450, 430, 200, fine=True)
        b.R(sx * 450 - 240, 845, sx * 450 + 240, 895, r=12, fine=True)                # firebox door
    b.R(-60, 845, 60, 895, r=12, fine=True)


def _hood(b, n):
    b.R(-n / 2, 0, n / 2, 1100, dash=True)
    b.R(-n / 2 + 100, 100, n / 2 - 100, 1000, dash=True)
    for sx, sy in ((-1, 0), (1, 0), (-1, 1), (1, 1)):                                 # sloping sides in plan
        b.L((sx * n / 2, sy * 1100), (sx * (n / 2 - 100), 100 + sy * 900), dash=True)
    m = max(1, int(round(n / 2000.0)))
    for i in range(m):
        b.C(-n / 2 + n * (i + 0.5) / m, 550, 180, dash=True)                          # duct stubs


for _n in (1200, 1500, 1800, 2400, 5338):
    reg("EQP-HOOD-%d" % _n, "Equipment", "back-centre; overhead (dashed), over the cooking line", _n, 1100)(
        (lambda n: (lambda b: _hood(b, n)))(_n))


def _sink(b, w, nbowl, board):
    b.R(-w / 2, 0, w / 2, 700, r=8)
    b.R(-w / 2 + 25, 25, w / 2 - 25, 675, r=4, fine=True)
    if board:
        bw, gap, x = 500, 60, -w / 2 + 70
    else:
        gap = 70
        bw = (w - 140 - (nbowl - 1) * gap) / nbowl
        x = -w / 2 + 70
    centres = []
    for i in range(nbowl):
        b.R(x, 130, x + bw, 560, r=50)
        b.R(x + 28, 158, x + bw - 28, 532, r=34, fine=True)
        b.C(x + bw / 2, 345, 26)                                                      # waste
        b.C(x + bw / 2, 345, 9, fine=True)
        centres.append(x + bw / 2)
        x += bw + gap
    tapx = sum(centres[:2]) / len(centres[:2]) if nbowl >= 2 else centres[0]
    b.C(tapx, 68, 24)                                                                 # mixer tap
    b.L((tapx, 68), (tapx, 170), lw=35)
    b.C(tapx, 170, 12)
    if board:                                                                         # draining board
        dx0 = x - gap + 30
        b.L((dx0, 140), (dx0, 580), fine=True)
        gx = dx0 + 60
        while gx < w / 2 - 60:
            b.L((gx, 170), (gx, 550), fine=True)
            gx += 60


reg("EQP-SINK1-900", "Equipment", "back-centre; 1 bowl + draining board", 900, 700)(lambda b: _sink(b, 900, 1, True))
reg("EQP-SINK2-1300", "Equipment", "back-centre; pot sink, 2 bowls", 1300, 700)(lambda b: _sink(b, 1300, 2, False))
reg("EQP-SINK2-1800", "Equipment", "back-centre; 2 bowls + draining board", 1800, 700)(
    lambda b: _sink(b, 1800, 2, True))


def _prep(b, n, pans=False):
    b.R(-n / 2, 0, n / 2, 700)
    b.R(-n / 2 + 30, 30, n / 2 - 30, 670, fine=True)
    b.L((-n / 2 + 30, 110), (n / 2 - 30, 110), fine=True)                             # upstand line
    if pans:
        m = int((n - 200) // 400)
        for i in range(m):                                                            # cold pan wells
            x = -n / 2 + n * (i + 0.5) / m
            b.R(x - 170, 230, x + 170, 580, r=14, fine=True)
    else:
        b.R(-n / 2 + 80, 160, n / 2 - 80, 620, dash=True)                             # under-shelf (hidden)


for _n in (700, 1200, 1500, 1800, 2400):
    reg("EQP-PREP-%d" % _n, "Equipment", "back-centre; prep counter", _n, 700)(
        (lambda n: (lambda b: _prep(b, n)))(_n))
reg("EQP-PREP-3200", "Equipment", "back-centre; cold prep counter with pan wells", 3200, 700)(
    lambda b: _prep(b, 3200, True))


@reg("EQP-ISLAND-2400x900", "Equipment", "centre; prep island, work from both long sides", 2400, 900)
def _island(b):
    b.R(-1200, -450, 1200, 450, r=18)
    b.R(-1170, -420, 1170, 420, r=10, fine=True)
    b.R(-1090, -340, 1090, 340, dash=True)                                            # under-shelf (hidden)
    b.R(-640, -150, -140, 170, r=20, fine=True)                                       # cutting boards
    b.R(150, -140, 650, 160, r=20, fine=True)
    b.L((-1000, 390), (1000, 390), lw=35)                                             # pot rail


@reg("EQP-PASS-1300x300", "Equipment", "back-centre; pass shelf at a serving hatch", 1300, 300)
def _pass(b):
    b.R(-650, 0, 650, 300, r=6)
    b.R(-620, 30, 620, 270, fine=True)
    b.L((-650, 150), (650, 150), fine=True)


@reg("EQP-FRIDGE-1000x700", "Equipment", "back-centre; 2-door reach-in, doors on +Y", 1000, 700)
def _fridge1000(b):
    b.R(-500, 0, 500, 700, r=8)
    b.L((-500, 650), (500, 650))                                                      # door line
    b.L((0, 650), (0, 700))
    b.R(-440, 40, 440, 150, r=4, fine=True)                                           # compressor grille
    for x in range(-390, 391, 65):
        b.L((x, 55), (x, 135), fine=True)
    for x in (-60, 60):
        b.L((x, 665), (x, 690), lw=40)                                                # handles
    b.R(-470, 190, 470, 620, fine=True)


@reg("EQP-FREEZER-700x800", "Equipment", "back-centre; reach-in freezer, door on +Y", 700, 800)
def _freezer(b):
    b.R(-350, 0, 350, 800, r=8)
    b.L((-350, 740), (350, 740))
    b.R(-300, 40, 300, 150, r=4, fine=True)
    for x in range(-250, 251, 50):
        b.L((x, 55), (x, 135), fine=True)
    b.L((250, 755), (250, 790), lw=40)
    b.R(-320, 190, 320, 710, fine=True)
    b.diag(-320, 190, 320, 710, 130, 45)                                              # insulated top


@reg("EQP-FRIDGE-700", "Equipment", "back-centre; single door swings 90 deg", 700, 1500)
def _fridge700(b):
    b.R(-350, 0, 350, 800, r=8)
    b.L((-350, 740), (350, 740))
    b.R(-300, 40, 300, 130, r=4, fine=True)
    for x in range(-250, 251, 50):
        b.L((x, 52), (x, 118), fine=True)
    b.R(-350, 800, -310, 1500)                                                        # open door leaf
    b.A(-350, 800, 700, 0, 90, fine=True)                                             # swing arc


@reg("EQP-FRYER-600", "Equipment", "back-centre; twin fryer, baskets on +Y", 600, 900)
def _fryer600(b):
    b.R(-300, 0, 300, 900, r=10)
    for x in (-150, 150):
        b.R(x - 115, 150, x + 115, 580, r=24)
        b.R(x - 90, 175, x + 90, 555, r=14, fine=True)
        b.L((x, 580), (x, 700), lw=35)                                                # basket handle
        b.R(x - 30, 700, x + 30, 760, r=12)
    b.L((-300, 790), (300, 790))
    for x in (-150, 150):
        b.C(x, 845, 22)


@reg("EQP-FRYER-450", "Equipment", "back-centre; single fryer", 450, 750)
def _fryer450(b):
    b.R(-225, 0, 225, 750, r=8)
    b.R(-170, 120, 170, 540, r=24)
    b.R(-145, 145, 145, 515, r=14, fine=True)
    b.L((0, 540), (0, 660), lw=35)
    b.R(-30, 660, 30, 720, r=12)


@reg("EQP-DISHWASHER-700", "Equipment", "back-centre; door + control panel on +Y", 700, 700)
def _dishwasher(b):
    b.R(-350, 0, 350, 700, r=8)
    b.L((-350, 615), (350, 615))
    for x in (-110, 0, 110):
        b.C(x, 658, 16)
    b.R(-290, 60, 290, 560, dash=True)                                                # rack (hidden)
    b.C(0, 310, 170, dash=True)                                                       # spray arm


@reg("EQP-CHAI-BOILER-600", "Equipment", "centre; chai boiler, tap on +Y", 600, 600)
def _chai(b):
    b.R(-300, -300, 300, 300, r=25)
    b.C(0, -10, 225)
    b.C(0, -10, 190, fine=True)
    b.C(0, -10, 40, fine=True)                                                        # lid knob
    b.R(-28, 230, 28, 300, r=12)                                                      # tap spout
    b.C(-215, 215, 20, fine=True)                                                     # gauge


@reg("EQP-RO-UNIT-500", "Equipment", "centre; drinking-water RO unit", 500, 500)
def _ro(b):
    b.R(-250, -250, 250, 250, r=30)
    b.R(-215, -215, 215, 215, r=20, fine=True)
    for x in (-120, 0, 120):
        b.C(x, -50, 48)                                                               # filter cartridges
    b.C(0, 150, 22)                                                                   # tap
    b.L((0, 150), (0, 200), lw=35)


@reg("EQP-SCALE-600", "Equipment", "centre; platform weighing scale", 600, 600)
def _scale(b):
    b.R(-300, -300, 300, 300, r=20)
    b.R(-260, -260, 260, 190, r=10, fine=True)
    b.diag(-260, -260, 260, 190, 75, 45)                                              # tread plate
    b.R(-110, 215, 110, 275, r=8)                                                     # display
    b.C(180, 245, 12, fine=True)


@reg("EQP-POS-400", "Equipment", "centre; cash / POS, customer on +Y", 400, 400)
def _pos(b):
    b.R(-200, -200, 200, 200, r=30)
    b.R(-135, -175, 135, -115, r=8)                                                   # display
    b.R(-150, -80, 150, 100, r=12, fine=True)                                         # cash drawer
    b.R(30, 125, 160, 180, r=8, fine=True)                                            # card reader
    b.C(-100, 150, 14, fine=True)


def _foodlift(b, w):
    h = w / 2.0
    b.R(-h, -h, h, h)
    b.R(-h + 60, -h + 60, h - 60, h - 60, fine=True)                                  # car
    b.L((-h + 60, -h + 60), (h - 60, h - 60), fine=True)
    b.L((-h + 60, h - 60), (h - 60, -h + 60), fine=True)
    for x in (-h + 130, 0, h - 130):                                                  # door leaf marks on +Y
        b.L((x, h - 60), (x, h), fine=True)


reg("EQP-FOODLIFT-800", "Equipment", "centre; food lift (dumb waiter) car", 800, 800)(lambda b: _foodlift(b, 800))
reg("EQP-FOODLIFT-980", "Equipment", "centre; food lift (dumb waiter) car", 980, 980)(lambda b: _foodlift(b, 980))


@reg("EQP-HOTCASE-1200", "Equipment", "back-centre; hot food case on the counter", 1200, 600)
def _hotcase(b):
    b.R(-600, 0, 600, 600, r=15)
    b.R(-570, 30, 570, 570, r=8, fine=True)
    for x in (-380, 0, 380):
        b.R(x - 170, 110, x + 170, 460, r=12, fine=True)                              # pan wells
    b.L((-570, 530), (570, 530), lw=25)                                               # sneeze guard


@reg("EQP-PLATERACK-900", "Equipment", "back-centre; plate rack / tray stack on the counter", 900, 450)
def _platerack(b):
    b.R(-450, 0, 450, 450, r=8)
    b.R(-420, 30, 420, 420, fine=True)
    for i in range(4):
        x = -337.5 + 225 * i
        b.C(x, 225, 92)
        b.C(x, 225, 58, fine=True)


@reg("EQP-PANEL-LT-2400x600", "Equipment", "back-centre; LT panel, doors on +Y", 2400, 600)
def _panel(b):
    b.R(-1200, 0, 1200, 600)
    b.R(-1170, 30, 1170, 570, fine=True)
    for x in (-600, 0, 600):
        b.L((x, 450), (x, 600))                                                       # door joints
    b.L((-1200, 450), (1200, 450))
    for x in (-540, -60, 60, 540):
        b.L((x, 500), (x, 560), lw=35)                                                # door handles


@reg("EQP-UPS-800x600", "Equipment", "back-centre; UPS / inverter, panel on +Y", 800, 600)
def _ups(b):
    b.R(-400, 0, 400, 600, r=10)
    b.R(-370, 30, 370, 570, r=6, fine=True)
    for i in range(6):
        b.L((-300, 330 + 32 * i), (300, 330 + 32 * i), fine=True)                     # vent slots
    b.R(-170, 70, 170, 150, r=6)                                                      # display
    for x in (-300, 300):
        b.C(x, 110, 16, fine=True)                                                    # indicator lamps


@reg("EQP-BATTERY-RACK-1200x500", "Equipment", "back-centre; battery rack, 2 rows", 1200, 500)
def _battery(b):
    b.R(-600, 0, 600, 500)
    b.R(-570, 30, 570, 470, fine=True)
    for row in (60, 270):
        for i in range(5):
            x = -560 + 224 * i + 12
            b.R(x, row, x + 200, row + 170, r=8)
            b.L((x + 30, row + 140), (x + 170, row + 140), fine=True)                  # terminal strip


@reg("EQP-CABLETRAY-2000x300", "Equipment", "back-centre; vertical cable tray", 2000, 300)
def _cabletray(b):
    b.R(-1000, 0, 1000, 300)
    b.L((-1000, 40), (1000, 40), fine=True)                                           # side rails
    b.L((-1000, 260), (1000, 260), fine=True)
    for x in range(-900, 901, 150):
        b.L((x, 40), (x, 260), fine=True)                                             # rungs


@reg("EQP-LPG-CYL-320", "Equipment", "centre; LPG cylinder (top view)", 320, 320)
def _lpg(b):
    b.C(0, 0, 160)
    b.C(0, 0, 132, fine=True)
    b.C(0, 0, 38)                                                                     # valve
    b.A(0, 0, 80, 20, 160, fine=True)                                                 # guard ring


@reg("EQP-GENSET-2500x1000", "Equipment", "centre; DG set in acoustic enclosure, doors on +Y", 2500, 1000)
def _genset(b):
    b.R(-1250, -500, 1250, 500, r=15)
    b.R(-1220, -470, 1220, 470, r=8, fine=True)
    b.L((250, -470), (250, 470), fine=True)
    for i in range(9):
        b.L((-1150 + 105 * i, -400), (-1150 + 105 * i, 400), fine=True)               # louvre slats
    b.C(750, -150, 90)                                                                # exhaust
    b.C(750, -150, 55, fine=True)
    for x in (-700, 700):
        b.L((x, 440), (x, 500))                                                       # door joints on +Y


@reg("EQP-COMPOST-DRUM-1000", "Equipment", "centre; compost drum (top view)", 1000, 1000)
def _compost(b):
    b.C(0, 0, 500)
    b.C(0, 0, 440, fine=True)
    b.R(-110, -60, 110, 60, r=30)                                                     # lid latch
    b.A(0, 0, 330, 200, 340, fine=True)


# ================================================================== SANITARY AND ACCESSIBILITY
@reg("SAN-WC-WEST", "Sanitary", "back-centre; cistern on the wall, bowl toward +Y", 400, 685)
def _ewc(b):
    b.R(-200, 0, 200, 200, r=25)                                                      # cistern
    b.R(-170, 28, 170, 172, r=14, fine=True)                                          # lid line
    b.C(100, 100, 24)                                                                 # flush button
    b.C(100, 100, 9, fine=True)
    b.E(0, 440, 180, 245)                                                             # bowl rim
    b.E(0, 452, 150, 213, fine=True)                                                  # seat ring
    b.E(0, 470, 105, 160)                                                             # seat opening
    b.E(0, 495, 62, 92, fine=True)                                                    # water
    for sx in (-1, 1):
        b.R(sx * 100 - 20, 205, sx * 100 + 20, 245, r=6, fine=True)                   # seat hinges


@reg("SAN-WC-INDIAN", "Sanitary", "back-centre; squat pan, foot rests toward +Y", 450, 590)
def _iwc(b):
    b.HULL((0, 365), 225, (0, 50), 50)                                                # pan outline
    b.HULL((0, 365), 178, (0, 60), 22, fine=True)                                     # pan bowl
    for sx in (-1, 1):                                                                # foot plates
        b.R(sx * 140 - 55, 300, sx * 140 + 55, 500, r=18)
        for y in (350, 400, 450):
            b.L((sx * 140 - 38, y), (sx * 140 + 38, y), fine=True)
    b.C(0, 150, 36)                                                                   # outlet
    b.C(0, 150, 12, fine=True)


@reg("SAN-WC-WALLHUNG-400x550", "Sanitary", "back-centre; wall-hung pan, concealed cistern", 400, 550)
def _wc_wh(b):
    b.PLB([(-200, 0, 0), (200, 0, 0), (200, 350, 1), (-200, 350, 0)], True)           # D-shaped pan
    b.PLB([(-160, 40, 0), (160, 40, 0), (160, 350, 1), (-160, 350, 0)], True, fine=True)   # seat
    b.E(0, 345, 118, 165)                                                             # opening
    b.E(0, 375, 68, 98, fine=True)                                                    # water
    for sx in (-1, 1):
        b.R(sx * 110 - 18, 42, sx * 110 + 18, 82, r=5, fine=True)                     # hinges


@reg("SAN-URINAL-400", "Sanitary", "back-centre; bowl on the wall", 400, 350)
def _urinal(b):
    b.PLB([(-200, 0, 0), (200, 0, 0), (200, 150, 1), (-200, 150, 0)], True)           # bowl outline
    b.PLB([(-160, 28, 0), (160, 28, 0), (160, 150, 1), (-160, 150, 0)], True, fine=True)   # lip
    b.L((-60, 40), (60, 40), fine=True)                                               # flush spreader
    b.C(0, 150, 20)                                                                   # waste
    b.C(0, 150, 7, fine=True)


@reg("SAN-URINAL-DIV", "Sanitary", "back-centre; modesty board", 40, 450)
def _urinal_div(b):
    b.R(-20, 0, 20, 450, r=4)


def _basin(b, w, d, bowl_ry, rr):
    """wall-hung wash basin: square back at the wall, rounded front."""
    b.R(-w / 2, 0, w / 2, d, r4=(0, 0, rr, rr))
    cy = d * 0.58
    rx = w * 0.39
    b.E(0, cy, rx, bowl_ry)                                                           # bowl
    b.E(0, cy, rx - 20, bowl_ry - 20, fine=True)
    b.C(0, cy, 17)                                                                    # waste
    ty = min(68, d * 0.17)
    b.C(0, ty, 21)                                                                    # tap
    b.L((0, ty), (0, ty + min(70, bowl_ry * 0.45)), lw=35)


reg("SAN-BASIN-550", "Sanitary", "back-centre; wall-hung basin", 550, 450)(lambda b: _basin(b, 550, 450, 150, 150))
reg("SAN-BASIN-500x400", "Sanitary", "back-centre; wall-hung basin", 500, 400)(lambda b: _basin(b, 500, 400, 130, 140))
reg("SAN-BASIN-HAND-450", "Sanitary", "back-centre; staff hand-wash basin", 450, 350)(
    lambda b: _basin(b, 450, 350, 105, 120))
reg("SAN-BASIN-HAND-400x280", "Sanitary", "back-centre; staff hand-wash basin", 400, 280)(
    lambda b: _basin(b, 400, 280, 88, 100))


@reg("SAN-BASIN-TROUGH-1500", "Sanitary", "back-centre; wash trough, 3 taps", 1500, 450)
def _trough1500(b):
    b.R(-750, 0, 750, 450, r=20)
    b.R(-700, 100, 700, 400, r=40, fine=True)
    for x in (-500, 0, 500):
        b.C(x, 55, 20)
        b.L((x, 55), (x, 120), lw=40)
        b.C(x, 260, 22, fine=True)


@reg("SAN-MOPSINK-600x500", "Sanitary", "back-centre; mop service basin", 600, 500)
def _mopsink(b):
    b.R(-300, 0, 300, 500, r=12)
    b.R(-250, 70, 250, 450, r=40, fine=True)
    b.C(0, 260, 28)
    b.C(0, 260, 10, fine=True)
    b.C(0, 32, 18)                                                                    # tap
    b.L((0, 32), (0, 100), lw=35)


@reg("SAN-BABYCHANGE-700", "Sanitary", "back-centre; fold-down baby-changing counter", 700, 500)
def _babychange(b):
    b.R(-350, 0, 350, 500, r4=(0, 0, 45, 45))
    b.R(-315, 35, 315, 465, r=40, fine=True)                                          # mattress
    for x in (-140, 140):
        b.L((x, 120), (x, 400), fine=True)                                            # safety strap
        b.C(x, 260, 12, fine=True)
    for x in (-260, 260):
        b.R(x - 25, 0, x + 25, 28, r=4, fine=True)                                    # hinge brackets


@reg("SAN-WASH-COUNTER-2300", "Sanitary", "back-centre; counter for 3 basins, mirror line on the wall",
     2300, 600)
def _washctr(b):
    b.R(-1150, 0, 1150, 600, r4=(0, 0, 35, 35))
    b.R(-1120, 30, 1120, 570, r4=(0, 0, 22, 22), fine=True)
    b.L((-1150, 22), (1150, 22), lw=35)                                               # mirror line


@reg("SAN-MIRROR-600", "Sanitary", "back-centre; mirror on the wall", 600, 20)
def _mirror(b):
    b.R(-300, 0, 300, 20)
    b.L((-250, 6), (250, 14), fine=True)


def _grab(b, w):
    b.R(-w / 2, 0, w / 2, 40, r=20)
    b.L((-w / 2 + 20, 20), (w / 2 - 20, 20), fine=True)
    for x in (-w / 2 + 60, w / 2 - 60):
        b.C(x, 20, 14, fine=True)                                                     # wall flanges


reg("SAN-GRAB-800x40", "Sanitary", "back-centre; grab bar on the wall", 800, 40)(lambda b: _grab(b, 800))
reg("SAN-GRABBAR-600", "Sanitary", "back-centre; grab bar on the wall", 600, 40)(lambda b: _grab(b, 600))
reg("SAN-GRABBAR-750", "Sanitary", "back-centre; grab bar on the wall", 750, 40)(lambda b: _grab(b, 750))


@reg("SAN-GRAB-DROP-40x700", "Sanitary", "back-centre; fold-down grab rail, hinged on the wall", 40, 700)
def _grab_drop(b):
    b.R(-20, 0, 20, 700, r=20)
    b.L((0, 40), (0, 660), fine=True)
    b.C(0, 40, 12, fine=True)
    b.C(0, 660, 12, fine=True)


@reg("SAN-TAP-100", "Sanitary", "centre; spout toward +Y", 100, 100)
def _tap(b):
    b.C(0, -15, 35)
    b.R(-50, -23, 50, -7, r=8, fine=True)                                             # lever
    b.R(-10, -15, 10, 50, r=10)                                                       # spout


@reg("SAN-TAP-DRINK-200x150", "Sanitary", "back-centre; drinking-water bubbler on the wall", 200, 150)
def _tap_drink(b):
    b.R(-100, 0, 100, 150, r4=(0, 0, 60, 60))
    b.E(0, 88, 62, 42, fine=True)
    b.C(0, 88, 8, fine=True)
    b.C(0, 32, 16)
    b.L((0, 32), (0, 70), lw=35)


@reg("SAN-TROUGH-800x6000", "Sanitary", "centre; long hand-wash trough, tap deck on the +X side", 800, 6000)
def _trough6000(b):
    b.R(-400, -3000, 400, 3000, r=45)
    b.R(-330, -2940, 200, 2940, r=60, fine=True)                                      # basin channel
    for i in range(6):
        y = -2500 + 1000 * i
        b.C(-65, y, 28)                                                               # waste every 1 m
        b.C(-65, y, 10, fine=True)


@reg("SAN-SHOWER-1000x1200", "Sanitary", "centre; tray with curtain on the +Y edge", 1000, 1200)
def _shower1000(b):
    b.R(-500, -600, 500, 600, r=14)
    b.R(-460, -560, 460, 560, r=10, fine=True)
    b.C(0, -80, 45)                                                                   # drain
    b.L((-45, -80), (45, -80), fine=True)
    b.L((0, -125), (0, -35), fine=True)
    b.C(-250, -480, 85)                                                               # shower rose
    b.C(-250, -480, 50, fine=True)
    pts = []
    for i in range(10):                                                               # curtain, soft folds
        pts.append((-460 + 92 * i, 585, 0.45 if i % 2 == 0 else -0.45))
    pts.append((460, 585, 0))
    b.PLB(pts, False, dash=False)


@reg("SAN-SHOWER-900", "Sanitary", "tray corner at the wall corner; door opens +Y", 900, 1600)
def _shower900(b):
    b.R(0, 0, 900, 900)
    b.R(40, 40, 860, 860, fine=True)
    b.C(450, 450, 45)
    b.L((410, 410), (490, 490), fine=True)
    b.L((410, 490), (490, 410), fine=True)
    b.C(160, 160, 100)
    b.C(160, 160, 60, fine=True)
    b.L((850, 900), (850, 1600), lw=25)                                               # door leaf
    b.A(850, 900, 700, 90, 180, fine=True, layer=SWING_LAYER)


@reg("SAN-TURN-1500", "Sanitary", "centre; 1.5 m wheelchair turning circle (clearance, flat)", 1500, 1500)
def _turn(b):
    b.C(0, 0, 750, dash=True)
    b.L((-70, 0), (70, 0), fine=True)
    b.L((0, -70), (0, 70), fine=True)


@reg("PLB-STACK-160", "Sanitary", "centre; plumbing stack dia 160", 160, 160)
def _stack(b):
    b.C(0, 0, 80)
    b.C(0, 0, 58, fine=True)
    b.L((-30, 0), (30, 0), fine=True)
    b.L((0, -30), (0, 30), fine=True)


@reg("SAN-MANHOLE-600", "Sanitary", "centre; manhole cover dia 600", 600, 600)
def _manhole(b):
    b.C(0, 0, 300)
    b.C(0, 0, 255, fine=True)
    b.L((-255, 0), (255, 0), fine=True)
    b.L((0, -255), (0, 255), fine=True)


@reg("SYM-WHEELCHAIR-PLACE-900x1400", "Symbol", "centre; 900 x 1400 wheelchair place (flat marking)", 900, 1400)
def _wch_place(b):
    b.R(-450, -700, 450, 700, dash=True)
    b.C(-30, 300, 48, fill=False)                                                     # head
    b.PL([(-30, 245), (-30, 40), (150, 40), (235, -150), (290, -150)])                # body + leg
    b.PL([(-30, 170), (110, 170), (140, 90)])                                         # arm
    b.A(-20, -60, 195, 55, 335)                                                       # wheel


# ================================================================== DOORS AND LIFT
def _door_sw(b, n):
    b.R(0, 0, 40, n, fill=False)                                                      # leaf, open 90 deg
    b.A(0, 0, n, 0, 90, fine=True, layer=SWING_LAYER)
    for x in (0, n):
        b.L((x, -115), (x, 115))                                                      # jamb ticks
    b.L((0, 0), (n, 0), fine=True)                                                    # closed position


for _n in (600, 700, 750, 800, 900, 1000, 1200):
    reg("DOR-SW-%04d" % _n, "Doors", "hinge jamb on the wall centre line; opening along +X, leaf opens +Y",
        _n, _n + 115)((lambda n: (lambda b: _door_sw(b, n)))(_n))


def _door_dw(b, n):
    h = n / 2.0
    b.R(-n / 2, 0, -n / 2 + 40, h, fill=False)
    b.R(n / 2 - 40, 0, n / 2, h, fill=False)
    b.A(-n / 2, 0, h, 0, 90, fine=True, layer=SWING_LAYER)
    b.A(n / 2, 0, h, 90, 180, fine=True, layer=SWING_LAYER)
    for x in (-n / 2, n / 2):
        b.L((x, -115), (x, 115))
    b.L((-n / 2, 0), (n / 2, 0), fine=True)


for _n in (1500, 1800, 2100):
    reg("DOR-DW-%d" % _n, "Doors", "centre of the opening on the wall centre line; leaves open +Y",
        _n, _n / 2 + 115)((lambda n: (lambda b: _door_dw(b, n)))(_n))


@reg("DOR-DA-1000", "Doors", "hinge jamb on the wall centre line; double-action leaf, arcs on both sides", 1000, 2000)
def _door_da(b):
    b.R(0, -20, 1000, 20, fill=False)                                                 # leaf, closed position
    b.A(0, 0, 1000, 0, 90, fine=True, layer=SWING_LAYER)
    b.A(0, 0, 1000, 270, 360, fine=True, layer=SWING_LAYER)
    b.L((0, 1000), (0, 0), fine=True)
    b.L((0, 0), (0, -1000), fine=True)
    for x in (0, 1000):
        b.L((x, -115), (x, 115))


def _door_sld(b, n):
    b.R(0, -45, n / 2 + 60, -5, fill=False)                                           # two panels on two tracks
    b.R(n / 2 - 60, 5, n, 45, fill=False)
    b.L((0, -25), (n / 2 + 60, -25), fine=True)
    b.L((n / 2 - 60, 25), (n, 25), fine=True)
    for x in (0, n):
        b.L((x, -45), (x, 45))


for _n in (900, 2400, 3000):
    reg("DOR-SLD-%d" % _n, "Doors", "start jamb on the wall centre line; opening along +X", _n, 90)(
        (lambda n: (lambda b: _door_sld(b, n)))(_n))


@reg("DOR-LIFT-0900", "Doors", "start jamb on the wall centre line; centre-opening 2 panels along +X", 900, 90)
def _door_lift(b):
    b.R(0, -22, 448, 22, fill=False)
    b.R(452, -22, 900, 22, fill=False)
    b.L((20, 0), (428, 0), fine=True)
    b.L((472, 0), (880, 0), fine=True)
    for x in (0, 900):
        b.L((x, -45), (x, 45))


@reg("LIFT-CAR-1500x2000", "Lift", "centre of the car; door on the +Y side", 1600, 2120)
def _lift_car(b):
    b.R(-800, -1050, 800, 1050)                                                       # car wall
    b.R(-750, -1000, 750, 1000, fine=True)                                            # clear cabin 1500 x 2000
    b.L((-750, -1000), (750, 1000), fine=True)
    b.L((-750, 1000), (750, -1000), fine=True)
    b.PL([(-550, 1050), (-550, 1070), (550, 1070), (550, 1050)], fine=True)           # 1100 door opening
    b.L((0, 1050), (0, 1070), fine=True)
    for x in (-550, 550):
        b.L((x, 1050), (x, 1070))
    for x in (-715, 715):
        b.L((x, -940), (x, 940), fine=True)                                           # hand rails
    b.L((-715, -965), (715, -965), fine=True)


# ================================================================== LANDSCAPE, PEOPLE, VEHICLES
_LOBES = {3000: 8, 4000: 8, 5000: 12, 6000: 12, 7000: 16, 8000: 16, 9000: 20}


def _tree(b, dia):
    """P05 sketch tree: lobed canopy outline, branch strokes with twigs, trunk dot. No fill (renderer tints)."""
    R = dia / 2.0
    b.PLB(lobed_verts(R, _LOBES[dia], dia), True, False)
    rnd = random.Random(dia + 11)
    tr = max(90.0, dia * 0.026)
    nb = 5 if dia >= 5000 else 4
    for k in range(nb):
        a = math.radians(360.0 / nb * k + rnd.uniform(-16, 16) + 25)
        r1 = R * rnd.uniform(0.60, 0.78)
        p0 = (tr * 1.05 * math.cos(a), tr * 1.05 * math.sin(a))
        p1 = (r1 * math.cos(a + 0.10), r1 * math.sin(a + 0.10))
        b.PLB([(p0[0], p0[1], 0.10), (p1[0], p1[1], 0)], False, lw=13)                 # branch stroke
        side = 1 if k % 2 == 0 else -1
        for f, ln, ang in ((0.52, 0.26, 32), (0.80, 0.16, 38)):                       # twigs, alternate sides
            q0 = (f * p1[0], f * p1[1])
            a2 = a + 0.10 + side * math.radians(ang)
            b.L(q0, (q0[0] + ln * r1 * math.cos(a2), q0[1] + ln * r1 * math.sin(a2)), fine=True)
            side = -side
    b.C(0, 0, tr)
    if dia >= 5000:
        b.C(0, 0, tr * 2.4, fine=True)


for _d in (3000, 4000, 5000, 6000, 7000, 8000, 9000):
    reg("LND-TREE-%d" % _d, "Landscape", "trunk centre; canopy dia %d (scale to suit)" % _d, _d, _d)(
        (lambda d: (lambda b: _tree(b, d)))(_d))


@reg("LND-SHRUB-1500", "Landscape", "centre; shrub clump", 1500, 1500)
def _shrub(b):
    b.BLOB(0, 0, 750, 1500, n=8, lo=0.86)
    for k in range(4):
        a = math.radians(40 + 90 * k)
        b.PLB([(130 * math.cos(a), 130 * math.sin(a), 0.12), (470 * math.cos(a + 0.2), 470 * math.sin(a + 0.2), 0)],
              False, fine=True)
    b.C(0, 0, 45, fine=True)


@reg("LND-PLANTER-1200", "Landscape", "back-centre; planter box with shrubs", 1200, 600)
def _planter(b):
    b.R(-600, 0, 600, 600, r=25)
    b.R(-545, 55, 545, 545, r=12, fine=True)
    for x, r, sd in ((-330, 170, 11), (60, 200, 12), (400, 150, 13)):
        b.BLOB(x, 300, r, sd, fine=True)
        b.C(x, 300, 18, fine=True)


# ---- people (top view): arms, then a rounded shoulder bar and the head on top (white fills hide the overlaps)
def _person(b, left, right):
    for sx, hand in ((-1, left), (1, right)):
        b.HULL((sx * 195, -5), 46, (sx * hand[0], hand[1]), 28)                       # arm to the hand
    b.HULL((-150, 0), 92, (150, 0), 92)                                               # shoulders
    b.C(0, 14, 80)                                                                    # head


reg("ENT-PERSON-PLAN", "People", "centre; standing person facing +Y", 500, 330)(
    lambda b: _person(b, (205, 190), (205, 190)))
reg("ENT-PERSON-WALK", "People", "centre; walking person facing +Y", 500, 420)(
    lambda b: _person(b, (215, 215), (215, -190)))


# ---- vehicles (nose = +Y, origin = centre)
def _wheel(b, cx, cy, w=210, l=640):
    b.R(cx - w / 2, cy - l / 2, cx + w / 2, cy + l / 2, r=45)
    b.L((cx - w / 2 + 40, cy - l / 2 + 60), (cx - w / 2 + 40, cy + l / 2 - 60), fine=True)


def _car(b, W, L):
    k = L / 4500.0
    h, hw = L / 2, W / 2
    for sx in (-1, 1):
        for ay in (0.31 * L, -0.31 * L):
            _wheel(b, sx * (hw - 70), ay)
    b.R(-hw, -h, hw, h, r=340)                                                        # body
    wb, wt = 820 * k, 110 * k
    b.POLY([(-0.39 * W, wb), (0.39 * W, wb), (0.34 * W, wt), (-0.34 * W, wt)])        # windscreen
    rt, rb = -700 * k, -1300 * k
    b.POLY([(-0.34 * W, rt), (0.34 * W, rt), (0.37 * W, rb), (-0.37 * W, rb)])        # rear glass
    for s in (-1, 1):
        b.L((s * 0.34 * W, wt), (s * 0.34 * W, rt))                                   # side-glass edge
        b.L((s * 0.39 * W, wb), (s * 0.37 * W, rb), fine=True)                        # roof drip rail
        b.L((s * 0.455 * W, 150 * k), (s * 0.455 * W, 450 * k), fine=True)            # door shut line
        b.R(s * (hw + 25), 650 * k, s * (hw + 105), 830 * k, r=25)                    # mirror
        b.POLY([(s * 0.43 * W, h - 70), (s * 0.30 * W, h - 40), (s * 0.28 * W, h - 110), (s * 0.43 * W, h - 160)],
               fine=True)                                                             # headlamp
        b.R(s * 0.27 * W, -h + 50, s * 0.46 * W, -h + 105, r=20, fine=True)           # tail lamp
    b.R(-0.17 * W, wb + 380 * k, 0.17 * W, wb + 640 * k, r=40, fine=True)             # bonnet crease


reg("VEH-CAR-4500", "Vehicles", "centre; nose +Y", 1990, 4500)(lambda b: _car(b, 1800, 4500))
reg("VEH-SUV-4800", "Vehicles", "centre; nose +Y", 2090, 4800)(lambda b: _car(b, 1900, 4800))


@reg("VEH-2W-1900", "Vehicles", "centre; nose +Y", 740, 1900)
def _two(b):
    for y in (700, -700):
        b.R(-45, y - 330, 45, y + 330, r=30)                                          # tyres
    b.L((-60, 560), (60, 560))                                                        # fork crown
    b.L((0, 560), (0, 380), lw=35)
    b.R(-190, -760, 190, -430, r=60)                                                  # rear mudguard / carrier
    b.R(-155, -350, 155, 130, r=70)                                                   # seat
    b.R(-120, -310, 120, 90, r=50, fine=True)
    b.E(0, 330, 150, 250)                                                             # tank
    b.E(0, 330, 120, 215, fine=True)
    b.L((-370, 640), (370, 640), lw=35)                                               # handlebar
    for s in (-1, 1):
        b.R(s * 370 - 20, 570, s * 370 + 20, 700, r=15)                               # grips
        b.C(s * 240, 770, 38)                                                         # mirrors
        b.L((s * 240, 732), (s * 175, 650), fine=True)
    b.R(-110, 700, 110, 830, r=40)                                                    # headlamp cowl


def _truck(b, L, artic):
    W = 2500
    top = L / 2
    cab_b = top - 2100
    if not artic:
        box_top = cab_b - 150
        axes = [top - 1250, -top + 1900, -top + 3200]
    else:
        box_top = top - 3700
        axes = [top - 1250, top - 3500, top - 4800, -top + 1400, -top + 2700, -top + 4000]
    for ay in axes:
        for sx in (-1, 1):
            b.R(sx * 1170 - 130, ay - 500, sx * 1170 + 130, ay + 500, r=50)           # dual tyres as one stroke
            b.L((sx * 1170, ay - 440), (sx * 1170, ay + 440), fine=True)
    b.R(-1250, -top, 1250, box_top, r=40)                                             # cargo box / trailer
    b.R(-1200, -top + 40, 1200, box_top - 40, fine=True)
    for y in range(int(-top + 1600), int(box_top - 600), 1600):
        b.L((-1200, y), (1200, y), fine=True)                                         # rib lines
    if artic:
        b.R(-450, top - 5300, 450, cab_b, dash=True)                                  # chassis rails under trailer
        b.C(0, top - 4200, 400, dash=True)                                            # fifth wheel
    b.R(-1200, cab_b, 1200, top, r=210)                                               # cab
    b.POLY([(-1000, top - 300), (-900, top - 750), (900, top - 750), (1000, top - 300)])   # windscreen
    b.R(-1000, cab_b + 120, 1000, top - 1000, r=80, fine=True)                        # roof panel
    for s in (-1, 1):
        b.R(s * 1230 - 55, top - 750, s * 1230 + 55, top - 450, r=20)                 # mirror


reg("VEH-TRUCK-12000", "Vehicles", "centre; cab +Y", 2500, 12000)(lambda b: _truck(b, 12000, False))
reg("VEH-TRUCK-16500", "Vehicles", "centre; cab +Y", 2500, 16500)(lambda b: _truck(b, 16500, True))


@reg("VEH-BUS-12000", "Vehicles", "centre; front +Y", 2600, 12000)
def _bus(b):
    W, L = 2600, 12000
    h = L / 2
    for ay in (h - 2500, -h + 2600):
        for sx in (-1, 1):
            b.R(sx * 1230 - 140, ay - 500, sx * 1230 + 140, ay + 500, r=50)
    b.R(-1300, -h, 1300, h, r=420)
    b.POLY([(-1050, h - 250), (-1150, h - 1050), (1150, h - 1050), (1050, h - 250)])              # windscreen
    b.POLY([(-1000, -h + 250), (-1100, -h + 900), (1100, -h + 900), (1000, -h + 250)])            # rear glass
    b.R(-1180, -h + 1000, 1180, h - 1150, r=60, fine=True)                            # roof outline
    for y in (h - 3700, -h + 3200):
        b.R(-450, y - 700, 450, y + 700, r=40)                                        # roof hatch / AC pod
        b.L((-450, y), (450, y), fine=True)
    for y in range(int(-h + 1300), int(h - 1300), 600):
        for s in (-1, 1):
            b.L((s * 500, y), (s * 1180, y), fine=True)                               # roof ribs
    b.L((0, -h + 1000), (0, h - 1150), fine=True)
    b.R(-1300, h - 3300, -1230, h - 2200)                                             # passenger door
    for s in (-1, 1):
        b.R(s * 1300 + s * 30, h - 800, s * 1300 + s * 180, h - 480, r=20)            # mirror arms


# ================================================================== ENTRY POINT
def add_blocks(doc, names=None):
    """Create every block definition in `doc` (skips ones that already exist). Returns the list of names added."""
    _ensure(doc)
    done = []
    for name, cat, ins, w, d, fn in REG:
        if names is not None and name not in names:
            continue
        if name in doc.blocks:
            continue
        fn(B(doc, name))
        done.append(name)
    return done


def measure(doc, name):
    """(xmin, ymin, xmax, ymax) of a block definition in mm."""
    from ezdxf import bbox
    bb = bbox.extents(doc.blocks[name], fast=False)
    return bb.extmin.x, bb.extmin.y, bb.extmax.x, bb.extmax.y



# ---- measured extents (w, d in mm) of every block geometry; BLOCK_INFO[name] = (w, d, insert_note)
_MEASURED = {
    "FUR-CHAIR-450": (450, 450),
    "FUR-CHAIR-TUCK-450": (450, 450),
    "FUR-CHAIR-KID-300": (300, 300),
    "FUR-CHAIR-OFFICE-550": (550, 500),
    "FUR-LOUNGE-CHAIR-800": (800, 800),
    "FUR-TBL2-700": (700, 1400),
    "FUR-TBL4-900": (1600, 1600),
    "FUR-TBL4R-1200": (1200, 1450),
    "FUR-TBL6-1800": (1800, 1500),
    "FUR-TBLR2-700": (700, 1400),
    "FUR-TBLR4-1000": (1700, 1700),
    "FUR-TBLR6-1500": (2018, 2200),
    "FUR-TBLR4-KIDS-600": (999, 999),
    "FUR-DHABA-TABLE-4": (1550, 1200),
    "FUR-BOOTH4-1500": (1500, 1850),
    "FUR-BENCH-COMM-3000": (3000, 1700),
    "FUR-BENCH-3000": (3000, 450),
    "FUR-BENCH-2800": (2800, 450),
    "FUR-BENCH-1800": (1800, 450),
    "FUR-BENCH-1500x400": (1500, 400),
    "FUR-BENCH-1200x350": (1200, 350),
    "FUR-CHARPOY-1900": (1900, 1000),
    "FUR-SOFA3-2000": (2000, 900),
    "FUR-SOFA2-1500": (1500, 900),
    "FUR-KIDSPLAY-3000": (3000, 2400),
    "FUR-KIDSPLAY-3000-GATE-E": (3000, 2400),
    "FUR-BARTOP-5400x450": (5400, 450),
    "FUR-BARTOP-5600x450": (5600, 450),
    "FUR-BARTOP-5900x450": (5900, 450),
    "FUR-CTR-PLAIN-2700": (2700, 700),
    "FUR-CTR-ROUNDED-5000x3500": (5000, 3500),
    "FUR-CTR-2000": (2000, 700),
    "FUR-CTR-3000": (3000, 700),
    "FUR-CTR-4000": (4000, 700),
    "FUR-CTR-ACC-1500": (1500, 600),
    "FUR-CTR-L-3000": (3000, 2000),
    "FUR-DISPLAY-1200": (1200, 600),
    "FUR-LEDGE-4500x350": (4500, 350),
    "FUR-WASHCTR-4000x600": (4000, 600),
    "FUR-PLANTER-BENCH-2500x600": (2500, 600),
    "FUR-TREESEAT-R1400": (2800, 2800),
    "FUR-MAT-RUBBER-1000x2400": (1000, 2400),
    "FUR-DESK-1500x750": (1500, 750),
    "FUR-DESK-1200x600": (1200, 600),
    "FUR-DESK-1200": (1200, 1205),
    "FUR-CABINET-450x600": (450, 600),
    "FUR-LOCKER-450": (450, 500),
    "FUR-RACK-1200x600": (1200, 600),
    "FUR-RACK-1200x500": (1200, 500),
    "FUR-SAFE-500": (500, 500),
    "FUR-SHELF-700x300": (700, 300),
    "FUR-SHELF-LOW-1200": (1200, 300),
    "FUR-HOOKRAIL-600x50": (600, 50),
    "FUR-SIGN-WALL-600": (600, 100),
    "FUR-CHARGE-POST-300": (300, 300),
    "FUR-VEND-PAD-400x200": (400, 200),
    "FUR-STOOL-350": (350, 350),
    "FUR-STOOL-340": (340, 340),
    "FUR-BIN-400": (400, 400),
    "FUR-BIN-DUAL-800x400": (780, 380),
    "EQP-RANGE6-1800": (1800, 900),
    "EQP-RANGE6-1500": (1500, 800),
    "EQP-RANGE4-1200": (1200, 800),
    "EQP-TAWA-1200": (1200, 900),
    "EQP-TANDOOR-900": (900, 900),
    "EQP-DOSA-TAWA-1000": (1100, 1100),
    "EQP-DOSA-HEARTH-1800": (1800, 900),
    "EQP-HOOD-1200": (1200, 1100),
    "EQP-HOOD-1500": (1500, 1100),
    "EQP-HOOD-1800": (1800, 1100),
    "EQP-HOOD-2400": (2400, 1100),
    "EQP-HOOD-5338": (5338, 1100),
    "EQP-SINK1-900": (900, 700),
    "EQP-SINK2-1300": (1300, 700),
    "EQP-SINK2-1800": (1800, 700),
    "EQP-PREP-700": (700, 700),
    "EQP-PREP-1200": (1200, 700),
    "EQP-PREP-1500": (1500, 700),
    "EQP-PREP-1800": (1800, 700),
    "EQP-PREP-2400": (2400, 700),
    "EQP-PREP-3200": (3200, 700),
    "EQP-ISLAND-2400x900": (2400, 900),
    "EQP-PASS-1300x300": (1300, 300),
    "EQP-FRIDGE-1000x700": (1000, 700),
    "EQP-FREEZER-700x800": (700, 800),
    "EQP-FRIDGE-700": (700, 1500),
    "EQP-FRYER-600": (600, 900),
    "EQP-FRYER-450": (450, 750),
    "EQP-DISHWASHER-700": (700, 700),
    "EQP-CHAI-BOILER-600": (600, 600),
    "EQP-RO-UNIT-500": (500, 500),
    "EQP-SCALE-600": (600, 600),
    "EQP-POS-400": (400, 400),
    "EQP-FOODLIFT-800": (800, 800),
    "EQP-FOODLIFT-980": (980, 980),
    "EQP-HOTCASE-1200": (1200, 600),
    "EQP-PLATERACK-900": (900, 450),
    "EQP-PANEL-LT-2400x600": (2400, 600),
    "EQP-UPS-800x600": (800, 600),
    "EQP-BATTERY-RACK-1200x500": (1200, 500),
    "EQP-CABLETRAY-2000x300": (2000, 300),
    "EQP-LPG-CYL-320": (320, 320),
    "EQP-GENSET-2500x1000": (2500, 1000),
    "EQP-COMPOST-DRUM-1000": (1000, 1000),
    "SAN-WC-WEST": (400, 685),
    "SAN-WC-INDIAN": (450, 590),
    "SAN-WC-WALLHUNG-400x550": (400, 550),
    "SAN-URINAL-400": (400, 350),
    "SAN-URINAL-DIV": (40, 450),
    "SAN-BASIN-550": (550, 450),
    "SAN-BASIN-500x400": (500, 400),
    "SAN-BASIN-HAND-450": (450, 350),
    "SAN-BASIN-HAND-400x280": (400, 280),
    "SAN-BASIN-TROUGH-1500": (1500, 450),
    "SAN-MOPSINK-600x500": (600, 500),
    "SAN-BABYCHANGE-700": (700, 500),
    "SAN-WASH-COUNTER-2300": (2300, 600),
    "SAN-MIRROR-600": (600, 20),
    "SAN-GRAB-800x40": (800, 40),
    "SAN-GRABBAR-600": (600, 40),
    "SAN-GRABBAR-750": (750, 40),
    "SAN-GRAB-DROP-40x700": (40, 700),
    "SAN-TAP-100": (100, 100),
    "SAN-TAP-DRINK-200x150": (200, 150),
    "SAN-TROUGH-800x6000": (800, 6000),
    "SAN-SHOWER-1000x1200": (1000, 1206),
    "SAN-SHOWER-900": (900, 1600),
    "SAN-TURN-1500": (1500, 1500),
    "PLB-STACK-160": (160, 160),
    "SAN-MANHOLE-600": (600, 600),
    "SYM-WHEELCHAIR-PLACE-900x1400": (900, 1400),
    "DOR-SW-0600": (600, 715),
    "DOR-SW-0700": (700, 815),
    "DOR-SW-0750": (750, 865),
    "DOR-SW-0800": (800, 915),
    "DOR-SW-0900": (900, 1015),
    "DOR-SW-1000": (1000, 1115),
    "DOR-SW-1200": (1200, 1315),
    "DOR-DW-1500": (1500, 865),
    "DOR-DW-1800": (1800, 1015),
    "DOR-DW-2100": (2100, 1165),
    "DOR-DA-1000": (1000, 2000),
    "DOR-SLD-900": (900, 90),
    "DOR-SLD-2400": (2400, 90),
    "DOR-SLD-3000": (3000, 90),
    "DOR-LIFT-0900": (900, 90),
    "LIFT-CAR-1500x2000": (1600, 2120),
    "LND-TREE-3000": (3003, 2999),
    "LND-TREE-4000": (3987, 4019),
    "LND-TREE-5000": (5029, 4974),
    "LND-TREE-6000": (5983, 6022),
    "LND-TREE-7000": (6994, 7009),
    "LND-TREE-8000": (7974, 8029),
    "LND-TREE-9000": (8992, 9014),
    "LND-SHRUB-1500": (1505, 1496),
    "LND-PLANTER-1200": (1200, 600),
    "ENT-PERSON-PLAN": (484, 310),
    "ENT-PERSON-WALK": (486, 461),
    "VEH-CAR-4500": (2010, 4500),
    "VEH-SUV-4800": (2110, 4800),
    "VEH-2W-1900": (780, 2060),
    "VEH-TRUCK-12000": (2600, 12000),
    "VEH-TRUCK-16500": (2600, 16500),
    "VEH-BUS-12000": (2960, 12000),
}
for _n, (_w, _d) in _MEASURED.items():
    if _n in BLOCK_INFO:
        BLOCK_INFO[_n] = (_w, _d, BLOCK_INFO[_n][2])


def verify(tol=3):
    """rebuild every block in a scratch DXF, audit it, and report blocks whose measured size differs from BLOCK_INFO."""
    doc = ezdxf.new("R2018", setup=True)
    add_blocks(doc)
    bad = []
    for n, (w, dd, _) in BLOCK_INFO.items():
        x0, y0, x1, y1 = measure(doc, n)
        if abs((x1 - x0) - w) > tol or abs((y1 - y0) - dd) > tol:
            bad.append((n, round(x1 - x0), round(y1 - y0), w, dd))
    errs = doc.audit().errors
    return bad, len(errs)


if __name__ == "__main__":
    d = ezdxf.new("R2018", setup=True)
    n = add_blocks(d)
    print(len(n), "blocks defined;", "size mismatches / audit errors:", verify())
