# Presentation rules (all PDFs, diagrams and sheets)

## Quality bar
- The benchmark is professional competition-sheet quality: dense but ordered, fine lines, lots of white space, one accent colour.
- "Simple" means minimal and self-explanatory. It never means cartoonish, hand-drawn, icon-heavy or "first-year". The source user rejected that output as "AI slop".
- A viewer must understand every drawing at a glance, on the spot, without reading a long text.

## Markings (the most common failure)
- **Every arrow, line type, hatch, colour and symbol has a legend entry.** If it isn't in the legend, it isn't on the drawing.
- Lines and arrows are **thin**: 0.8–1.2 pt for routes, with small arrowheads or chevrons. No thick block arrows.
- Use **one colour per user group or flow**. Where flows share a lane, offset them in parallel (about 1 m at plan scale). If more than 3 flows crowd one plan, split it into small multiples (one panel per user group).
- Entries are small line-drawn chevrons: › for main, » for secondary, outward for exit. Don't use text glyphs.
- Use plain space names written inside zones. Never use internal codes (no "NE-1", "C-02", "SN-03").
- Every plan-like diagram has a north arrow, a scale bar in metres and a one-line caption.

## Typography
- Arial (or Calibri). Bold for headings; regular otherwise.
- No monospace (Consolas etc.), no Arial Black, no decorative fonts.
- Sizes on A3: body 8.5–9.5 pt, labels and captions 7–8 pt, sheet titles 14–18 pt.
- Never use odd markers such as †, ‡, §, ◐, [K], [V] or [A], or emoji.

## Colour
- Drawings are monochrome (white, greys, fine black) plus **one accent colour**, chosen at the style lock from the seed's suggestion or the user's references. Burnt orange was only the source project's pick. Never default to it.
- Diagram semantics stay the same everywhere:
  - sun = warm yellow-orange;
  - wind = blue, dashed;
  - water = light blue;
  - planting = sage/green;
  - noise = violet, wavy.
- Zone colours are pastel fills, defined once in `LOCKED_STYLE.md` and reused in the programme table, bubbles and zoning.

## Content kept OFF presentation pages
Rule lists, long code clauses, assumptions, open questions, audit or revision notes, internal checks, and "questions for the student". These live in internal notes or the guides.

**Exception: the area programme table.** It carries a short justification and a short source for each space, e.g. "NBC 2016", "Neufert", "Brief". The user can then present it as is, without copying from the Sources PDF. Only **verified** sources appear there. Clause-level detail and "to verify" items stay in the Sources PDF.

## Vector pipeline (mandatory)
- Diagrams: matplotlib → **SVG** with `svg.fonttype = 'none'` and `font.family = 'Arial'` (text stays as text). Alternatively, hand-written SVG.
- CAD drawings: from the model, draw the PDF directly (matplotlib with vector output, or ezdxf's drawing add-on to SVG/PDF).
- Sheets: HTML + CSS with SVGs embedded via `<img src="x.svg">` or inline, printed with headless Chrome:
  ```
  chrome --headless=new --disable-gpu --no-pdf-header-footer --print-to-pdf="OUT.pdf" "file:///.../index.html"
  ```
  Edge works the same if Chrome is missing.
- **Never embed PNG screenshots of drawings.** The source project's first presentation went blurry on zoom for exactly this reason. Raster is allowed only for photos and for reference crops on choice boards.
- Verify after every build:
  - pymupdf `page.get_images()` count per page (drawings = 0);
  - render at about 50 dpi to look for layout faults;
  - zoom-test one crop at 400%.

## Page setup
- Use the brief's sheet size. Default to A3 landscape for working PDFs, which scales cleanly to A1 (same √2 ratio). Margins 12–15 mm.
- Every sheet has the same title band (number + title + one-line subtitle) and footer (project tag, page x/y, "GROUP NO." if anonymous).
- Save the machine-readable twin (the data file it was built from) next to the PDF's build folder.
