# Technical drawing accuracy: get it right the first time

The source project's "finished" set passed its own checks. Then an outside AI that was given only the PDF found:
- stair sections with missing flights and wrong risers;
- columns not meeting beams in sections;
- footings off their columns;
- a lift shaft vanishing;
- roof levels that disagreed.

This file lists how each element must be **constructed**, so those errors cannot happen. The geometry rules are also asserted by `scripts/check_model.py`. A drawing that fails an assertion is not shown.

## 1. Universal rules
- **One model, one geometry module.** Every drawing computes from `06_model/*.json` + `geometry.py`. No hand-typed coordinate or level in any drawing script.
- **Draw at true size in mm, 1:1.** Scale only at output.
- **Line hierarchy** (at 1:100):
  - cut 0.50–0.70 mm (or solid poché);
  - elements beyond 0.25–0.35 mm;
  - furniture and fixtures 0.13–0.18 mm;
  - hidden/overhead dashed 0.13 mm;
  - grid dash-dot 0.13 mm.
- **Closed, joined geometry.** Wall polygons join at corners and T-junctions with no gaps or overlaps. Columns merge into walls. Hatches are bounded by closed polylines.
- **Same element, same geometry, everywhere.** Each element has one source record. Plans, sections, elevations, axos and details all read it.

## 2. Stairs (the most common failure)
**Maths first, in `check_model.py`:**
- `n_risers = floor_to_floor / riser` must be a whole number. Riser ≤ code max (non-residential typically 150, residential 190). Tread ≥ code min (300 / 250).
- 2R + T between 550 and 700.
- Flights ≤ code max risers (typically 12–15). Landings ≥ stair width (≥ 1500 public).
- Headroom ≥ 2100 measured vertically from the pitch line to anything above, including beams and the upper landing.
- Every flight's top tread meets the next level exactly. The last riser lands at the floor level, not a step short.

**In plan:**
- Draw all treads.
- On the lower floor, the flight is solid up to a diagonal cut line at about 1.2 m above the floor; beyond the cut it is dashed. The upper floor shows the full stair from above.
- Arrows run from the foot, with "UP" / "DN" from the floor you stand on.
- Handrails at both sides; well opening trimmed and guarded at ≥ 1100 on the upper floor.
- The same stair at the same coordinates on every floor.

**In section:**
- Draw EVERY flight and landing.
  - Flights that are cut are poché with stepped profile.
  - Flights beyond are lines.
- Waist slab (RCC, typically 150) or steel stringer drawn with real depth.
- Each flight is supported at both ends by a beam, landing or wall that is itself drawn.
- Nosings line up on the pitch line. Risers are counted and must equal the plan count.
- Place the section cut so that it shows the stair fully. Move the cut if it misses a flight.

## 3. Columns, beams, slabs (frame continuity)
- **Columns run continuously** from the base plate or pedestal to the underside of the topmost beam they carry. In section, the column line meets the beam with no gap and no overshoot through the slab.
- **Beams frame into columns.** Beam ends stop at the column face (or run through for continuous frames). Beam depth is drawn below the slab, using the real member (I-section for steel: flanges and web; rectangle for RCC).
- **Slabs sit on beams.** Slab thickness is drawn (RCC 125–150; composite deck 120–150 over the deck profile). Floor levels (FFL) = top of finish; the structural level is FFL minus the finish.
- **Steel columns in plan** are drawn at true section size and orientation (I-section web along the major-axis frame), not as dots, when the scale allows.
- **Upper columns stack** on lower ones (same x, y). A column that doesn't stack (a floating column) needs a transfer beam drawn and justified.
- **Bracing and moment frames:** braced bays drawn as X or K in sections and elevations where they are cut or seen. Same bays in every view.

## 4. Foundations and the load path
- The load path in every section reads: roof → beam → column → base plate → pedestal → footing → soil.
- **Every footing is centred under its column** (the model asserts footing.x,y = column.x,y unless combined). Combined or raft footings are labelled.
- Footing depth below ground (typically −1.2 to −2.0 m, by soil assumption) is the same value on all sheets. Draw the PCC bed (75–100) under the footing.
- Walls stand on plinth beams or wall footings that are drawn. Plinth beams connect the column pedestals.
- Plinth level, ground level, FFL, the ramp and steps at the entrance are all drawn and levelled.
- Adjacent footings at different levels respect the 45° spread rule. Otherwise step them or combine them.

## 5. Walls, openings, levels
- Exact wall thicknesses by type, e.g. 230 external brick, 115 partition, 150 block; constant in all drawings.
- Doors in plan: the leaf at 90° plus the swing arc; the door width matches the schedule. In section and elevation: head height (typically 2100) and frame.
- Windows: sill and head heights from the model, the same in sections and elevations. Lintels are drawn in section.
- **Level chain in every section:** ground ±0.00, plinth, each FFL, beam soffits, eave, ridge/top, footing bottom. One value per element across the whole set. Fix the datum once, e.g. "roof level = top of roofing".
- Parapets ≥ 1000 (guards ≥ 1100 where people stand at a drop).

## 6. Roofs
- The roof profile comes from one function. Sections and elevations both call it, so ridge, eave and steps agree.
- The built-up is drawn: deck/sheet, purlins at the stated spacing, rafters or trusses with real depth, insulation if any.
- Every roof surface has a drawn drainage end: gutter → downpipe → ground or channel. No unexplained gaps exposed to rain.
- Details use the same geometry as the section they come from; never redraw them from memory.

## 7. Elevations
- Only what is visible from that side, projected from the model, with hidden parts removed. The heights, column rhythm and openings must match the plans and sections.
- If a large part is set back and looks "missing", add depth shading and a small key plan arrow, or pair it with a vector aerial.

## 8. Self-test before any reviewer sees it
1. Run `py -I scripts/check_model.py 06_model` → must report 0 FAIL.
2. Render previews. Zoom into crops of each stair (plan + section), one column-beam junction, one footing, the roof eave and the entrance steps/ramp, and compare them with this file.
3. Run the blind review (`stages/S10_blind_review.md`).
