# DXF output (AutoCAD-ready, never DWG)

There is no AutoCAD access. Write **DXF R2018** with Python `ezdxf` (`pip install ezdxf`). AutoCAD opens it directly; the user can Save As DWG.

## Always
- Units mm, 1:1 model space, origin at a fixed site corner, the same for every drawing (so files overlay as xrefs).
- **Furniture, fixtures, kitchen equipment, trees, cars, trucks, people, doors, north arrow and grid bubbles are BLOCK inserts.** Nothing is exploded into lines, so the user can move and swap blocks. The user's original complaint was that PDF import into AutoCAD gives exploded lines.
- Every entity sits on a named layer with a colour, linetype and lineweight set on the layer (ByLayer).
- Hatches are real HATCH entities (solid for poché, patterns for finishes) on their own layers.
- Text uses an Arial text style; no SHX-only fonts.
- One DXF per drawing: `A101_GF_Plan.dxf`, `A201_Section_AA.dxf` …
- Build the block library once (`07_drawings/src/blocks.py`) and reuse it. Render a block catalogue PDF so the user can see the blocks.
- Never read a generated DXF into the chat context. Check it by script (count entities per layer, list blocks) and by rendering a preview PNG with ezdxf's drawing add-on.

## Layer naming by level (chosen at intake)
### Simple (W1, and W2 if the user picked Simple)
The names a student would type:
```
Walls        Walls-Hatch    Columns       Doors        Windows
Stairs       Furniture      Toilets       Kitchen      Landscape
Parking      Site           Text          Dimensions   Grid
Section-Marks  Hidden-Above
```

### Standard (W2, W3)
Short AIA-style names (as used in the source project):
```
A-WALL  A-WALL-LOW  A-GLAZ  A-DOOR  A-DOOR-SWING  A-WIND  A-STAIR  A-LIFT
A-FURN  A-FIXT  A-EQPT  A-FLOR-PATT  A-AREA-TINT  A-ROOF-ABOVE  A-VOID
A-ANNO-NUMB  A-ANNO-TEXT  A-ANNO-LEGEND  A-ANNO-TITLE  A-GRID  A-DIMS  A-AREA
A-SECT-MARK  S-COLS  S-BEAM  S-FNDN  S-BRAC  L-PLNT  L-HARD  L-SOFT
C-ROAD  C-PARK  C-PROP  C-SETB  A-PEOP
A-ELEV  A-ELEV-FILL  A-SECT-CUT  A-SECT-BEYOND  A-SECT-GRND
```

### Professional (W4)
Full US NCS / AIA layer format, `Discipline-Major-Minor-Status`:
- A-WALL-EXTR, A-WALL-INTR, A-WALL-FIRE, A-WALL-PATT;
- A-DOOR, A-DOOR-IDEN;
- A-GLAZ-CURT, A-FLOR-EVTR (lift), A-FLOR-STRS;
- A-FURN-FIXD, A-FURN-FREE, P-FIXT;
- A-ANNO-DIMS, A-ANNO-NOTE, A-ANNO-SYMB, A-ANNO-TTLB;
- S-GRID, S-GRID-IDEN, S-COLS, S-BEAM, S-FNDN;
- E-POWR (if shown);
- C-PROP, C-TOPO;
- L-PLNT-TREE.

Add a title-block block with attributes (sheet no., title, scale, revision, date) and a layer list sheet.

## Block naming
Use readable names, e.g. `TABLE-4SEAT-1200x750`, `CHAIR-DINING`, `WC-INDIAN`, `WC-WESTERN`, `URINAL`, `BASIN`, `ACCESSIBLE-WC-SET`, `KITCHEN-RANGE-2400`, `TREE-SAGE-6M`, `CAR-SEDAN`, `TRUCK-12M`, `BUS-12M`, `PERSON-WALK`, `DOOR-SINGLE-900` (dynamic swing via insert scale/rotation).

Simple mode may shorten these (`Table 4`, `Chair`, `WC`). Professional mode adds a prefix (`F-`, `P-`, `L-`).

## Minimal ezdxf pattern
```python
import ezdxf
doc = ezdxf.new("R2018", setup=True); doc.units = ezdxf.units.MM
doc.layers.add("A-WALL", color=250); doc.layers.add("A-FURN", color=7)
blk = doc.blocks.new("CHAIR-DINING"); blk.add_lwpolyline([(0,0),(450,0),(450,450),(0,450)], close=True)
msp = doc.modelspace()
h = msp.add_hatch(color=250, dxfattribs={"layer": "A-WALL"}); h.paths.add_polyline_path(wall_poly_mm, is_closed=True)
msp.add_blockref("CHAIR-DINING", (x_mm, y_mm), dxfattribs={"layer": "A-FURN", "rotation": rot})
doc.saveas("A101_GF_Plan.dxf")
# preview: ezdxf.addons.drawing → matplotlib backend → PNG (check only) / SVG (vector)
```
Run `ezdxf`'s audit (`doc.audit()`) before saving. Any errors must be zero.
