# Planning checklist (run before ANY plan is shown; every answer must be YES)

Automate whatever can be computed from the model (overlaps, clearances, counts, areas). Log the results in `07_drawings/CHECKS.md` as PASS/FAIL per item, then fix every FAIL.

Values below are typical defaults (Indian NBC 2016, Harmonised Accessibility Guidelines 2021, common practice). Replace them with the project's code from `02_research/space_standards_internal.md`.

## A. Every room
1. It has a door, or a stated open connection. No room is sealed on all sides.
2. Habitable rooms, toilets and kitchens have a window or louvre on an outside wall. Lift, duct, riser and cold room are exempt.
3. It has a reason to exist AND a reason to be in this spot, written in `programme.json` → `why`.
4. Its area is within ±5% of `programme.json`, computed from the polygon, never typed.

## B. Structure
5. Columns sit on grid intersections at true size; upper-floor columns stack on lower ones.
6. No column in a door opening or swing, aisle, exit route, kitchen equipment line, toilet cubicle, turning circle or a table's seated zone.
7. Braced bays are solid (no doors or windows) and continuous between floors.
8. Floor openings (stair, lift, ducts) sit in one bay and are trimmed. Cantilevers are within about 0.4 × backspan.
9. Every footing sits centred under its column.

## C. Furniture
10. Every table has its chairs; every counter has stools or a queue strip; every bed has a locker.
11. No furniture inside a door swing or within 1.2 m of an exit door. Never a table or basin in a doorway.
12. Aisles are measured from the 0.6 m seated zone: main 1.2–1.5 m, secondary 0.9 m, 0.6 m between chair backs.
13. Furniture faces sensibly: diners toward views or the room, not toward toilets; beds' heads on solid walls, not under windows.
14. Accessible seats exist (900 × 1400 + 1500 turning) and are not at the back of the room.

## D. Toilets and kitchen
15. Fixture counts from the code AND the peak scenario.
16. WC cubicle ≥ 0.9 × 1.2 m (aim 1.0 × 1.4 m); urinal pitch ≥ 0.6 m; 1.0 m clear in front of each WC.
17. Accessible WC ≥ 2.2 × 2.3 m; 1.5 m turning circle clear of the door leaf; door opens out; grab rails drawn.
18. No fixture visible from dining, the entrance or the queue (baffled entry). No toilet door opens onto the dining hall or the kitchen.
19. Toilets are reachable from dining without going outside and around. Wash basins sit on the way to eating.
20. Kitchen flow runs one way: receive → store → prep → cook → pass. Dish return does not cross the pass. Receiving and waste use separate doors.
21. Kitchen has hoods over all flames, 1.0–1.2 m cook aisles, a hand-wash at the entry, and air/light on an outside wall.
22. The gas cylinder store is outside, ventilated and away from openings. The electrical room is accessible.

## E. Doors, stairs, ramps, lift, exits
23. Door widths suit the room (public ≥ 1.0 m, accessible ≥ 0.9 m clear). Swing arcs don't clash with each other, fixtures or furniture. Exit doors swing outward.
24. Stair: floor-to-floor ÷ riser = a whole number. Riser and tread meet the code (non-residential typically ≤ 150 / ≥ 300). Flights ≤ 12–15 risers, landings ≥ the stair width, headroom ≥ 2.1 m, handrails drawn.
25. Every flight is drawn on every floor in the right direction (UP/DN), with the plan cut line.
26. Ramps ≤ 1:12, 1.5 m landings, ≥ 1.2 m wide, rails both sides. There is a step-free route from parking to every public space.
27. Lift car and door sized for a wheelchair or stretcher as required; a 1.5 × 1.5 m lobby on every floor; the same position on all floors.
28. Travel distance and number of exits per floor meet the code (assembly typically ≤ 30 m). A second way down is drawn if needed.

## F. Site
29. Vehicle loop and turning radii checked for the largest vehicle; parked vehicles never block the loop or fire-tender path.
30. Pedestrian routes don't cross truck paths without a marked crossing. Stair and exit feet land in safe zones, not in traffic lanes.
31. Coverage, height, setbacks and FAR are within limits, computed from the model.

## G. Drawing
32. Wall thicknesses are exact and consistent by type.
33. Every line type, hatch and symbol is in the legend; names are plain; nothing jury-sensitive is on the sheet.
34. The DXF follows `cad_dxf.md`: proper layers, furniture as blocks.
