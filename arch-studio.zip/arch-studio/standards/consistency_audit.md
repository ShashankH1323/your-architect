# Cross-drawing consistency audit (run before any drawing set is shown)

Every item below actually went wrong in the source project's first full set. The fix in every case: correct the **model** or the shared geometry function, then rebuild all drawings. Never patch one drawing.

Write the results to `07_drawings/AUDIT.md`. Write every decision you take to `07_drawings/DECISIONS.md`, so later agents read it first.

## Vertical elements
- [ ] **Stairs.** The same position, width, flight count and direction on every plan, section and 3D view. The section shows ALL flights and the landing at the right level. Risers × riser height = floor-to-floor exactly.
- [ ] **Lift.** The shaft is continuous through every floor in sections. No furniture inside the shaft on upper plans. The pit and overrun are drawn.
- [ ] **Secondary or escape stairs.** ONE geometry used in plans, sections, elevations and axos. The foot lands in a safe place, not in a vehicle lane.
- [ ] **Shafts and food lifts** stack vertically. Check the coordinates match between floors.

## Levels and heights
- [ ] Each level has **one value** on every sheet (floor, eave, crest or highest point, footing bottom). Decide the datum once (e.g. "top of roofing") and write it in DECISIONS.md.
- [ ] Section rooflines match elevation rooflines (same profile, same steps).
- [ ] Details match the section geometry they come from (no symmetrical gable in a detail when the section is asymmetric).
- [ ] Foundations: adjacent footing levels are compatible (check level steps against the 45° spread); special footings such as a lift-pit raft are labelled plainly.

## Plans vs sections vs elevations
- [ ] The section cut lines on the plans match where each section actually cuts. Move the cut if it misses the key element.
- [ ] Openings in elevations match the doors and windows in the plans.
- [ ] Column rhythm is the same in plans, sections, elevations and the structure axo.
- [ ] Every elevation obviously shows the same building. Compare against a vector aerial view.
- [ ] Spaces seen below on upper plans (open to below, a street below) are drawn faint, with no floor hatch, so they don't read as a slab.

## Roofs and envelope
- [ ] The roof concept described in words (e.g. "ribbons side by side") matches what sections and details show. Don't draw stacked layers if the concept is side-by-side.
- [ ] No unexplained open gaps between roof parts exposed to driving rain. If gaps are intended for light or air, show how rain is handled.
- [ ] Rainwater: every roof drains somewhere drawn (gutter, spout, chain, channel, rain garden).

## Site
- [ ] Parking bays never block the vehicle loop or the fire-tender path. Trucks don't need to reverse across pedestrian routes.
- [ ] The site plan, roof plan, ground plan and 3D views show the same layout. Old 3D images are refreshed after layout changes.

## Numbers and text
- [ ] All areas and key numbers on sheets are generated from the data, so there are no typos (e.g. 53 m² vs 5.3 m²).
- [ ] Grid labels are sequential and unique (no two "5" lines; rows in order).
- [ ] Room names are identical across plans, legends, the programme table and guides.
