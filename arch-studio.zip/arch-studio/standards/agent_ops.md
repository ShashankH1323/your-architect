# Agent operations: cost, speed, resumability

These rules come from what went wrong in the source sessions:
- subagents stuck for an hour on giant tasks;
- reruns that wasted the tokens already spent;
- work lost at usage limits;
- subagents that could not be resumed after the session moved apps;
- two agents overwriting the same scratch file.

## The lead (main chat)
- Make decisions, write data files and briefs, review outputs. Delegate scripting and drawing to subagents.
- Stay lean: read sections of files, not whole files.
- Never read raw `.dxf`, `.pdf` or large images into context. Use:
  - `grep` and listings;
  - scripts that print summaries;
  - downscaled previews (about 50–100 dpi), plus a few zoomed crops.

## Delegation map (the workflow is subagent-driven)
Delegate a job when it is big, mechanical or parallel. The lead does it when it is a short decision that needs context the lead already has, since re-briefing an agent would cost more than doing it.

| Stage | Lead (main chat) | Subagents (parallel where marked ∥) | Model tier |
|---|---|---|---|
| S0 intake | brief digest, brief-test analysis, questions | – | – |
| S1 research | picks the topics, merges the results | ∥ site & climate · ∥ bylaws & rules · ∥ one per space group (sizes + sources, returned as programme rows) · ∥ reference search per sheet category | mid; small for downloads and renaming |
| S2 foundation | journeys, triage, final programme numbers, adjacency logic (design decisions) | ∥ one per diagram script (table, matrix, bubbles, each zoning panel, site test-fit) · then 1 sheet builder (Foundation + Sources + Triage PDFs) | mid |
| S3 boards | writes the 1-line option descriptions | 1 board builder per board | small/mid |
| S4 form | drivers, form rules, the recommendation | ∥ one per option (massing + axo + checks) · 1 sheet builder | strongest for option concepts if the lead is busy; mid for drawing |
| S5 model | grid and structural decisions, clash rulings (`DECISIONS.md`) | one per level (walls → openings → rooms → stairs → furniture), then STRUCT, then SITE: sequential within a level, ∥ across levels once the grid is frozen | mid |
| S5/S6 drawings | reviews previews and crops | ∥ plans · ∥ sections · ∥ elevations · ∥ structure/details · ∥ 3D views (all read the frozen model) | mid |
| Checks | rules on failures | 1 runner for check_model + consistency audit | small |
| S10 blind review | verifies each issue (TRUE/FALSE), decides the fixes | 1 fresh reviewer, no context | strongest |
| S8 sheets | composition pick, captions sign-off | 1 sheet builder (+1 for check_pdf and previews) | mid / small |
| S9 guides | the "6 sentences" story | ∥ one per guide · 1 humanise pass | mid |

Rules for this map:
- **Freeze the inputs before fanning out.** Parallel drawing agents only start after the model and `DECISIONS.md` are frozen. Otherwise they each redraw from different data.
- At most about 4–5 agents at once. More causes file clashes and makes progress hard to track.
- If the host has no subagents, the lead runs the same jobs one by one, with the same small-save discipline.

## Subagents
- **One narrow job each, finishable in one go.** Examples: "build the adjacency matrix SVG from relations.json"; "draw section B-B from the model". Bad: "do all the foundation diagrams".
- If a job needs more than about 6 files of reading, it is too big. Split it, or pre-digest the inputs into one short brief file.
- Match the model to the job:
  - strongest model for design decisions and reviews;
  - mid model for scripting and drawing;
  - small model for trivial checks or renames.
- Each brief uses `templates/subagent_brief.md`:
  - goal;
  - exact input files (sections);
  - output paths;
  - style lock;
  - checks to run;
  - "save after each step";
  - "report clashes, don't silently redesign".
- **Unique file names per agent**, prefixed by job (`sec_draw.py`, `gf_model.py`), never generic (`part3.md`).
- Agents save in small pieces (one function, one level or one sheet at a time), never one giant file at the end.
- Agents append their check results under their own heading in `CHECKS.md`.
- Run independent jobs in parallel (e.g. plans / sections / elevations once the model is frozen).
- **Don't interrupt a working agent.** Check its output files instead. Only if it has been idle with no file changes for 15+ minutes, stop it. Then start a NEW narrow agent that continues from the files already saved, instead of rerunning the whole job.
- Report progress to any progress UI the host provides.

## State on disk (so any new chat can resume)
- `00_admin/PROJECT_STATE.md`: route, answers, locked styles, gates passed, approved versions.
- `00_admin/PROGRESS.md`: STATUS line, DONE, RUNNING (which agent writes which file), NEXT. Update it after every step.
- `DECISIONS.md` files hold lead decisions that agents must read first.
- When the user says "save and stop", or limits are close:
  - finish the current small save;
  - write PROGRESS.md with exactly what's half-done and which files exist;
  - stop.
- On resume, read PROJECT_STATE + PROGRESS first, check which output files exist, then continue. Never redo finished work.

## Phases in fresh chats
For long projects, split the work into fresh sessions at natural boundaries:
1. foundation;
2. form + drawings;
3. sheets;
4. 3D.

At each boundary, write a hand-off folder or `START_HERE.md` listing only the files the next phase needs. The next chat then reads 5 files, not 500.

## Token budget: where the cost goes and how this pack cuts it
| Cost driver (largest first) | What the pack does |
|---|---|
| **Redo loops** (foundation redone, forms redone, a full audit-and-fix revision in the source project) | Brief-test analysis, test-fit before approval, the hard foundation gate, purpose-driven forms, accuracy rules up front, check_model, blind review. Every gate makes later stages one-pass |
| **Writing drawing code from scratch** | Reuse `scripts/lib` (164 blocks + CAD helpers) and the checkers. Copy the previous project's `07_drawings/src` as a starting point when the typology is similar |
| **Reading big files into context** | Never read DXF/PDF/images raw. Use script summaries, 50–100 dpi previews, and a few targeted crops |
| **Subagents re-reading everything** | Pre-digest inputs into one short brief file; list exact file sections; one job each; finishable in one go |
| **Stuck or overlong agents and reruns** | Small saves; continue from saved files; never rerun a whole job |
| **Research sprawl** | Furniture values come from the pack's tables; about 5 searches per topic; research agents return table rows, not essays |
| **Loading the whole pack** | Load map in SKILL.md: about 3–6 files per stage |
| **Wrong model size** | Strongest model only for design decisions, the review and the blind review; mid model for scripting and drawing; small model for renames and trivial checks |
| **Chatty output** | Chat = questions + one-line status; content lives in files |

Rough budget for a W2 project, as a sanity check rather than a hard limit:
- the foundation about 15–20%;
- form about 10%;
- model + drawings about 40%;
- review and fixes about 10%;
- sheets + guides about 20%.

If a stage runs far over its share, stop and check whether it is redoing work.

## Cheap checks instead of reading
- Area totals, clashes, clearances, stair maths: Python on the model JSON.
- PDF health: pymupdf page count, image count per page, text extract for typos.
- DXF health: ezdxf audit, entity counts per layer, block list.
