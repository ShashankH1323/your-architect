# Edge cases: how to handle them without wasting a round

Each line gives the situation → what to do. When unsure, ask ONE question with a recommended default.

## The brief and the site
- **Scanned or image-only brief** → OCR it once (pymupdf text first, OCR only if empty). Write the digest; never re-read the brief after that.
- **Brief in another language, or mixed units** → digest in English. Keep the brief's units; if US/imperial, ask once whether drawings should be in feet-inches.
- **No brief (thesis or self-initiated)** → add one round: purpose of the building, users, rough size or budget, site. Build the programme from typology research and mark every area's source. The foundation gate matters even more here.
- **Brief contradicts itself or the rules** (areas exceed FAR, parking doesn't fit) → show the conflict at the foundation gate with 2–3 options (e.g. reduce X, add a floor, basement parking). Never silently break a rule.
- **No site given** → ask; offer "use a typical plot for this brief" with stated dimensions. A hypothetical site is labelled as such in the guide, never on the sheets.
- **Irregular plot or exact boundary unknown** → ask for a site plan, survey, a Google Earth screenshot with a scale, or coordinates. Trace the polygon and confirm its area in one line.
- **Sloped site** → ask for levels or contours (or estimate from public elevation data and say so). Sections show the ground line, and plinth/steps/ramps follow it.
- **Existing building, renovation or extension** → ask for the existing drawings. Model the existing parts on their own layers (`A-WALL-EXST`, `A-WALL-DEMO`). Plans show existing / new / demolished in the legend.
- **Campus or masterplan scale (many buildings)** → foundation at masterplan level (zoning, movement, phasing). Then ask which 1–2 buildings get full drawings. The other buildings are drawn as massing only.
- **Non-Indian location** → swap the code set in `space_standards_research.md` (IBC/ADA, Approved Documents/BS 8300, etc.), and the climate data source.
- **Local bylaws not found** → use the nearest larger city's or the national code. State the substitute in the Sources PDF.

## The user
- **Previous project or own references supplied** → study those instead of searching (S1, S3). Reuse their DXF layer and block names if the user wants the same office standard.
- **Hand sketch of a plan, zoning or form they want** → this is a design input, not a style. Trace it into the data (zoning, bubbles or model) at the right stage. Check it against the standards and report any conflicts.
- **"Just do it, skip the questions"** → use the recommended defaults for every choice and record them in PROJECT_STATE. Show the foundation warning once anyway; it is the one stop that prevents a full redo. Offer to skip the remaining boards.
- **Change of mind after a gate** → reply with an impact note first: what must be redrawn, roughly how big the job is, and which files. Proceed on OK. Version the data (`_approved_v2`) and log it in "Changes after approval".
- **The user rejects every option on a board twice** → ask them for one image they like (any source), or offer to use the preset in `drawing_style_presets.md` closest to what they described.
- **Team project** → the project guide gets a "who presents what" split. All sheets use one style.
- **The user can't open DXF** (no AutoCAD) → they can still view the DXFs in free viewers; the PDFs are the main deliverable. Offer R2013 DXF if they have an older AutoCAD.
- **The user asks for a DWG** → explain in one line that DXF opens in AutoCAD and can be saved as DWG there.

## Production
- **Usage limit or interruption mid-stage** → save protocol (agent_ops). Resume from PROGRESS.md and the files on disk; never restart the stage.
- **Arial not installed on the host** → use Liberation Sans / Arimo (metric-compatible) and embed fonts in the PDF.
- **Competition anonymity** → strip names from file names, PDF metadata (author, title, creator) and DXF headers. Use the brief's ID only.
- **PDF size limit** → keep drawings vector. Compress only photographic raster parts (JPEG at about 85%). Never rasterise drawings to save space.
- **One drawing changes late** → rebuild that drawing from its script, then every sheet that embeds it (check the inventory). Re-run check_model / check_pdf for the affected files only.
- **A user reference image is low-resolution or watermarked** → use it for style only. Never place it on a sheet.
- **Reference sources go down or downloads are blocked** → fall back to `drawing_style_presets.md` and draw small vector samples for the board.
- **A subagent returns something off-brief** → don't rerun the whole job. Send a narrow correction job that edits its saved files.
