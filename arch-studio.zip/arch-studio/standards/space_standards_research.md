# Space standards research: how every area is sized

**Rule:** no area in `programme.json` is a guess. Every space is sized by a **furniture-and-clearance test-fit**, then cross-checked against a published standard. Its source is recorded so the user can see where each number came from.

## 1. Source hierarchy (use the highest one that covers the item)
| Rank | Source | Use it for |
|---|---|---|
| 1 | **The brief** (areas, counts, annexures) | anything it states. Strict routes must follow it |
| 2 | **Local bylaws / development control rules** of the site's city or state | FAR/FSI, coverage, height, setbacks, parking ratios |
| 3 | **National building code.** India: NBC 2016 (Part 3 development control, Part 4 fire & life safety, Part 8 services, Part 9 plumbing). Elsewhere: IBC, Approved Documents | occupant loads, exits, stairs, fixture counts, ventilation |
| 4 | **Accessibility.** India: Harmonised Guidelines 2021. Elsewhere: ADA / BS 8300 | accessible WC, ramps, lifts, door widths, parking bays |
| 5 | **Typology guidelines.** Examples: FSSAI kitchens, IPHS hospitals, school norms, hotel classification, URDPFI parking | type-specific rooms and ratios |
| 6 | **Design data handbooks:** Neufert, *Architects' Data*; *Time-Saver Standards for Building Types*; *Metric Handbook*; Panero & Zelnik, *Human Dimension & Interior Space* | furniture sizes, clearances, unit layouts, area per person |
| 7 | **Comparable built precedents** | a sanity check of totals only |

## 2. Method per space
1. **Function + occupants + equipment.** For example: "Family dining, 72 seats, tables of 4 and 6, 1 kids' corner."
2. **Unit layout** from `standards/furniture_layout.md` (handbook values). Lay out the smallest repeating unit at true size: furniture, its use zone and the aisle share. Examples:
   - a 4-seat table unit is about 2.2–2.4 m square;
   - a WC cubicle is 1000 × 1400 plus a 1000 front zone.
3. **Multiply and arrange.** Units × count + main circulation + wall/column allowance give the **net area**.
4. **Cross-check against a standard rate**, e.g. dining 1.2–1.6 m² per seat, kitchen 0.4–0.5 m² per cover, office 8–10 m² per workstation. If the test-fit is off by more than ±15%, find out why before accepting it.
5. **Code minimums** for sizes, widths and heights. Fixtures come from the code AND a peak scenario (e.g. a bus of 50 arriving at once). Take the larger.
6. **Record it** in `programme.json`. Per space: name, area, unit, count, basis, check, source (list), verified (true/false), tier (core / essential / peripheral / technical), why. Example:
   - name "Family dining", area 110, unit "4-seat unit 2.4 x 2.4 m", count 18;
   - basis "test-fit 18 units + 1.2 m main aisle", check "1.5 m2 per seat x 72 = 108";
   - source "Neufert, Architects' Data, restaurants" + "NBC 2016 Part 4, occupant load";
   - verified true, tier core, why "families need a quieter floor away from trucks".
7. **Totals:** net → gross with a stated circulation and wall factor (typically 15–30% by type). Compare against the FAR, coverage and envelope.

## 3. Citations: honest and checkable
- Cite the document and the chapter. Add clause or table numbers only if read in the source this session.
- If a value comes from memory or a secondary site, set verified to false. It then appears as "to verify" in the Sources PDF. Do not make up clause numbers.
- If two sources disagree, use the stricter, unless the brief or local bylaw says otherwise. Note the choice in one line.
- The values used must agree with each other. A juror comparing two numbers must never find a contradiction.

## 4. Cost control
- One research subagent per **group** of spaces (e.g. dining + kitchen; toilets + accessibility; parking + site rules). It returns filled programme rows plus sources, not prose.
- Furniture and unit sizes come from `furniture_layout.md`, so there is no web search for them. Web-search only for:
  - local bylaws;
  - code fixture tables;
  - typology guidelines;
  - items marked "verify".

  Stop at about 5 searches per topic.

## 5. The user's sources file (always delivered with the foundation)
`04_foundation/PDF/Sources_and_Standards.pdf` is generated from `programme.json` + `regulations_internal.md`:
- **Areas.** Per space: area, how it was sized, the cross-check rate, the sources, and verified or "to verify".
- **Rules.** FAR, coverage, height, setbacks, parking, exits, fixtures, accessibility. Each has its value, source and the city or code it came from (and why that one, if it is a substitute).
- **Reading list.** Each book or code with edition and the chapter used.

This file is the full reference for the user. It answers "where did this number come from?" in depth.

The **short version** goes on the sheets themselves: the area programme table carries a one-line "How we sized it" and a short source per space (see S2 "The area programme table"). The user can present it directly without copying from this file.
