# Furniture and layout: sizes, clearances, placement procedure

Areas being right is not enough. In the first attempts at the source project, furniture blocked doors, basins sat in doorways and tables stood on column lines. This file makes layouts right the first time. All sizes are in mm and are typical values from Neufert, *Architects' Data*, *Time-Saver Standards*, *Metric Handbook*, *Human Dimension & Interior Space*, NBC 2016 and the Harmonised Accessibility Guidelines 2021. Where the local code is stricter, it wins.

The block library `scripts/lib/blocks.py` already draws most of these at true size. Use it and don't redraw blocks.

## 1. Placement procedure (always in this order)
1. **Fixed elements:** columns, walls with exact thickness, shafts, stairs, lift.
2. **Doors and swings.** Mark every swing arc plus a 1.2 m landing zone on both sides of exit doors. This zone is **no-furniture**.
3. **Circulation spines:** the main aisle from the entry to the counter, toilets and exits (1.2–1.5 m), and secondary aisles (0.9 m). Mark them as keep-clear strips.
4. **Wet and service fixtures** against the walls that hold the services: WCs and basins on the shaft wall, kitchen lines under the hoods on the outside wall.
5. **Furniture by zones,** in what's left. Respect the use zones in the tables below; never only the object outline.
6. **Orientation** (§4).
7. **Run the checks** (`scripts/check_model.py` + `standards/planning_checklist.md` §C–E). Fix, then re-run.

## 2. Furniture and use zones
| Item | Size | Use zone / clearance |
|---|---|---|
| Dining chair | 450 × 500 | 600 seated zone behind the table edge; 450 to push back |
| Table 2-seat | 700 × 700 | unit about 1.8 × 1.8 m with aisle share |
| Table 4-seat | 750 × 750 (sq) or 1200 × 750 | unit 2.2–2.4 m square |
| Table 6-seat | 1800 × 900 | — |
| Round 4 / 6 | Ø 900 / Ø 1200 | — |
| Booth (2 + 2) | 1500 × 1650 overall | aisle in front ≥ 900 |
| Bar / counter stool | Ø 400, 600 pitch | counter 600 deep, 1050 high; 300 knee space |
| Service counter | 600–750 deep, 900–1050 high | 1.2 m queue zone; accessible section at 800 high |
| Aisles (dining) | main 1200–1500, secondary 900, between chair backs 600 (min) / 900 if service passes | measured from the 600 seated zone |
| Office desk | 1500 × 750 | 1000 behind for the chair, 1200 if it is also a passage |
| Bed single / double | 900 × 2000 / 1800 × 2000 | 600 at the sides used, 900 in front; head against a solid wall |
| Bunk | 900 × 2000 | 900 aisle; ladder side clear |
| Sofa 3-seat | 2000 × 900 | 450 to the coffee table |
| Classroom desk + chair | 600 × 450 per student | rows 900 apart, aisles 600 / 1200 |
| Shelving / rack | 300–600 deep | 900 aisle (1200 if trolleys are used) |

## 3. Sanitary and kitchen
| Item | Size | Clearance |
|---|---|---|
| WC cubicle | min 900 × 1200 (aim 1000 × 1400; 900 × 1500 with an inward door) | 1000 clear in front; door swings out or clears the pan |
| Urinal | 400 wide | 600 pitch minimum (700 preferred), 1200 behind for circulation |
| Wash basin | 500 × 400 | 650–700 pitch; 1000 standing zone in front |
| Accessible WC | min 2000 × 2200 (design 2200 × 2300) | Ø 1500 turning circle clear of the door leaf, 900 transfer space beside the WC, grab rails, door ≥ 900 clear opening outward |
| Shower | 900 × 900 + 900 × 900 changing | — |
| Kitchen range / line | 700–900 deep | cook aisle 1000–1200, two-sided 1500; 150 from walls; hood = equipment + 300 at each end and the front |
| Prep table | 600–750 deep | 1000 aisle |
| Dishwash (pot + plate) | sink 600 × 600 per bowl + drainers | dirty and clean sides separate |
| Walk-in cold room | 2400 × 2400 minimum | door 900 outward |

## 4. Orientation logic
- **Dining:** diners face views, daylight or the room's focus. No seat faces a toilet door or a kitchen pass. Long tables run parallel to the main aisle.
- **Chairs** are pushed back into seated zones, never into aisles narrower than 1200.
- **Tables:** never on a column line. Either keep ≥ 450 clear between a chair zone and the column face, or wrap the column into a booth.
- **Beds:** head to a solid wall, never under a window or facing the door directly. Bedside access on the used side.
- **Desks:** light from the side (left for right-handed users), never with the back to the door in an office.
- **Toilets:** entries baffled so no fixture is visible from public areas. Urinals are never in line of sight of the door.
- **Kitchens:** one-way flow (receive → store → prep → cook → pass); dish return separate; hand-wash at the entry.
- **Vehicles:** park in the direction of the drive aisle; leave no reversing across pedestrian routes.

## 5. Never
- Furniture inside a door swing or the 1.2 m exit-door zone.
- A table, basin or fixture in a doorway or opening.
- Tables drawn without chairs, counters without stools or a queue zone, beds without access.
- Furniture overlapping walls, columns, stair flights or other furniture.
- Furniture shrunk to make it fit. If it doesn't fit, change the layout or the room, and report it.
- Decorative furniture with no use. Every piece serves a user in the journey.

## 6. Automated checks (see `scripts/check_model.py`)
- block footprint vs walls, columns and other blocks (overlap);
- block footprint vs door swing arcs + exit zones;
- block vs keep-clear aisle strips;
- WC front clearance;
- accessible WC turning circle;
- counts (seats, WCs, urinals, basins) vs `programme.json`.
