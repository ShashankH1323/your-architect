# Drawing style presets (fallbacks and board starting points)

Use these when reference downloads fail, or to make sure a choice board offers three genuinely different options. Each preset lists the traits the drawing scripts need. The source project's final picks are marked ★.

**★ marks are history, not defaults.** Never rank ★ presets first. Swap the hex colours for the project's locked accent. Two projects on the same brief should not both end on the same preset combination (`standards/originality.md`).

## Plans
**P-A ★ Filled walls, furnished, soft floors, one accent** (like a "furnished colour accent" plan)
- Cut walls solid warm dark grey #6B625C; columns small dark circles #3D3734.
- Floors pale #EFEFED, with faint grids by finish:
  - tile 300 in wet areas;
  - stone 600 in halls #EDE6DC;
  - deck planks on terraces #D9C8B5 (the accent);
  - pavers 450 outside #ECE8E1;
  - gardens #E4EBDB with stipple.
- Furniture and fixtures thin #4A4A4A at 0.18 mm, white fills, realistic shapes. Doors: leaf 0.25 mm, swing arc 0.13 mm light grey.
- Trees: lobed sketch canopies, sage #9DB08F at 35% alpha.
- Plain 2-digit room numbers; one "LEGEND" block in 4 columns of uppercase names. North arrow, scale bar, bold title bottom-right.

**P-B Outlined walls with hatch, black and white, technical**
- Walls double-line with 45° hatch; furniture 0.13 mm.
- No floor tones; room names and areas inside rooms; dimension chains.
- Good for W4 and strict juries.

**P-C Black poché with coloured zone tints**
- Walls solid #1A1A1A; each zone a very light tint (from the zone palette).
- Columns in the accent colour as small I or box sections.
- Trees as outlined line-trees with light grey fill.

## Sections
**S-A ★ Black poché, grey context, soil band**
- Everything cut solid #1A1A1A, including footings below ground in a grey soil band #D9D9D9 with stipple.
- Beyond lines #8C8C8C, light fills; grey people in use; soft grey trees.
- Small level triangles, scale bar, spaced-caps title, small key plan.

**S-B Rendered section / section-perspective**
- White clay interior in perspective behind the cut.
- Accent-coloured structure; people; light sun and wind annotation.
- Best as one hero on the "experience" sheet.

**S-C Line section with accent structure**
- Cut in mid grey, steel members in the accent colour, very light context.
- Good for structure sheets.

## Elevations
**E-A ★ Watercolour sky, sage trees** (the "Urban Food" look)
- Fine dark-grey linework 0.13–0.25 mm; light grey facade fills with soft shade bands; pale blue-grey glass.
- Soft watercolour cloud wash behind (#C9D6DE–#E6ECEF); sage trees #A9BC9A; dark grey ground band.
- Accent only on steel edges; a spaced-caps title centred below.

**E-B Pure line**
- Black line weights only (outline heavy, recesses medium, texture fine).
- No fills except glass; minimal trees as outlines.

**E-C Shaded with cast shadows**
- Grey planes with 45° cast shadows, a light ground plane, people.
- Reads depth best on flat facades.

## Diagrams (zoning, bubbles, movement)
**D-A ★ Minimal pastel**
- Zones as soft pastel fills with rounded corners and labels inside, in uppercase Arial.
- Thin dashed routes, one colour per user group; chevrons at entries; a full legend strip.
- Exploded axo with the active zone in one accent tint and a thin red route.

**D-B Axo blocks**
- Pale tints with a thin darker outline of the same hue on an isometric site.

**D-C Monochrome with accent**
- All grey, with only the subject in the accent colour.

## Sheet compositions
**C-A ★ Hero + ordered grid + text column** (Deus / Fish House boards)
- Big title band; one large hero drawing; a dense, aligned grid of smaller drawings and strips; a narrow text column; lots of white.

**C-B Horizontal bands**
- Full-width strips: a section strip, a plan band and a diagram row.
- Strong for long buildings.

**C-C Central plan (portrait A1)**
- One large plan in the middle, with sections and elevations around it and the text at the bottom.
