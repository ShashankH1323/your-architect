# Originality: no two users end up with the same project

**The problem.** The same brief plus the same answers given to the same workflow tends to give the same output: the same references, the same accent colour, the same sheet grid, even the same form. In a studio, where everyone has the same brief and often the same site, that makes every output suspicious and only one of them usable. It also wastes the tokens spent on the duplicates.

**What may repeat:** standards, accuracy rules, checklists and the process. Those are correct for everyone.

**What must differ:**
- references shown;
- colour theme;
- sheet composition;
- form and concept;
- plan layout;
- wording.

## 1. Design seed (every project, at S0)
- Create a random seed once: `py -I scripts/originality.py seed --project <folder>`. It is stored in `00_admin/PROJECT_STATE.md` and `00_admin/fingerprint.json`. Resumes reuse it.
- The seed decides, before the user sees anything:
  - **which 3 references** are shown per type, picked from a larger pool of about 8–12 found candidates (never just the top 3 of a search);
  - **the order of options** on every board;
  - **the accent colour family** offered first. The accent palette has 10 families, and only one accent is used per project;
  - **the composition families** proposed (3 of 5);
  - **the precedent families** studied for the form (S4);
  - **the form-driver emphasis** (which driver leads the first option).
- The user's own choices then diverge further from there. The seed only makes sure different users start from different places.

## 2. Personal inputs drive the design (the strongest source of difference)
- The intake free-text idea (theme, material, feeling) is a real form driver. Option A of S4 must come from it when given.
- **At S4, if the user gave no idea at intake,** ask ONE extra question before the form options. It offers 3 seed-picked design intents, e.g. "a shaded street", "one big roof", "pavilions in a garden", "a courtyard house", "a stepped terrace". Plus "Other: describe your own".
- The user's own references (S1) override the seed for that type.
- The local-context story (S1) is researched fresh per project. Pick the angle by seed: history, craft, landscape, industry or climate.

## 3. Fingerprint and registry
Each project writes `00_admin/fingerprint.json` (`templates/fingerprint.json`):
- the brief key (hash of the brief text) and the site key;
- reference file hashes (found + user);
- accent family and composition family;
- form family and footprint signature;
- plan topology signature;
- the version of the pack.

**Registry.** `scripts/originality.py` appends each fingerprint to a registry and checks new projects against it:
- **Local (default):** `~/.arch-studio/registry.jsonl`. It stops one user (or one machine, e.g. a lab PC) from repeating themselves.
- **Shared (for a class, a team or a product):** set the environment variable `ARCH_STUDIO_REGISTRY` to a shared path, e.g. a synced folder or a network drive. A web product replaces the file with a backend endpoint holding the same record (see README).
- Only hashes and design signatures are stored. No names, emails, briefs or drawings.

**Without a shared registry, there's no hard guarantee.** Separate accounts on separate machines can't see each other. The seed plus personal inputs make close matches unlikely; the shared registry is what makes them checkable.

## 4. Checks (automatic, silent unless a clash is found)
Run `py -I scripts/originality.py check 00_admin/fingerprint.json` at three points:

| When | Compared against other projects on the same brief | If too similar |
|---|---|---|
| Before showing reference boards (S3) | reference hashes | swap the overlapping references for the next pool candidates; no user question |
| After the form pick (S4) | form family + footprint signature (+ site key) | tell the user in one line and show the next option family, or a variation of their pick (different roof, massing or open-space strategy) |
| After the plans (S5) and before the sheets (S8) | plan topology + composition + accent | change composition or accent automatically if they were seed-driven. If the plan topology matches, make one variation round (zoning moves, core position, entry side), then re-check |

The thresholds are in the script (similarity 0–1; ≥ 0.75 = too similar). Projects on different briefs are never compared.

## 5. Wording and text
- Captions, the concept name, principles and guide text are written fresh from the project's own data. Don't reuse sentences from earlier projects or from examples in this pack.
- The examples in this pack ("The Woven Street", "six principles", the ★ presets) are illustrations. Never copy them as defaults.
